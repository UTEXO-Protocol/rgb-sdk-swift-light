# utexo-rgb-verifier

Pre-sign RGB verification for the UTEXO mobile SDKs: one Rust core with UniFFI
bindings for Kotlin and Swift.

The gateway prepares RGB sends and the device signs them. Spending a colored
input authorizes whatever RGB transition the transaction commits to, and that
commitment is opaque to the local signer, whose README says so directly:
"Bitcoin validation cannot prove RGB transition semantics". So a compromised
backend can send the payment and the wallet's own RGB change to seals it
controls while the PSBT passes every bitcoin check. This crate closes that hole.
The background is in `rln-gateway/docs/design/rgb-client-side-verification.md`.

## What `verify_rgb_send` proves

It takes the unsigned PSBT, rgb-lib's fascia and MPC entropy, the invoice, the
user-approved asset and amount, and the wallet's account xpubs. It returns a
verdict only if all of these hold:

1. **The fascia describes this transaction.** Its witness txid equals the PSBT's
   unsigned txid, and its commitment method is opret.
2. **No committed contract is hidden.** The transaction's single `OP_RETURN`
   carries 32 bytes equal to the MPC root recomputed from every bundle in the
   fascia with the given entropy (`src/rgb.rs`, `recompute_commitment`).
3. **No committed transition is hidden.** A bundle id commits only to its input
   map, so every opid in it must be disclosed, must hash to that id, and must
   spend exactly the inputs mapped to it (`disclosed_transitions`).
4. **There is no second commitment.** Every output is the `OP_RETURN`, a wallet
   output whose script re-derives from the account xpubs, or, for a witness
   invoice, the single output paying the invoice's script. None of these can
   carry a tapret commitment.
5. **The beneficiary gets exactly what was approved.** Exactly one assignment
   goes to the invoice's beneficiary (its blinded seal, or the witness output),
   for the approved asset and amount.
6. **Everything else comes back.** Every other assignment of every committed
   transition (RGB change, other assets on spent inputs, rights) goes to a
   revealed seal on the wallet's colored account. That is either an output of
   this transaction or an existing UTXO whose creating transaction was supplied
   and re-derives.

So the signature cannot move RGB state to anyone except the invoice's
beneficiary and the wallet.

## What it does not prove

- **That the transitions are valid RGB history**, such as amount conservation
  or schema rules. An invalid transition destroys the state it spends; nobody
  gains it.
- **That the fascia covers every allocation on the spent inputs.** Proving an
  absence needs the wallet's own RGB state, which a stateless client doesn't
  hold. An allocation left out is destroyed when its input is spent.
- **That an existing-UTXO seal is still unspent.** That needs an indexer, and a
  spent one destroys the change assigned to it.
- **Bitcoin policy**: input ownership, fees, the witness output's sats,
  locktime. The local signer checks these, so run both.
- **Invoice expiry and transport endpoints**, which the SDK facades check
  already.

Each gap destroys value rather than redirecting it. The server holds the user's
only copy of their RGB history today, so it can already destroy assets by
deleting that history.

## Inputs

| Field | Source | Trusted |
| --- | --- | --- |
| `network`, `accounts` | the device's own key derivation (the signer's `WalletIdentity`) | yes |
| `invoice`, `asset_id`, `amount` | what the user entered and approved, never the gateway's echo of it | yes |
| `psbt_base64` | gateway prepare response | no |
| `fascia`, `mpc_entropy` | rgb-lib `send_begin`: the bytes at `details.fascia_path`, and `details.entropy`. The PSBT of a current rgb-lib-bfa carries neither | no |
| `existing_output_proofs` | the raw transaction of each existing UTXO used as a seal, plus its derivation index | no, self-authenticating |
| `max_derivation_index` | SDK policy; `10_000` matches `verify.ts` | yes |

rgb-lib uses an existing UTXO for RGB change when the send has no BTC change
output (`get_change_seal` in rgb-lib-bfa `src/wallet/online.rs`). Otherwise
`existing_output_proofs` is empty.

## What the server returns

The evidence comes from two services. Both changes are additive, and both
describe only the requesting user's own transfer.

- **rgb-node-api** `sendbegin` returns, next to `psbt`: `fascia` (the file at
  rgb-lib's `details.fascia_path`, as hex), `entropy` (`details.entropy`, as
  decimal text) and `change_utxos` (the UTXOs rgb-lib assigns the transfer's
  RGB change to, each with its `derivation_index` on the colored account when
  the wallet already holds it).
- **The gateway** turns that into `rgbEvidence` in the send-asset prepare
  response. For each change UTXO that is not an output of the prepared
  transaction, it reads the creating transaction from its Electrum indexer and
  adds an existing-output proof. Without an indexer it leaves the proof out,
  and the device refuses that send.

rgb-lib uses an existing UTXO for RGB change exactly when the send has no
bitcoin change output, for instance when what is left of the inputs after the
fee is below the dust limit.

The Kotlin and Swift SDKs read them from an optional `rgbEvidence` object next
to `psbt`. It must contain exactly these keys:

```json
"rgbEvidence": {
  "fascia": "<canonical padded Base64 of the strict-encoded fascia>",
  "mpcEntropy": "<details.entropy as decimal text: a u64 exceeds JSON's safe integers>",
  "existingOutputProofs": [
    { "transaction": "<lowercase hex of the creating transaction>", "vout": 1, "derivationIndex": 7 }
  ]
}
```

`existingOutputProofs` is empty unless a seal is an existing UTXO, and holds at
most 8 proofs. A missing or `null` `rgbEvidence` means the gateway sent no
evidence. The SDK then refuses to sign unless its policy explicitly allows
unverified RGB sends.

## Using it from the SDKs

Call it after binding the gateway's intent to the user's request, and before
the signer. Sign only if it returns a verdict.

```kotlin
import com.utexo.rgb.sdk.internal.ffi.verifier.*

val verdict = verifyRgbSend(
    RgbSendRequest(
        network = Network.REGTEST,
        accounts = WalletAccounts(
            masterFingerprint = identity.masterFingerprint,
            accountXpubVanilla = identity.accountXpubVanilla,
            accountXpubColored = identity.accountXpubColored,
        ),
        psbtBase64 = prepared.psbt,
        fascia = prepared.fascia,
        mpcEntropy = prepared.mpcEntropy,
        invoice = request.invoice,
        assetId = request.assetId,
        amount = request.amount,
        existingOutputProofs = prepared.existingOutputProofs,
        maxDerivationIndex = 10_000u,
    ),
) // throws VerifierException: do not sign; its message is safe to log
```

```swift
let verdict = try verifyRgbSend(request: RgbSendRequest(
    network: .regtest,
    accounts: WalletAccounts(
        masterFingerprint: identity.masterFingerprint,
        accountXpubVanilla: identity.accountXpubVanilla,
        accountXpubColored: identity.accountXpubColored),
    psbtBase64: prepared.psbt,
    fascia: prepared.fascia,
    mpcEntropy: prepared.mpcEntropy,
    invoice: request.invoice,
    assetId: request.assetId,
    amount: request.amount,
    existingOutputProofs: prepared.existingOutputProofs,
    maxDerivationIndex: 10_000)) // throws VerifierError
```

`network` uses the signer's `Network` variants, including `Utexo`. Error
messages name output indexes, counts and asset ids only. They never include
keys, PSBTs, fascia bytes or invoices.

## Building

```sh
cargo test --locked             # unit and attack tests
scripts/ffi-smoke.sh            # calls the built library through generated Python bindings
scripts/generate-bindings.sh    # Kotlin and Swift bindings into target/bindings
scripts/build-android.sh        # release .so per ABI into target/android/jniLibs
scripts/build-apple.sh          # UtexoRgbVerifier.xcframework into target/apple (macOS only)
```

The tests build every PSBT and fascia with `psrgbt::rgb_commit`, the code
rgb-lib's `send_begin` runs. Each attack test then changes one thing a hostile
preparer controls. Two more tests run the real sends in
`tests/fixtures/regtest-rgb-lib-sends.json`. `tests/fixtures/README.md` covers
the fixtures.

On Android release builds (`opt-level = "z"`, stripped), `libutexo_rgb_verifier.so`
is 3.1 MB on arm64-v8a, 2.1 MB on armeabi-v7a and 3.2 MB on x86_64, against
2.4 MB, 2.0 MB and 2.6 MB for `libutexo_local_signer.so`.

The RGB crates are pinned to the exact versions rgb-node-api resolves through
rgb-lib-bfa `v0.3.0-beta.7-upstream-dev-bfa.3` (`rgb-consensus`, `rgb-ops`,
`rgb-invoicing` `0.11.2-rc.1`; `bitcoin 0.32.102`). Bump them together with
rgb-node-api: ids and commitments must come from the same code on both sides.

## Packaging

Both SDKs ship this as a second Rust library next to `utexo-local-signer`. That
costs a second copy of std, `bitcoin` and `secp256k1`.

On Android the two are separate shared libraries, and `rgb-sdk-kotlin-light`
ships `libutexo_rgb_verifier.so` that way.

On Apple platforms both are static, and they do collide: linking the two
release archives into one binary fails with 65 duplicate definitions, all of
them `rustsecp256k1_v0_10_0_*` from the libsecp256k1 both embed (measured on
Linux with GNU ld, both crates built with rustc 1.88.0). So
`scripts/build-apple.sh` prelinks each slice into a single object and keeps only
the `ffi_utexo_rgb_verifier_*` and `uniffi_utexo_rgb_verifier_*` symbols global.
The same prelink on Linux (`ld -r --whole-archive`, then `objcopy
--keep-global-symbol`) leaves 57 global symbols, links cleanly next to the
signer's archive, and both libraries answer from the one binary.

The alternative is one combined library: add this crate as a path dependency of
`utexo-local-signer` and generate both crates' bindings from the signer's
library. The signer's `uniffi-bindgen.toml` already uses the per-crate format,
so that is one more `[crates.utexo_rgb_verifier.*]` section plus a `crate-roots`
entry. It removes the duplicate copies, at the price of releasing the two
together.

## Status

- **Verified against real rgb-lib output.** Three sends prepared by rgb-lib-bfa
  `v0.3.0-beta.7-upstream-dev-bfa.8` on the gateway's regtest stack verify, and
  are fixtures in `tests/fixtures/regtest-rgb-lib-sends.json`: a witness send,
  a blinded send, and a blinded send whose change sits on an existing UTXO.
  That rgb-lib takes the RGB crates from git revisions rather than the
  `0.11.2-rc.1` releases pinned here; for these NIA transfers both produce the
  same ids and commitment.
- **Verified on device, Android only.** Through `rgb-sdk-kotlin-light` on an
  x86_64 emulator, with verification required: a witness send and a blinded
  send completed and settled, and a changed entropy, a changed fascia, missing
  evidence and a missing ownership proof were each refused.
- **The server side is not merged.** It exists on the branches
  `feat/sendbegin-rgb-evidence` (rgb-node-api) and `feat/rgb-send-evidence`
  (gateway). No deployed gateway returns the evidence yet.
- **rgb-lib-bfa bfa.8 PSBTs fail the local signer**, with or without this
  verifier. They carry no RGB, MPC or OPRET proprietary data, and
  `utexo-local-signer` requires all of it ("incomplete or unsupported RGB PSBT
  envelope"). The device runs above used a signer patched to accept such a
  PSBT; the shipped signer cannot sign an RGB send from that rgb-lib.
- **The signer's fee rule refuses most sends that need an ownership proof.**
  With no bitcoin change the leftover goes to the fee, which then exceeds the
  signer's budget for the caller's fee rate. The verifier accepts these sends;
  the signer does not.
- `scripts/build-apple.sh` hasn't been run: this was developed on Linux, and
  Apple libraries need macOS. No Apple library exists yet, and
  `rgb-sdk-swift-light` can't rebuild its binary facade until one does.
- The Swift bindings compile, and `rgb-sdk-swift-light`'s tests call this
  library through them, on Linux only (Swift 6.2.4, against a Linux build of
  this crate).
- The tests pass on rustc 1.88.0, the toolchain the signer pins, as well as on
  1.98.0, and both generate identical bindings. The Android libraries in
  `rgb-sdk-kotlin-light` were built with 1.98.0.
