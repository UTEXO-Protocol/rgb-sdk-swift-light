#!/usr/bin/env bash
# Builds UtexoRgbVerifier.xcframework for the Swift SDK: static libraries for
# macOS (arm64, x86_64), iOS (arm64) and the iOS simulator (arm64, x86_64).
#
# Usage: scripts/build-apple.sh [out-dir]   (default: target/apple)
# Writes <out-dir>/UtexoRgbVerifier.xcframework, whose headers are the generated
# UtexoRgbVerifierFFI.h and its module map. Needs macOS, Xcode and the five Rust
# Apple targets. Deployment targets are macOS 13.0 and iOS 15.0, matching the
# local signer.
#
# Each slice is prelinked into one object that exports only this crate's UniFFI
# symbols. An app links this library statically next to utexo-local-signer, and
# both embed libsecp256k1 and the Rust runtime: left global, those definitions
# collide at link time.
set -euo pipefail

CORE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${CORE_DIR}"
OUT_DIR="${1:-target/apple}"
LIBRARY=libutexo_rgb_verifier.a
OBJECT=utexo_rgb_verifier.o

if [[ "$(uname -s)" != Darwin ]]; then
  echo "Apple libraries can only be built on macOS with Xcode" >&2
  exit 1
fi

mkdir -p target "${OUT_DIR}"
STAGING="$(mktemp -d target/apple-stage.XXXXXX)"
trap 'rm -rf "${STAGING}"' EXIT

# The headers come from the same source the libraries are built from.
scripts/generate-bindings.sh "${STAGING}/bindings"
mkdir -p "${STAGING}/Headers"
cp "${STAGING}/bindings/swift/UtexoRgbVerifierFFI.h" "${STAGING}/Headers/"
cp "${STAGING}/bindings/swift/UtexoRgbVerifierFFI.modulemap" "${STAGING}/Headers/module.modulemap"

# Only the UniFFI C ABI stays global. ld accepts shell-style wildcards here.
printf '%s\n' '_ffi_utexo_rgb_verifier_*' '_uniffi_utexo_rgb_verifier_*' > "${STAGING}/exports.txt"

# Keep developer paths out of the Rust and libsecp256k1 objects.
export RUSTFLAGS="--remap-path-prefix=${CORE_DIR}=/utexo-rgb-verifier --remap-path-prefix=${CARGO_HOME:-${HOME}/.cargo}=/cargo"
export CFLAGS="-ffile-prefix-map=${CORE_DIR}=/utexo-rgb-verifier -ffile-prefix-map=${CARGO_HOME:-${HOME}/.cargo}=/cargo"

# build <rust-target> <arch> <deployment-target-assignment>
build() {
  local target="$1" arch="$2" deployment="$3" out="${STAGING}/$1" leaked
  mkdir -p "${out}"
  # libsecp256k1's C build must not inherit the build host's OS version.
  env "${deployment}" cargo build --release --locked --lib --target "${target}"
  # Without -keep_private_externs, every symbol outside the export list becomes
  # local to the prelinked object.
  xcrun ld -r -arch "${arch}" -exported_symbols_list "${STAGING}/exports.txt" \
    -all_load "target/${target}/release/${LIBRARY}" -o "${out}/${OBJECT}"
  strip -S "${out}/${OBJECT}"
  # Fail here rather than ship an archive that can collide with the signer's.
  leaked="$(xcrun nm -gU "${out}/${OBJECT}" | awk '{print $NF}' |
    grep -Ev '^_(ffi|uniffi)_utexo_rgb_verifier_' || true)"
  if [[ -n "${leaked}" ]]; then
    echo "${target}: symbols outside the UniFFI ABI are still global:" >&2
    echo "${leaked}" | head -n 20 >&2
    exit 1
  fi
  if ! xcrun nm -gU "${out}/${OBJECT}" | grep -q '_uniffi_utexo_rgb_verifier_fn_func_verify_rgb_send$'; then
    echo "${target}: verify_rgb_send is not exported" >&2
    exit 1
  fi
  xcrun libtool -static -o "${out}/${LIBRARY}" "${out}/${OBJECT}"
}

build aarch64-apple-darwin arm64 MACOSX_DEPLOYMENT_TARGET=13.0
build x86_64-apple-darwin x86_64 MACOSX_DEPLOYMENT_TARGET=13.0
build aarch64-apple-ios arm64 IPHONEOS_DEPLOYMENT_TARGET=15.0
build aarch64-apple-ios-sim arm64 IPHONEOS_DEPLOYMENT_TARGET=15.0
build x86_64-apple-ios x86_64 IPHONEOS_DEPLOYMENT_TARGET=15.0

mkdir -p "${STAGING}/macos" "${STAGING}/ios" "${STAGING}/simulator"
lipo -create \
  "${STAGING}/aarch64-apple-darwin/${LIBRARY}" "${STAGING}/x86_64-apple-darwin/${LIBRARY}" \
  -output "${STAGING}/macos/${LIBRARY}"
cp "${STAGING}/aarch64-apple-ios/${LIBRARY}" "${STAGING}/ios/${LIBRARY}"
lipo -create \
  "${STAGING}/aarch64-apple-ios-sim/${LIBRARY}" "${STAGING}/x86_64-apple-ios/${LIBRARY}" \
  -output "${STAGING}/simulator/${LIBRARY}"

xcodebuild -create-xcframework \
  -library "${STAGING}/macos/${LIBRARY}" -headers "${STAGING}/Headers" \
  -library "${STAGING}/ios/${LIBRARY}" -headers "${STAGING}/Headers" \
  -library "${STAGING}/simulator/${LIBRARY}" -headers "${STAGING}/Headers" \
  -output "${STAGING}/UtexoRgbVerifier.xcframework"
plutil -lint "${STAGING}/UtexoRgbVerifier.xcframework/Info.plist"

# Replace a previous build only once every slice is complete.
rm -rf "${OUT_DIR}/UtexoRgbVerifier.xcframework"
mv "${STAGING}/UtexoRgbVerifier.xcframework" "${OUT_DIR}/UtexoRgbVerifier.xcframework"
echo "built ${OUT_DIR}/UtexoRgbVerifier.xcframework"
