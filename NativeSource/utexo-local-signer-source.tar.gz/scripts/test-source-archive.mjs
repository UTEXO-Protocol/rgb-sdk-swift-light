#!/usr/bin/env node
// Integration regression for the independent decoder. Mutated archives are
// created only in a fresh temporary directory; no source or SDK files change.
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { gunzipSync, gzipSync } from 'node:zlib';

const script = dirname(fileURLToPath(import.meta.url));
const archive = resolve(process.argv[2] ?? resolve(script, '../../../rgb-sdk-swift-light/NativeSource/utexo-local-signer-source.tar.gz'));
const raw = gunzipSync(readFileSync(archive));
const files = [];
for (let offset = 0; offset + 512 <= raw.length;) {
  const header = raw.subarray(offset, offset + 512);
  if (header.every(byte => byte === 0)) break;
  const size = Number.parseInt(header.subarray(124, 136).toString('ascii').replace(/\0.*$/, '').trim(), 8);
  assert.ok(Number.isSafeInteger(size) && size >= 0);
  const end = offset + 512 + Math.ceil(size / 512) * 512;
  assert.ok(end <= raw.length);
  files.push({ name: header.subarray(0, 100).toString('ascii').replace(/\0.*$/, ''), bytes: Buffer.from(raw.subarray(offset, end)) });
  offset = end;
}
const temporary = mkdtempSync(join(tmpdir(), 'utexo-source-archive-regression-'));
function verify(path, expected, label) {
  const result = spawnSync(process.execPath, [join(script, 'verify-source-archive.mjs'), path], { encoding: 'utf8' });
  if (result.error) throw result.error;
  assert.equal(result.status === 0, expected, `${label}: ${result.stderr}`);
}
function check(name, parts) {
  const path = join(temporary, `${name}.tar.gz`);
  writeFileSync(path, gzipSync(Buffer.concat([...parts, Buffer.alloc(1024)])));
  verify(path, false, name);
}
function headerMutation(entry, mutate) {
  const bytes = Buffer.from(entry.bytes);
  mutate(bytes.subarray(0, 512));
  bytes.fill(0x20, 148, 156);
  const checksum = bytes.subarray(0, 512).reduce((sum, byte) => sum + byte, 0);
  bytes.write(`${checksum.toString(8).padStart(6, '0')}\0 `, 148, 8, 'ascii');
  return bytes;
}
try {
  verify(archive, true, 'unaltered source');
  const parts = files.map(file => file.bytes);
  assert.ok(files.some(file => file.name === 'src/keys.rs'));
  check('missing-source', files.filter(file => file.name !== 'src/keys.rs').map(file => file.bytes));
  check('duplicate', [...parts, parts[0]]);
  check('symlink', [headerMutation(files[0], header => { header[156] = 0x32; }), ...parts.slice(1)]);
  check('hardlink', [headerMutation(files[0], header => { header[156] = 0x31; }), ...parts.slice(1)]);
  check('unsafe-path', [headerMutation(files[0], header => {
    header.fill(0, 0, 100); header.write('../outside');
  }), ...parts.slice(1)]);
  const altered = Buffer.from(parts[0]);
  assert.ok(altered.length > 512);
  altered[512] ^= 1;
  check('changed-content', [altered, ...parts.slice(1)]);
  console.log('Source archive: unaltered pass; six malformed/incomplete/tampered archives rejected.');
} finally {
  // Exact freshly-created directory only; never a user-supplied path.
  rmSync(temporary, { recursive: true });
}
