#!/usr/bin/env node
// Generate exact locked-source SBOM/notices; optionally query OSV for advisories.
// No wallet state, identifiers, credentials, source text or private URLs are sent.
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { dirname, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { validatedOsvResults } from './osv-response.mjs';
import { lockedRegistryChecksums, verifyRegistryNoticeBinding } from './notice-binding.mjs';

const core = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const flags = process.argv.slice(2);
if (flags.some(flag => !['--advisories', '--check'].includes(flag))) {
  throw new Error('usage: security-inventory.mjs [--check] [--advisories]');
}
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const compare = (a, b) => a < b ? -1 : a > b ? 1 : 0;
const metadata = JSON.parse(execFileSync('cargo', [
  'metadata', '--all-features', '--offline', '--locked', '--format-version', '1',
], { cwd: core, encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 }));
const packages = metadata.packages.filter(p => p.source !== null)
  .sort((a, b) => compare(a.name, b.name) || compare(a.version, b.version));
if (!packages.length || packages.some(p => !p.source.startsWith('registry+'))) {
  throw new Error('expected nonempty registry dependency graph; review non-registry dependencies explicitly');
}
const output = join(core, 'assurance');
mkdirSync(output, { recursive: true });
const persist = (name, text) => {
  const path = join(output, name);
  if (flags.includes('--check')) {
    if (!existsSync(path) || readFileSync(path, 'utf8') !== text) {
      throw new Error(`stale or missing generated security inventory: ${name}`);
    }
  } else {
    writeFileSync(path, text);
  }
};
const purl = p => `pkg:cargo/${p.name}@${encodeURIComponent(p.version)}`;
const byID = new Map(metadata.packages.map(p => [p.id, p]));
const dependencyGraph = metadata.resolve.nodes.map(node => ({
  ref: purl(byID.get(node.id)),
  dependsOn: [...new Set(node.dependencies.map(id => purl(byID.get(id))))].sort(),
})).sort((a, b) => compare(a.ref, b.ref));
const mainPackage = metadata.packages.find(p => p.id === metadata.resolve.root);
const bom = {
  bomFormat: 'CycloneDX', specVersion: '1.6', version: 1,
  metadata: {
    component: { type: 'library', name: mainPackage.name, version: mainPackage.version,
      'bom-ref': purl(mainPackage), purl: purl(mainPackage) },
    properties: [
      { name: 'utexo:scope', value: 'Locked production-crate all-feature graph, including its build, test, bindgen and all-platform dependencies; excludes the separately locked fuzz harness and is not a runtime-linked-code-only inventory.' },
      { name: 'utexo:cargo-lock-sha256', value: sha(readFileSync(join(core, 'Cargo.lock'))) },
    ],
  },
  components: packages.map(p => ({
    type: 'library', name: p.name, version: p.version, 'bom-ref': purl(p), purl: purl(p),
    ...(p.license ? { licenses: [{ expression: p.license.replaceAll('MIT/Apache-2.0', 'MIT OR Apache-2.0') }] } : {}),
    ...(p.repository ? { externalReferences: [{ type: 'vcs', url: p.repository }] } : {}),
  })),
  dependencies: dependencyGraph,
};
persist('native-source.cdx.json', `${JSON.stringify(bom, null, 2)}\n`);

function noticeFiles(directory, depth = 0) {
  const files = [];
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const path = join(directory, entry.name);
    // Do not follow symlinks outside the dependency source tree.
    if (entry.isFile() && /^(LICENSE|LICENCE|COPYING|NOTICE|COPYRIGHT|AUTHORS)([._-]|$)/i.test(entry.name)) {
      files.push(path);
    } else if (entry.isDirectory() && depth < 6 && !['.git', 'target', 'node_modules'].includes(entry.name)) {
      files.push(...noticeFiles(path, depth + 1));
    }
  }
  return files.sort();
}
let notices = '# Third-party Rust source notices\n\n' +
  'Generated from the pinned production-crate Cargo source graph, including build/test/bindgen dependencies.\n' +
  'The separately locked, non-shipping fuzz harness is outside this mobile distribution inventory.\n' +
  'This preserves upstream notice texts; it is not a choice of SDK license, legal approval,\n' +
  'or proof that every listed crate is linked into every platform binary.\n\n';
const missing = [];
const supplements = JSON.parse(readFileSync(join(core, 'assurance/upstream-notices/manifest.json'), 'utf8'));
const registryChecksums = lockedRegistryChecksums(readFileSync(join(core, 'Cargo.lock'), 'utf8'));
const supplementFor = new Map();
for (const notice of supplements) {
  if (!/^[A-Za-z0-9_.-]+$/.test(notice.file) || !/^[a-f0-9]{64}$/.test(notice.sha256) ||
      !/^[a-f0-9]{40}$/.test(notice.commit) || !Array.isArray(notice.packages)) {
    throw new Error('invalid supplemental notice manifest');
  }
  const bytes = readFileSync(join(core, 'assurance/upstream-notices', notice.file));
  if (sha(bytes) !== notice.sha256) throw new Error('supplemental notice content changed');
  for (const id of notice.packages) {
    if (supplementFor.has(id) || !packages.some(p => `${p.name}@${p.version}` === id)) {
      throw new Error(`duplicate/stale supplemental notice package: ${id}`);
    }
    supplementFor.set(id, { ...notice, bytes });
  }
}
function renderNotice(label, bytes) {
  if (bytes.includes(0) || bytes.length > 1_000_000) throw new Error(`unexpected notice format: ${label}`);
  const original = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
  // Preserve the entire text, including original trailing whitespace. The
  // optional final newline is Markdown framing, not part of the stated hash.
  const fence = '`'.repeat(Math.max(3, ...[...original.matchAll(/`+/g)].map(match => match[0].length + 1)));
  return `### ${label} (original bytes SHA-256 ${sha(bytes)})\n\n` +
    `${fence}text\n${original}${original.endsWith('\n') ? '' : '\n'}${fence}\n\n`;
}
for (const p of packages) {
  const directory = dirname(p.manifest_path);
  const files = noticeFiles(directory);
  notices += `## ${p.name} ${p.version}\n\nDeclared license: ${p.license ?? 'UNDECLARED'}\n\n`;
  const supplement = supplementFor.get(`${p.name}@${p.version}`);
  if (!files.length && !supplement) {
    missing.push(`${p.name}@${p.version}`);
    notices += 'REVIEW REQUIRED: crate archive contains no recognized license/notice file.\n\n';
  }
  for (const file of files) {
    const bytes = readFileSync(file);
    notices += renderNotice(relative(directory, file), bytes);
  }
  if (supplement) {
    if (supplement.registryRelease) {
      verifyRegistryNoticeBinding(supplement, p, registryChecksums);
      notices += 'Binding: reviewed upstream release tag and exact registry archive checksum; ' +
        'this crate did not include a VCS identity. Not a source-to-tag reproduction claim.\n\n';
    } else {
      const vcs = JSON.parse(readFileSync(join(directory, '.cargo_vcs_info.json'), 'utf8'));
      if (vcs.git?.sha1 !== supplement.commit) throw new Error(`supplement commit mismatch: ${p.name}`);
    }
    notices += `Upstream supplement: ${supplement.url}\n\n`;
    notices += renderNotice(supplement.file, supplement.bytes);
  }
}
persist('THIRD_PARTY_RUST_NOTICES.md', notices);
persist('license-review.json', `${JSON.stringify({
  schema: 'utexo.license-review-input.v1',
  status: 'requires-owner-review',
  sdkDistributionLicense: 'not-selected-by-this-generator',
  packages: packages.length,
  missingNoticePackages: missing,
  declaredExpressions: [...new Set(packages.map(p => p.license))].sort(),
}, null, 2)}\n`);
console.log(`Inventory: ${packages.length} third-party crates; ${missing.length} missing notice bundles (see license-review.json).`);

if (flags.includes('--advisories')) {
  const queries = packages.map(p => ({ package: { name: p.name, ecosystem: 'crates.io' }, version: p.version }));
  const findings = [];
  for (let offset = 0; offset < queries.length; offset += 64) {
    const batch = queries.slice(offset, offset + 64);
    const response = await fetch('https://api.osv.dev/v1/querybatch', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ queries: batch }), signal: AbortSignal.timeout(30_000),
    });
    if (!response.ok) throw new Error(`OSV query failed: HTTP ${response.status}; no clean scan may be inferred`);
    const results = validatedOsvResults(await response.json(), batch.length);
    for (let i = 0; i < results.length; i++) {
      const result = results[i];
      for (const advisory of result.vulns ?? []) {
        findings.push({ ...batch[i], advisory: advisory.id, modified: advisory.modified });
      }
    }
  }
  const report = {
    schema: 'utexo.advisory-scan.v1', checkedAt: new Date().toISOString(),
    source: 'https://api.osv.dev/v1/querybatch',
    cargoLockSha256: sha(readFileSync(join(core, 'Cargo.lock'))),
    scope: 'Exact locked all-feature Cargo versions; not OS/runtime/container/Gradle or unpublished vulnerabilities.',
    queriedPackages: queries.length, findings,
    status: findings.length ? 'review-required' : 'no-advisories-returned',
  };
  writeFileSync(join(output, 'advisories.json'), `${JSON.stringify(report, null, 2)}\n`);
  console.log(`OSV: ${queries.length} packages, ${findings.length} advisory matches. Report: assurance/advisories.json`);
  if (findings.length) process.exitCode = 2;
}
