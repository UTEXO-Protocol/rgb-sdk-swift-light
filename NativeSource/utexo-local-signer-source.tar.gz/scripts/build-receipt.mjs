#!/usr/bin/env node
// This is a locally recorded build receipt, not an independent signed attestation.
import { execFileSync } from 'node:child_process';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { artifactTree, verifyArtifactTree } from './artifact-tree.mjs';

const core = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const workspace = resolve(core, '../..');
const [mode, platform, receiptPath, artifactRoot, ...extra] = process.argv.slice(2);
if (!['begin', 'finish', 'verify'].includes(mode) || !['apple', 'android'].includes(platform) ||
  !receiptPath || extra.length || (mode === 'finish' && !artifactRoot)) {
  throw new Error('usage: build-receipt.mjs begin|finish|verify apple|android RECEIPT [ARTIFACT_DIRECTORY]');
}
const sdk = resolve(workspace, platform === 'apple' ? 'rgb-sdk-swift-light' : 'rgb-sdk-kotlin-light');
const productionInputs = ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'uniffi.toml',
  'uniffi-bindgen.toml', 'src', 'scripts'];
const outputRoots = platform === 'apple' ? ['UtexoLocalSigner.xcframework'] : ['jniLibs'];
const run = (command, args) => execFileSync(command, args, { cwd: core, encoding: 'utf8' }).trim();
const input = () => ({
  core: artifactTree(core, productionInputs),
  binding: artifactTree(sdk, platform === 'apple' ? ['Generated'] :
    ['sdk/src/main/kotlin/com/utexo/rgb/sdk/internal/ffi']),
});
if (mode === 'begin') {
  const receipt = {
    schema: 'utexo.native-local-build.v1', platform,
    assurance: 'Locally observed build of possibly uncommitted source. Not a signed release, independent reproduction, or proof against a compromised compiler/dependency cache.',
    startedAt: new Date().toISOString(),
    tools: {
      rust: run('rustc', ['--version', '--verbose']), cargo: run('cargo', ['--version']),
      ...(platform === 'apple' ? { xcode: run('xcodebuild', ['-version']),
        clang: run('xcrun', ['clang', '--version']), swift: run('xcrun', ['swiftc', '--version']) } :
        { cargoNdk: run('cargo', ['ndk', '--version']), ndk: '28.2.13676358', api: 24 }),
    },
    flags: { rust: ['--remap-path-prefix=WORKSPACE=/utexo', '--remap-path-prefix=CARGO_HOME=/cargo'],
      c: ['-ffile-prefix-map=WORKSPACE=/utexo', '-ffile-prefix-map=CARGO_HOME=/cargo'],
      profile: 'Cargo.toml [profile.release]; --release --locked; inherited codegen overrides refused' },
    inputs: input(),
  };
  mkdirSync(dirname(resolve(receiptPath)), { recursive: true });
  writeFileSync(resolve(receiptPath), `${JSON.stringify(receipt, null, 2)}\n`, { flag: 'wx' });
} else {
  const receipt = JSON.parse(readFileSync(resolve(receiptPath), 'utf8'));
  if (receipt.schema !== 'utexo.native-local-build.v1' || receipt.platform !== platform ||
    JSON.stringify(input()) !== JSON.stringify(receipt.inputs)) {
    throw new Error('native build source/binding inputs changed; rebuild before recording or distributing artifacts');
  }
  if (mode === 'finish') {
    if (receipt.finishedAt) throw new Error('build receipt already finalized');
    receipt.outputs = artifactTree(resolve(artifactRoot), outputRoots);
    receipt.finishedAt = new Date().toISOString();
    writeFileSync(resolve(receiptPath), `${JSON.stringify(receipt, null, 2)}\n`);
  } else {
    if (!receipt.finishedAt || !Array.isArray(receipt.outputs)) throw new Error('unfinished native build');
    verifyArtifactTree(resolve(sdk, platform === 'apple' ? 'Artifacts' : 'sdk/src/main'), outputRoots, receipt.outputs);
    console.log(`${platform}: complete native artifact tree matches its local build input/output receipt`);
  }
}
