#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
CORE_DIR="$(cd -- "${SCRIPT_DIR}/.." && pwd)"
WORKSPACE_DIR="$(cd -- "${CORE_DIR}/../.." && pwd)"
cd "${CORE_DIR}"
source "${SCRIPT_DIR}/build-environment.sh"
utexo_check_build_environment
DESTINATION_PARENT="${WORKSPACE_DIR}/rgb-sdk-kotlin-light/sdk/src/main"
DESTINATION="${DESTINATION_PARENT}/jniLibs"
EXPECTED_CARGO_NDK_VERSION="4.1.2"
EXPECTED_NDK_VERSION="28.2.13676358"

if ! CARGO_NDK_OUTPUT="$(cargo ndk --version 2>/dev/null)"; then
  echo "cargo-ndk ${EXPECTED_CARGO_NDK_VERSION} is required" >&2
  exit 1
fi
if [[ "${CARGO_NDK_OUTPUT}" != "cargo-ndk ${EXPECTED_CARGO_NDK_VERSION}" ]]; then
  echo "expected cargo-ndk ${EXPECTED_CARGO_NDK_VERSION}, found: ${CARGO_NDK_OUTPUT}" >&2
  exit 1
fi

if [[ -n "${ANDROID_NDK_HOME:-}" ]]; then
  NDK_DIRECTORY="${ANDROID_NDK_HOME}"
elif [[ -n "${ANDROID_NDK_ROOT:-}" ]]; then
  NDK_DIRECTORY="${ANDROID_NDK_ROOT}"
elif [[ -n "${ANDROID_HOME:-}" ]]; then
  NDK_DIRECTORY="${ANDROID_HOME}/ndk/${EXPECTED_NDK_VERSION}"
elif [[ -n "${ANDROID_SDK_ROOT:-}" ]]; then
  NDK_DIRECTORY="${ANDROID_SDK_ROOT}/ndk/${EXPECTED_NDK_VERSION}"
else
  echo "set ANDROID_HOME, ANDROID_SDK_ROOT, or ANDROID_NDK_HOME" >&2
  exit 1
fi

NDK_PROPERTIES="${NDK_DIRECTORY}/source.properties"
if [[ ! -f "${NDK_PROPERTIES}" ]] || \
   ! grep -Eq "^Pkg\.Revision[[:space:]]*=[[:space:]]*${EXPECTED_NDK_VERSION}$" \
     "${NDK_PROPERTIES}"; then
  echo "Android NDK ${EXPECTED_NDK_VERSION} is required at ${NDK_DIRECTORY}" >&2
  exit 1
fi

mkdir -p "${DESTINATION_PARENT}"
STAGING_ROOT="$(mktemp -d "${DESTINATION_PARENT}/.jniLibs-stage.XXXXXX")"
STAGING="${STAGING_ROOT}/jniLibs"
node "${SCRIPT_DIR}/build-receipt.mjs" begin android "${STAGING_ROOT}/native-build.json"
BACKUP="${DESTINATION_PARENT}/.jniLibs-backup-$$"
BACKUP_ACTIVE=false

cleanup() {
  if [[ "${BACKUP_ACTIVE}" == true && ! -e "${DESTINATION}" && -e "${BACKUP}" ]]; then
    mv "${BACKUP}" "${DESTINATION}"
  fi
  rm -rf "${STAGING_ROOT}"
  if [[ "${BACKUP_ACTIVE}" == false && -e "${BACKUP}" ]]; then
    rm -rf "${BACKUP}"
  fi
}
trap cleanup EXIT

cd "${CORE_DIR}"
utexo_set_build_flags
ANDROID_NDK_HOME="${NDK_DIRECTORY}" cargo ndk \
  --target arm64-v8a \
  --target armeabi-v7a \
  --target x86_64 \
  --platform 24 \
  --output-dir "${STAGING}" \
  build --release --locked

for abi in arm64-v8a armeabi-v7a x86_64
do
  library="${STAGING}/${abi}/libutexo_local_signer.so"
  if [[ ! -s "${library}" ]]; then
    echo "missing staged native library for ${abi}" >&2
    exit 1
  fi
done
if [[ "$(rg --files "${STAGING}" -g libutexo_local_signer.so | wc -l | tr -d ' ')" != 3 ]]; then
  echo "staged native library set contains unexpected signer artifacts" >&2
  exit 1
fi

if [[ -e "${BACKUP}" ]]; then
  echo "refusing to replace artifacts while stale backup exists: ${BACKUP}" >&2
  exit 1
fi
node "${SCRIPT_DIR}/build-receipt.mjs" finish android "${STAGING_ROOT}/native-build.json" "${STAGING_ROOT}"
if [[ -e "${DESTINATION}" ]]; then
  mv "${DESTINATION}" "${BACKUP}"
  BACKUP_ACTIVE=true
fi
if ! mv "${STAGING}" "${DESTINATION}"; then
  if [[ "${BACKUP_ACTIVE}" == true ]]; then
    mv "${BACKUP}" "${DESTINATION}"
    BACKUP_ACTIVE=false
  fi
  exit 1
fi
if [[ "${BACKUP_ACTIVE}" == true ]]; then
  BACKUP_ACTIVE=false
  rm -rf "${BACKUP}"
fi
mkdir -p "${WORKSPACE_DIR}/rgb-sdk-kotlin-light/NativeSource"
mv "${STAGING_ROOT}/native-build.json" "${WORKSPACE_DIR}/rgb-sdk-kotlin-light/NativeSource/native-build.json"
