#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
CORE_DIR="$(cd -- "${SCRIPT_DIR}/.." && pwd)"

# Verify checked-in security inputs before embedding them. Advisory reports are
# point-in-time evidence; release CI must also perform a fresh online scan.
node "${SCRIPT_DIR}/security-inventory.mjs" --check
node "${SCRIPT_DIR}/source-archive.mjs"
node "${SCRIPT_DIR}/verify-source-archive.mjs"
node "${SCRIPT_DIR}/test-source-archive.mjs"
