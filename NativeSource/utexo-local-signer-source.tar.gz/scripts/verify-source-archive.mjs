#!/usr/bin/env node
// Independently decode with the platform tar implementation and compare bytes.
import { execFileSync } from 'node:child_process';
import { lstatSync, readFileSync, readdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const core = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const archive = resolve(process.argv[2] ?? resolve(core, '../../rgb-sdk-swift-light/NativeSource/utexo-local-signer-source.tar.gz'));
const paths = execFileSync('tar', ['-tzf', archive], { encoding: 'utf8' }).trimEnd().split('\n');
if (!paths.length || new Set(paths).size !== paths.length) throw new Error('empty or duplicate source entries');
const listing = execFileSync('tar', ['-tvzf', archive], { encoding: 'utf8' }).trimEnd().split('\n');
if (listing.length !== paths.length || listing.some(line => !line.startsWith('-'))) {
  throw new Error('archive must contain only regular files (no links/devices/directories)');
}
const expected = [];
function collect(path) {
  const stat = lstatSync(resolve(core, path));
  if (stat.isFile()) expected.push(path);
  else if (stat.isDirectory()) {
    for (const child of readdirSync(resolve(core, path))) collect(`${path}/${child}`);
  } else throw new Error(`nonregular source: ${path}`);
}
// Independently freeze the release scope, not merely a small required subset.
for (const path of ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'uniffi.toml',
  'uniffi-bindgen.toml', 'README.md', 'src', 'scripts', 'fixtures', 'assurance', 'examples',
  'fuzz/Cargo.toml', 'fuzz/Cargo.lock', 'fuzz/README.md', 'fuzz/fuzz_targets']) collect(path);
if (JSON.stringify(paths.toSorted()) !== JSON.stringify(expected.toSorted())) {
  throw new Error('source archive file set is incomplete or contains unexpected files');
}
for (const path of paths) {
  if (!/^[A-Za-z0-9_./-]+$/.test(path) || path.startsWith('/') || path.split('/').some(p => p === '..' || p === '.' || !p)) {
    throw new Error('unsafe archive entry');
  }
  const content = execFileSync('tar', ['-xOzf', archive, '--', path], { maxBuffer: 16 * 1024 * 1024 });
  if (!content.equals(readFileSync(resolve(core, path)))) throw new Error(`source archive mismatch: ${path}`);
}
console.log(`Independent tar decoder verified all ${paths.length} archived files against current source.`);
