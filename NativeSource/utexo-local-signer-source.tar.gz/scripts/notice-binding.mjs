// A release-tag supplement is explicitly weaker than an archived VCS identity:
// bind it to reviewed registry bytes and their declaration; never invent VCS data.
export function lockedRegistryChecksums(lockText) {
  const result = new Map();
  for (const block of lockText.split('[[package]]').slice(1)) {
    const value = name => new RegExp(`^${name} = "([^"\\r\\n]+)"$`, 'm').exec(block)?.[1];
    const source = value('source');
    if (!source) continue;
    if (source !== 'registry+https://github.com/rust-lang/crates.io-index') {
      throw new Error('notice binding requires reviewed crates.io sources');
    }
    const name = value('name'), version = value('version'), checksum = value('checksum');
    if (!name || !version || !/^[a-f0-9]{64}$/.test(checksum ?? '')) throw new Error('invalid registry lock identity');
    const id = `${name}@${version}`;
    if (result.has(id)) throw new Error('duplicate registry lock identity');
    result.set(id, checksum);
  }
  if (!result.size) throw new Error('empty registry lock graph');
  return result;
}

export function verifyRegistryNoticeBinding(notice, pkg, checksums) {
  const binding = notice.registryRelease;
  const id = `${pkg.name}@${pkg.version}`;
  if (!binding || typeof binding.tag !== 'string' || !binding.tag ||
    binding.declaredLicense !== pkg.license || !binding.checksums ||
    Object.keys(binding.checksums).sort().join('\n') !== [...notice.packages].sort().join('\n') ||
    !/^[a-f0-9]{64}$/.test(binding.checksums[id] ?? '') ||
    checksums.get(id) !== binding.checksums[id]) {
    throw new Error(`supplement registry identity or license changed: ${id}`);
  }
}
