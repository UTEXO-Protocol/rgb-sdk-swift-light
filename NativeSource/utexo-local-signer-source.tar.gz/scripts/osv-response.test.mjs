import assert from 'node:assert/strict';
import test from 'node:test';
import { validatedOsvResults } from './osv-response.mjs';

test('valid empty and populated results remain aligned to queries', () => {
  const data = { results: [{}, { vulns: [] }, { vulns: [{ id: 'GHSA-abcd-1234-wxyz' }] }] };
  assert.equal(validatedOsvResults(data, 3), data.results);
  assert.deepEqual(validatedOsvResults({ results: [{ next_page_token: '' }] }, 1), [{ next_page_token: '' }]);
});
test('missing, malformed and partial batches never count as clean', () => {
  for (const value of [undefined, null, false, 'unexpected', 1, [], {}, { results: [] }, { results: {} },
    { results: [{}, {}] }]) assert.throws(() => validatedOsvResults(value, 1));
});
test('primitive, array and null per-package results are rejected', () => {
  for (const value of [null, undefined, 'unexpected', 1, 0, false, true, [], [{}]]) {
    assert.throws(() => validatedOsvResults({ results: [value] }, 1));
  }
});
test('pagination or malformed vulnerability collections cannot hide findings', () => {
  for (const value of ['next', null, 0, false, [], {}]) {
    assert.throws(() => validatedOsvResults({ results: [{ next_page_token: value }] }, 1));
  }
  for (const value of [null, {}, 'none', 0, false]) {
    assert.throws(() => validatedOsvResults({ results: [{ vulns: value }] }, 1));
  }
});
test('advisory records require a safe nonempty ID', () => {
  for (const value of [null, [], 1, '', {}, { id: '' }, { id: 1 }, { id: 'unsafe/path' }, { id: 'x\ny' }]) {
    assert.throws(() => validatedOsvResults({ results: [{ vulns: [value] }] }, 1));
  }
});
