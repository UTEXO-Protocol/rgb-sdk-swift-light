FROM rust:1.88-bookworm@sha256:af306cfa71d987911a781c37b59d7d67d934f49684058f96cf72079c3626bfe0
RUN rustup component add --toolchain 1.88.0 clippy rustfmt
ENV RUSTUP_TOOLCHAIN=1.88.0
WORKDIR /source
