#!/usr/bin/env node
// Only stateless decoder/finalizer RPCs. No wallet/address generation, funding,
// blockchain mutation, mempool submission, service restart or network broadcast.
import { execFileSync } from 'node:child_process';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';

const core = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const backend = resolve(core, '../../rgb-lightning-node');
const cases = execFileSync('cargo', ['run', '--quiet', '--locked', '--example', 'core-differential'],
  { cwd: core, encoding: 'utf8', maxBuffer: 8 * 1024 * 1024 }).trim().split('\n').map(line => JSON.parse(line));
assert.equal(cases.length, 128);
function rpc(method, argument) {
  assert.ok(['decodepsbt', 'finalizepsbt', 'decoderawtransaction'].includes(method));
  const args = ['compose', '-f', 'compose.minimal-gateway.local.yaml', 'exec', '-T', 'bitcoind',
    'bitcoin-cli', '-regtest', '-rpcuser=user', '-rpcpassword=password', '-stdin', method];
  return JSON.parse(execFileSync('docker', args, {
    cwd: backend, input: `${argument}\n`, encoding: 'utf8', timeout: 15_000, maxBuffer: 2 * 1024 * 1024,
  }));
}
for (const item of cases) {
  const decodedPsbt = rpc('decodepsbt', item.psbt);
  // Core prints BTC JSON numerals; compare integer satoshis only inside this
  // synthetic bounded test corpus, not in production financial deserialization.
  assert.equal(Math.round(decodedPsbt.fee * 100_000_000), item.feeSats, `case ${item.case}: fee`);
  const finalized = rpc('finalizepsbt', item.psbt);
  assert.equal(finalized.complete, true);
  assert.equal(finalized.hex, item.raw, `case ${item.case}: independent extraction`);
  const decoded = rpc('decoderawtransaction', finalized.hex);
  assert.equal(decoded.txid, item.txid);
  assert.equal(decoded.vsize, item.vsize);
  assert.equal(decoded.weight, item.weight);
  assert.equal(decoded.vin.length, item.inputs);
  assert.equal(decoded.vout.length, item.outputs.length);
  for (let i = 0; i < item.outputs.length; i++) {
    assert.equal(Math.round(decoded.vout[i].value * 100_000_000), item.outputs[i].valueSats);
    assert.equal(decoded.vout[i].scriptPubKey.hex, item.outputs[i].script);
  }
  assert.ok(decoded.vin.every(input => input.txinwitness.length === 1 && input.scriptSig.hex === ''));
}
console.log(`Bitcoin Core independently decoded/extracted ${cases.length} signed synthetic transactions: exact txid, weight/vsize, inputs, witness shape, output scripts/amounts and fee agree. No consensus signature-validation or funded transaction claim.`);
