#!/usr/bin/env node
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { verifyArtifactTree } from './artifact-tree.mjs';

const [directory, ...extra] = process.argv.slice(2);
if (!directory || extra.length) throw new Error('usage: verify-artifacts.mjs SDK_DIRECTORY');
const root = resolve(directory);
const manifest = JSON.parse(readFileSync(resolve(root, 'NativeSource/artifact-manifest.json'), 'utf8'));
if (manifest.schema !== 'utexo.packaged-native-artifacts.v1' ||
  !Array.isArray(manifest.roots) || !Array.isArray(manifest.files)) {
  throw new Error('invalid artifact manifest');
}
verifyArtifactTree(root, manifest.roots, manifest.files);
console.log(`Verified complete file sets and content of ${manifest.roots.length} declared artifact roots (${manifest.files.length} files).`);
