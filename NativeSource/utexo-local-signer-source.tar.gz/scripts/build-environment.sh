#!/usr/bin/env bash
# Sourced by native artifact builders, never by ordinary developer/test builds.
# A release must not silently inherit caller-selected compilers or codegen flags.
utexo_check_build_environment() {
  local variable value
  while IFS= read -r variable; do
    case "${variable}" in
      RUSTFLAGS|CARGO_ENCODED_RUSTFLAGS|RUSTDOCFLAGS|CARGO_ENCODED_RUSTDOCFLAGS|RUSTC|RUSTDOC|RUSTC_WRAPPER|RUSTC_WORKSPACE_WRAPPER|CARGO_BUILD_TARGET|CARGO_BUILD_RUSTFLAGS|CARGO_TARGET_DIR|CARGO_PROFILE_*|CARGO_TARGET_*_LINKER|CARGO_TARGET_*_RUSTFLAGS|CC|CC_*|CXX|CXX_*|AR|AR_*|RANLIB|RANLIB_*|CFLAGS|CFLAGS_*|CXXFLAGS|CXXFLAGS_*|CPPFLAGS|CPPFLAGS_*|LDFLAGS|LDFLAGS_*|SDKROOT)
        value="${!variable}"
        if [[ -n "${value}" ]]; then
          echo "release build refuses ambient override ${variable}; use the reviewed build scripts" >&2
          return 1
        fi
        ;;
    esac
  done < <(compgen -e)
  if [[ "$(rustc --version)" != 'rustc 1.88.0 (6b00bc388 2025-06-23)' ]]; then
    echo 'release build requires pinned Rust 1.88.0' >&2
    return 1
  fi
}

utexo_set_build_flags() {
  # Every permitted flag is literal and retained in the build receipt. Use the
  # caller's Cargo cache location only for path remapping, never custom codegen.
  export RUSTFLAGS="--remap-path-prefix=${WORKSPACE_DIR}=/utexo --remap-path-prefix=${CARGO_HOME:-${HOME}/.cargo}=/cargo"
  export CFLAGS="-ffile-prefix-map=${WORKSPACE_DIR}=/utexo -ffile-prefix-map=${CARGO_HOME:-${HOME}/.cargo}=/cargo"
}
