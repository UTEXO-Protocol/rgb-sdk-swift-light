#!/usr/bin/env node
// Source/build dependency inventory, not a vulnerability scan or license determination.
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { artifactTree } from './artifact-tree.mjs';

const core = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const workspace = resolve(core, '../..');
const arguments_ = process.argv.slice(2);
if (arguments_.length !== 0 &&
    (arguments_.length !== 2 || arguments_[0] !== '--platform' ||
     !['swift', 'kotlin'].includes(arguments_[1]))) {
  throw new Error('usage: package-provenance.mjs [--platform swift|kotlin]');
}
const selectedPlatform = arguments_[1];
const sha256 = path => createHash('sha256').update(readFileSync(path)).digest('hex');
const compare = (a, b) => a < b ? -1 : a > b ? 1 : 0;
const metadata = JSON.parse(execFileSync('cargo', [
  'metadata', '--all-features', '--offline', '--locked', '--format-version', '1',
], { cwd: core, encoding: 'utf8', maxBuffer: 8 * 1024 * 1024 }));
const inventory = {
  schema: 'utexo.native-source-inventory.v1',
  scope: 'Production-crate Cargo metadata all-feature graph, including build/test/bindgen and all-platform dependencies; excludes the separately locked, non-shipping fuzz harness and is not solely runtime-linked code.',
  cargoLockSha256: sha256(resolve(core, 'Cargo.lock')),
  packages: metadata.packages.map(p => ({
    name: p.name, version: p.version, declaredLicense: p.license,
    repository: p.repository,
    source: p.source ?? 'bundled-source',
  })).sort((a, b) => compare(a.name, b.name) || compare(a.version, b.version)),
};
const platforms = [
  ['rgb-sdk-swift-light', [
    'Generated', 'Artifacts/UtexoLocalSigner.xcframework', 'Artifacts/RGBSDK.xcframework',
    'NativeSource/native-build.json', 'NativeSource/facade-build.json',
  ]],
  ['rgb-sdk-kotlin-light', [
    'sdk/src/main/kotlin/com/utexo/rgb/sdk/internal/ffi', 'sdk/src/main/jniLibs',
    'NativeSource/native-build.json',
  ]],
];
for (const [repository, artifacts] of platforms) {
  // Each distribution may be rebuilt independently. Never record the other
  // platform's stale outputs merely to unblock a local package verification.
  if (selectedPlatform && repository !== `rgb-sdk-${selectedPlatform}-light`) continue;
  const directory = resolve(workspace, repository);
  execFileSync(process.execPath, [resolve(core, 'scripts/build-receipt.mjs'), 'verify',
    repository.includes('swift') ? 'apple' : 'android', resolve(directory, 'NativeSource/native-build.json')],
  { stdio: 'inherit' });
  if (repository.includes('swift')) {
    execFileSync(process.execPath, [resolve(directory, 'Scripts/facade-provenance.mjs'), '--check'], { stdio: 'inherit' });
  }
  mkdirSync(resolve(directory, 'NativeSource'), { recursive: true });
  writeFileSync(resolve(directory, 'NativeSource/dependencies.json'), JSON.stringify(inventory, null, 2) + '\n');
  const securityFiles = ['native-source.cdx.json', 'THIRD_PARTY_RUST_NOTICES.md', 'license-review.json', 'advisories.json'];
  for (const name of securityFiles) {
    writeFileSync(resolve(directory, 'NativeSource', name), readFileSync(resolve(core, 'assurance', name)));
  }
  const roots = ['NativeSource/utexo-local-signer-source.tar.gz', 'NativeSource/dependencies.json',
    ...securityFiles.map(name => `NativeSource/${name}`), ...artifacts];
  const completeTree = artifactTree(directory, roots);
  const manifestPath = 'NativeSource/artifact-manifest.json';
  writeFileSync(resolve(directory, manifestPath), `${JSON.stringify({
    schema: 'utexo.packaged-native-artifacts.v1',
    scope: 'Complete file sets of the listed native/binding/facade/source/receipt roots. Not a signed release or a checksum of a final app, remote Maven archive or entire Git repository.',
    roots, files: completeTree,
  }, null, 2)}\n`);
  const files = [...completeTree.map(file => file.path), manifestPath];
  writeFileSync(resolve(directory, 'NativeSource/SHA256SUMS'),
    files.map(file => `${sha256(resolve(directory, file))}  ${file}`).join('\n') + '\n');
  console.log(`${repository}: complete native/binding/facade trees and local build receipts recorded (${files.length} files)`);
}
