#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
CORE_DIR="$(cd -- "${SCRIPT_DIR}/.." && pwd)"
WORKSPACE_DIR="$(cd -- "${CORE_DIR}/../.." && pwd)"
cd "${CORE_DIR}"
source "${SCRIPT_DIR}/build-environment.sh"
utexo_check_build_environment
if [[ "$(xcodebuild -version)" != $'Xcode 27.0\nBuild version 27A266a' ]]; then
  echo 'release build requires reviewed Xcode 27.0 (27A266a)' >&2
  exit 1
fi
OUTPUT_PARENT="${WORKSPACE_DIR}/rgb-sdk-swift-light/Artifacts"
OUTPUT="${OUTPUT_PARENT}/UtexoLocalSigner.xcframework"
mkdir -p "${OUTPUT_PARENT}"
TEMP_DIR="$(mktemp -d "${OUTPUT_PARENT}/.xcframework-stage.XXXXXX")"
BACKUP="${TEMP_DIR}/previous.xcframework"
node "${SCRIPT_DIR}/build-receipt.mjs" begin apple "${TEMP_DIR}/native-build.json"
cleanup() {
  if [[ ! -e "${OUTPUT}" && -d "${BACKUP}" ]]; then
    mv "${BACKUP}" "${OUTPUT}"
  fi
  rm -rf "${TEMP_DIR}"
}
trap cleanup EXIT

# Keep developer paths out of both Rust and libsecp256k1 build artifacts.
utexo_set_build_flags

cd "${CORE_DIR}"

# Freeze deployment targets to the native package contract. In particular,
# libsecp256k1's C build must not silently inherit the build host's OS version.
for target in aarch64-apple-darwin x86_64-apple-darwin
do
  MACOSX_DEPLOYMENT_TARGET=13.0 \
    cargo build --release --locked --target "${target}"
done
for target in aarch64-apple-ios aarch64-apple-ios-sim x86_64-apple-ios
do
  IPHONEOS_DEPLOYMENT_TARGET=15.0 \
    cargo build --release --locked --target "${target}"
done

mkdir -p \
  "${TEMP_DIR}/Headers" \
  "${TEMP_DIR}/Libraries/macos" \
  "${TEMP_DIR}/Libraries/ios" \
  "${TEMP_DIR}/Libraries/simulator" \
  "$(dirname -- "${OUTPUT}")"
cp "${WORKSPACE_DIR}/rgb-sdk-swift-light/Generated/UtexoLocalSignerFFI.h" "${TEMP_DIR}/Headers/"
cp \
  "${WORKSPACE_DIR}/rgb-sdk-swift-light/Generated/UtexoLocalSignerFFI.modulemap" \
  "${TEMP_DIR}/Headers/module.modulemap"

cp target/aarch64-apple-darwin/release/libutexo_local_signer.a \
  "${TEMP_DIR}/Libraries/macos/libutexo_local_signer-arm64.a"
cp target/x86_64-apple-darwin/release/libutexo_local_signer.a \
  "${TEMP_DIR}/Libraries/macos/libutexo_local_signer-x86_64.a"
cp target/aarch64-apple-ios/release/libutexo_local_signer.a \
  "${TEMP_DIR}/Libraries/ios/libutexo_local_signer.a"
cp target/aarch64-apple-ios-sim/release/libutexo_local_signer.a \
  "${TEMP_DIR}/Libraries/simulator/libutexo_local_signer-arm64.a"
cp target/x86_64-apple-ios/release/libutexo_local_signer.a \
  "${TEMP_DIR}/Libraries/simulator/libutexo_local_signer-x86_64.a"

# Static archives are dead-stripped again by the application linker; this
# stripping only removes build/debug symbols from the distributed artifact.
strip -S -x \
  "${TEMP_DIR}/Libraries/macos/libutexo_local_signer-arm64.a" \
  "${TEMP_DIR}/Libraries/macos/libutexo_local_signer-x86_64.a" \
  "${TEMP_DIR}/Libraries/ios/libutexo_local_signer.a" \
  "${TEMP_DIR}/Libraries/simulator/libutexo_local_signer-arm64.a" \
  "${TEMP_DIR}/Libraries/simulator/libutexo_local_signer-x86_64.a"
lipo -create \
  "${TEMP_DIR}/Libraries/macos/libutexo_local_signer-arm64.a" \
  "${TEMP_DIR}/Libraries/macos/libutexo_local_signer-x86_64.a" \
  -output "${TEMP_DIR}/Libraries/macos/libutexo_local_signer.a"
lipo -create \
  "${TEMP_DIR}/Libraries/simulator/libutexo_local_signer-arm64.a" \
  "${TEMP_DIR}/Libraries/simulator/libutexo_local_signer-x86_64.a" \
  -output "${TEMP_DIR}/Libraries/simulator/libutexo_local_signer.a"

xcodebuild -create-xcframework \
  -library "${TEMP_DIR}/Libraries/macos/libutexo_local_signer.a" -headers "${TEMP_DIR}/Headers" \
  -library "${TEMP_DIR}/Libraries/ios/libutexo_local_signer.a" -headers "${TEMP_DIR}/Headers" \
  -library "${TEMP_DIR}/Libraries/simulator/libutexo_local_signer.a" -headers "${TEMP_DIR}/Headers" \
  -output "${TEMP_DIR}/UtexoLocalSigner.xcframework"

# Do not remove the previous usable artifact until every slice is complete.
plutil -lint "${TEMP_DIR}/UtexoLocalSigner.xcframework/Info.plist"
node "${SCRIPT_DIR}/build-receipt.mjs" finish apple "${TEMP_DIR}/native-build.json" "${TEMP_DIR}"
if [[ -e "${OUTPUT}" ]]; then
  mv "${OUTPUT}" "${BACKUP}"
fi
mv "${TEMP_DIR}/UtexoLocalSigner.xcframework" "${OUTPUT}"
mkdir -p "${WORKSPACE_DIR}/rgb-sdk-swift-light/NativeSource"
mv "${TEMP_DIR}/native-build.json" "${WORKSPACE_DIR}/rgb-sdk-swift-light/NativeSource/native-build.json"
