import { execFileSync, spawnSync } from 'node:child_process';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';
import test from 'node:test';

const scripts = dirname(fileURLToPath(import.meta.url));
const core = resolve(scripts, '..');
const command = 'source "$1"; utexo_check_build_environment';
const args = ['-c', command, 'build-environment-test', resolve(scripts, 'build-environment.sh')];
const cleanEnvironment = Object.fromEntries(Object.entries(process.env).filter(([name]) =>
  !/^(RUSTFLAGS|CARGO_ENCODED_RUSTFLAGS|RUSTDOCFLAGS|CARGO_ENCODED_RUSTDOCFLAGS|RUSTC|RUSTDOC|RUSTC_WRAPPER|RUSTC_WORKSPACE_WRAPPER|CARGO_BUILD_TARGET|CARGO_BUILD_RUSTFLAGS|CARGO_TARGET_DIR|CARGO_PROFILE_|CARGO_TARGET_.*_(LINKER|RUSTFLAGS)|CC($|_)|CXX($|_)|AR($|_)|RANLIB($|_)|CFLAGS($|_)|CXXFLAGS($|_)|CPPFLAGS($|_)|LDFLAGS($|_)|SDKROOT$)/.test(name)));
test('pinned toolchain and ordinary environment are accepted', () => {
  execFileSync('bash', args, { cwd: core, env: cleanEnvironment });
});
test('code generation and compiler injection are refused without printing values', () => {
  for (const variable of ['RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER',
    'CARGO_TARGET_DIR', 'CARGO_PROFILE_RELEASE_PANIC', 'CARGO_TARGET_AARCH64_APPLE_IOS_LINKER',
    'CFLAGS', 'CC_aarch64_apple_ios', 'CPPFLAGS', 'SDKROOT']) {
    const result = spawnSync('bash', args, {
      cwd: core, encoding: 'utf8', env: { ...cleanEnvironment, [variable]: 'audit-secret-do-not-log' },
    });
    assert.notEqual(result.status, 0, variable);
    assert.match(result.stderr, new RegExp(variable), variable);
    assert.ok(!`${result.stdout}${result.stderr}`.includes('audit-secret-do-not-log'), variable);
  }
});
