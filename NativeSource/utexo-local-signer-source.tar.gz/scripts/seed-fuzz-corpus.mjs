#!/usr/bin/env node
// Populate a caller-owned diagnostic corpus without deleting or replacing files.
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, isAbsolute, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const destination = process.argv[2];
if (!destination || process.argv.length !== 3 || !isAbsolute(destination)) {
  throw new Error('usage: seed-fuzz-corpus.mjs ABSOLUTE_DESTINATION_DIRECTORY');
}
const core = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const fixture = JSON.parse(readFileSync(resolve(core, 'fixtures/native-signing-multi-smoke.json'), 'utf8'));
const seeds = new Map([
  ['psbt_bytes/valid-two-input.psbt', Buffer.from(fixture.psbt, 'base64')],
  ['key_material/valid-mnemonic.txt', Buffer.from(fixture.mnemonic, 'utf8')],
  ['key_material/valid-seed-length.bin', Buffer.alloc(64, 7)],
]);
// Reach all three gateway operation profiles and structured/context mutation
// branches immediately; mode zero is a positive untouched-fixture control.
for (let operation = 0; operation < 3; operation++) {
  for (let mode = 0; mode < 18; mode++) {
    const seed = Buffer.alloc(10);
    seed[0] = operation;
    seed[1] = mode;
    seed.writeBigUInt64LE(110n, 2);
    seeds.set(`gateway_psbt/${operation}-${mode}.bin`, seed);
  }
}
const invoiceFixtures = resolve(core, 'fixtures/upstream/rgb-invoice-0.11.1-rc.11.json');
try {
  const invoices = JSON.parse(readFileSync(invoiceFixtures, 'utf8'));
  for (const entry of [...invoices.accepted, ...invoices.rejected.filter(item => item.upstreamAccepts)]) {
    seeds.set(`rgb_invoice/${entry.name}.txt`, Buffer.from(entry.invoice, 'utf8'));
  }
} catch (error) {
  if (error?.code !== 'ENOENT') throw error;
}
for (const [path, bytes] of seeds) {
  const directory = resolve(destination, path.split('/')[0]);
  mkdirSync(directory, { recursive: true });
  const name = createHash('sha256').update(bytes).digest('hex');
  try { writeFileSync(resolve(directory, name), bytes, { flag: 'wx' }); }
  catch (error) { if (error?.code !== 'EEXIST') throw error; }
}
console.log(`Prepared ${seeds.size} immutable public-test fuzz seeds under ${destination}.`);
