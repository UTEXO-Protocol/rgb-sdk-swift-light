import assert from 'node:assert/strict';
import test from 'node:test';
import { lockedRegistryChecksums, verifyRegistryNoticeBinding } from './notice-binding.mjs';
const checksum = 'a'.repeat(64);
const lock = `version = 4\n\n[[package]]\nname = "fixture"\nversion = "1.0.0"\nsource = "registry+https://github.com/rust-lang/crates.io-index"\nchecksum = "${checksum}"\n`;
test('registry identity parsing refuses incomplete, non-registry and duplicate input', () => {
  assert.deepEqual([...lockedRegistryChecksums(lock)], [['fixture@1.0.0', checksum]]);
  for (const invalid of ['', lock + lock, lock.replace(checksum, 'f'),
    lock.replace('registry+https://github.com/rust-lang/crates.io-index', 'git+https://example.invalid/')]) {
    assert.throws(() => lockedRegistryChecksums(invalid));
  }
});
test('notice supplement must match exact package version, checksum, and license', () => {
  const pkg = { name: 'fixture', version: '1.0.0', license: 'CC0-1.0' };
  const notice = { packages: ['fixture@1.0.0'], registryRelease: {
    tag: 'fixture-1.0.0', declaredLicense: 'CC0-1.0', checksums: { 'fixture@1.0.0': checksum },
  } };
  const checksums = lockedRegistryChecksums(lock);
  verifyRegistryNoticeBinding(notice, pkg, checksums);
  for (const changed of [{ ...pkg, license: 'MIT' }, { ...pkg, version: '2.0.0' }]) {
    assert.throws(() => verifyRegistryNoticeBinding(notice, changed, checksums));
  }
  assert.throws(() => verifyRegistryNoticeBinding(notice, pkg, new Map([['fixture@1.0.0', 'b'.repeat(64)]])));
  assert.throws(() => verifyRegistryNoticeBinding({ ...notice, packages: [] }, pkg, checksums));
});
