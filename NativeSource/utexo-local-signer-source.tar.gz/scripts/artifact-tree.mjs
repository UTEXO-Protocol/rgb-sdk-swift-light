import { createHash } from 'node:crypto';
import { lstatSync, readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';

// Release inputs/outputs are regular files only. In particular, don't silently
// omit hidden files, headers, module maps or follow links outside the artifact.
export function artifactTree(directory, roots) {
  const files = [];
  function visit(path) {
    if (!path || path.startsWith('/') || path.split('/').some(part => !part || part === '.' || part === '..')) {
      throw new Error('invalid artifact-relative path');
    }
    const absolute = join(directory, path);
    const stat = lstatSync(absolute);
    if (stat.isDirectory()) {
      for (const child of readdirSync(absolute).sort()) visit(`${path}/${child}`);
    } else if (stat.isFile()) {
      const bytes = readFileSync(absolute);
      files.push({ path, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') });
    } else {
      throw new Error(`nonregular release artifact: ${path}`);
    }
  }
  for (const root of roots) visit(root);
  files.sort((a, b) => a.path < b.path ? -1 : a.path > b.path ? 1 : 0);
  if (!files.length || new Set(files.map(file => file.path)).size !== files.length) {
    throw new Error('empty or overlapping artifact roots');
  }
  return files;
}

export function verifyArtifactTree(directory, roots, expected) {
  const actual = artifactTree(directory, roots);
  if (JSON.stringify(actual) !== JSON.stringify(expected)) {
    throw new Error('artifact file set or content differs from the recorded build');
  }
  return actual;
}
