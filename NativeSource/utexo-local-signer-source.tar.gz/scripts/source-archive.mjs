#!/usr/bin/env node
// Fixed-order POSIX ustar archive with normalized metadata. Byte reproducibility
// also requires identical source bytes and the same Node/zlib build runtime.
// The explicit source scope is not a substitute for reviewing its contents.
import { createHash } from 'node:crypto';
import { lstatSync, mkdirSync, readFileSync, readdirSync, renameSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { gzipSync } from 'node:zlib';

const core = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const workspace = resolve(core, '../..');
const entries = [];
function collect(path) {
  if (path.split('/').some(part => part.startsWith('.') || ['target', 'build', 'node_modules'].includes(part))) {
    throw new Error(`unexpected hidden/build source entry: ${path}`);
  }
  const file = join(core, path);
  const stat = lstatSync(file);
  if (stat.isDirectory()) {
    for (const child of readdirSync(file).sort()) collect(`${path}/${child}`);
  } else if (stat.isFile()) {
    if (!/^[A-Za-z0-9_./-]+$/.test(path) || Buffer.byteLength(path) > 100) throw new Error(`non-ustar source path: ${path}`);
    const data = readFileSync(file);
    if (data.length > 16_000_000) throw new Error(`unexpected oversized source: ${path}`);
    entries.push({ path, data, mode: /^scripts\/.*\.(sh|mjs)$/.test(path) ? 0o755 : 0o644 });
  } else {
    throw new Error(`refusing nonregular source entry: ${path}`);
  }
}
for (const entry of [
  'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'uniffi.toml',
  'uniffi-bindgen.toml', 'README.md', 'src', 'scripts', 'fixtures', 'assurance', 'examples',
  'fuzz/Cargo.toml', 'fuzz/Cargo.lock', 'fuzz/README.md', 'fuzz/fuzz_targets',
]) collect(entry);
entries.sort((a, b) => a.path < b.path ? -1 : a.path > b.path ? 1 : 0);
const chunks = [];
function octal(header, value, offset, length) {
  const text = value.toString(8).padStart(length - 1, '0');
  if (text.length !== length - 1) throw new Error('ustar numeric overflow');
  header.write(`${text}\0`, offset, length, 'ascii');
}
for (const { path, data, mode } of entries) {
  const header = Buffer.alloc(512);
  header.write(path, 0, 100, 'ascii');
  octal(header, mode, 100, 8);
  octal(header, 0, 108, 8); // uid
  octal(header, 0, 116, 8); // gid
  octal(header, data.length, 124, 12);
  octal(header, 0, 136, 12); // fixed epoch, not workstation mtime
  header.fill(0x20, 148, 156);
  header[156] = 0x30; // regular file; parent dirs created by extractor
  header.write('ustar\0', 257, 6, 'ascii');
  header.write('00', 263, 2, 'ascii');
  header.write('root', 265, 32, 'ascii');
  header.write('root', 297, 32, 'ascii');
  const checksum = header.reduce((sum, byte) => sum + byte, 0);
  header.write(`${checksum.toString(8).padStart(6, '0')}\0 `, 148, 8, 'ascii');
  chunks.push(header, data, Buffer.alloc((512 - data.length % 512) % 512));
}
chunks.push(Buffer.alloc(1024));
const archive = gzipSync(Buffer.concat(chunks), { level: 9 });
for (const repository of ['rgb-sdk-swift-light', 'rgb-sdk-kotlin-light']) {
  const destination = join(workspace, repository, 'NativeSource');
  mkdirSync(destination, { recursive: true });
  const path = join(destination, 'utexo-local-signer-source.tar.gz');
  const pending = `${path}.pending-${process.pid}`;
  writeFileSync(pending, archive, { flag: 'wx' });
  renameSync(pending, path);
}
console.log(`${entries.length} files; ${archive.length} bytes; SHA256 ${createHash('sha256').update(archive).digest('hex')}`);
