#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
CORE_DIR="$(cd -- "${SCRIPT_DIR}/.." && pwd)"
WORKSPACE_DIR="$(cd -- "${CORE_DIR}/../.." && pwd)"

cd "${CORE_DIR}"
cargo build --locked --features bindgen --bin uniffi-bindgen
cargo build --locked --lib

target/debug/uniffi-bindgen generate \
  --config uniffi-bindgen.toml \
  target/debug/libutexo_local_signer.dylib \
  --language swift \
  --out-dir "${WORKSPACE_DIR}/rgb-sdk-swift-light/Generated"

"${WORKSPACE_DIR}/rgb-sdk-swift-light/Scripts/restrict-generated-swift-api.sh" \
  "${WORKSPACE_DIR}/rgb-sdk-swift-light/Generated/UtexoLocalSignerBindings.swift"

target/debug/uniffi-bindgen generate \
  --config uniffi-bindgen.toml \
  target/debug/libutexo_local_signer.dylib \
  --language kotlin \
  --no-format \
  --out-dir "${WORKSPACE_DIR}/rgb-sdk-kotlin-light/sdk/src/main/kotlin"
