#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
CORE_DIR="$(cd -- "${SCRIPT_DIR}/.." && pwd)"

cd "${CORE_DIR}"
cargo fmt --check
cargo clippy --all-targets --locked -- -D warnings
cargo test --locked
node --test \
  scripts/artifact-tree.test.mjs \
  scripts/build-environment.test.mjs \
  scripts/notice-binding.test.mjs \
  scripts/osv-response.test.mjs
node scripts/security-inventory.mjs --check
