// Shared fail-closed boundary for the public OSV batch response schema.
export function validatedOsvResults(data, expectedLength) {
  const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
  if (!Number.isSafeInteger(expectedLength) || expectedLength < 1 ||
      !object(data) || !Array.isArray(data.results) || data.results.length !== expectedLength) {
    throw new Error('incomplete OSV batch response; no clean scan may be inferred');
  }
  for (const result of data.results) {
    if (!object(result) ||
        (result.next_page_token !== undefined && result.next_page_token !== '') ||
        (result.vulns !== undefined && !Array.isArray(result.vulns))) {
      throw new Error('malformed or paginated OSV result; requires explicit follow-up');
    }
    for (const advisory of result.vulns ?? []) {
      if (!object(advisory) || typeof advisory.id !== 'string' || !/^[A-Za-z0-9_.-]+$/.test(advisory.id)) {
        throw new Error('invalid OSV advisory record');
      }
    }
  }
  return data.results;
}
