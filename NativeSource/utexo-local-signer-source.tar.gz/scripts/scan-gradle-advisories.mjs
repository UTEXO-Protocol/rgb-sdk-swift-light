#!/usr/bin/env node
// Scan exact Maven coordinates in a Gradle lockfile. Only public coordinates
// and versions are transmitted; never source files, auth, or wallet state.
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { validatedOsvResults } from './osv-response.mjs';

const [lockPath, outputPath, ...extra] = process.argv.slice(2);
if (!lockPath || !outputPath || extra.length) throw new Error('usage: scan-gradle-advisories.mjs LOCKFILE OUTPUT_JSON');
const bytes = readFileSync(resolve(lockPath));
const packages = [];
for (const line of bytes.toString('utf8').split(/\r?\n/)) {
  if (!line || line.startsWith('#') || line.startsWith('empty=')) continue;
  const match = /^([^:=\s]+):([^:=\s]+):([^=\s]+)=(.+)$/.exec(line);
  if (!match) throw new Error('unrecognized Gradle lock entry; scan is incomplete');
  packages.push({
    package: { name: `${match[1]}:${match[2]}`, ecosystem: 'Maven' },
    version: match[3], configurations: match[4].split(','),
  });
}
if (!packages.length) throw new Error('empty dependency graph');
const findings = [];
for (let offset = 0; offset < packages.length; offset += 64) {
  const batch = packages.slice(offset, offset + 64);
  const response = await fetch('https://api.osv.dev/v1/querybatch', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ queries: batch.map(({ package: p, version }) => ({ package: p, version })) }),
    signal: AbortSignal.timeout(30_000),
  });
  if (!response.ok) throw new Error(`OSV failed: HTTP ${response.status}; no clean scan may be inferred`);
  const results = validatedOsvResults(await response.json(), batch.length);
  for (let index = 0; index < batch.length; index++) {
    const result = results[index];
    for (const advisory of result.vulns ?? []) {
      findings.push({ ...batch[index], advisory: advisory.id, modified: advisory.modified });
    }
  }
}
const report = {
  schema: 'utexo.gradle-advisory-scan.v1', checkedAt: new Date().toISOString(),
  source: 'https://api.osv.dev/v1/querybatch',
  lockfileSha256: createHash('sha256').update(bytes).digest('hex'),
  scope: 'All Maven versions in this lockfile, including tests/tools. Does not cover unrecorded plugin graphs, the Android OS, Rust, or unpublished advisories.',
  queriedPackages: packages.length, packages, findings,
  status: findings.length ? 'review-required' : 'no-advisories-returned',
};
mkdirSync(dirname(resolve(outputPath)), { recursive: true });
writeFileSync(resolve(outputPath), `${JSON.stringify(report, null, 2)}\n`);
console.log(`OSV Maven: ${packages.length} exact dependencies; ${findings.length} matches.`);
if (findings.length) process.exitCode = 2;
