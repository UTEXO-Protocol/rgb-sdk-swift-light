import { mkdtempSync, mkdirSync, writeFileSync, symlinkSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import assert from 'node:assert/strict';
import test from 'node:test';
import { artifactTree, verifyArtifactTree } from './artifact-tree.mjs';

test('all-file verification detects added, removed, changed and linked artifacts', () => {
  const stage = mkdtempSync(join(tmpdir(), 'utexo-artifact-test-'));
  try {
    mkdirSync(join(stage, 'library'));
    writeFileSync(join(stage, 'library/binary'), 'binary');
    writeFileSync(join(stage, 'library/.metadata'), 'metadata');
    const original = artifactTree(stage, ['library']);
    assert.equal(original.length, 2);
    verifyArtifactTree(stage, ['library'], original);
    writeFileSync(join(stage, 'library/header.h'), 'additional unchecked header');
    assert.throws(() => verifyArtifactTree(stage, ['library'], original));
    rmSync(join(stage, 'library/header.h'));
    writeFileSync(join(stage, 'library/binary'), 'changed');
    assert.throws(() => verifyArtifactTree(stage, ['library'], original));
    rmSync(join(stage, 'library/binary'));
    assert.throws(() => verifyArtifactTree(stage, ['library'], original));
    symlinkSync('/etc/passwd', join(stage, 'library/binary'));
    assert.throws(() => artifactTree(stage, ['library']), /nonregular/);
    assert.throws(() => artifactTree(stage, ['../library']), /invalid/);
  } finally {
    rmSync(stage, { recursive: true, force: true });
  }
});
