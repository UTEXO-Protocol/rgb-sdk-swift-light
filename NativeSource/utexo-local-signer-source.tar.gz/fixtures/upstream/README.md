# Pinned upstream assurance fixtures

Retrieved 2026-09-19; public test keys only, never use these wallets for funds.
Files are checked in and tests never fetch or trust a moving remote resource.

| File | Primary source | SHA-256 |
|---|---|---|
| bip39.json | https://github.com/trezor/python-mnemonic/blob/master/vectors.json | fa3b937b7cff9c9b8ecd3aa011faeb8d6dd67993174b72326e83f4de8fdb30f8 |
| bip340.csv | https://github.com/bitcoin/bips/blob/master/bip-0340/test-vectors.csv | 34c9d1d9c3a88d524bc80778540dc43f8306ec249a7485293063c376db851c2d |
| bip341.json | https://github.com/bitcoin/bips/blob/master/bip-0341/wallet-test-vectors.json | 403e19fb81dd1f31e745699216308f61fb403774b2aafa87b631b8f7c042d37f |
| rgb-invoice-0.11.1-rc.11.json | https://github.com/rgb-protocol/rgb-ops/tree/5308b9d46c91857513ff5be2459992264687632b/invoice | d48c8f483356161a4aa1db4077aa1ddbfaebcd15c2430cfc7dc4c5f34c390644 |

Coverage: all 24 English BIP39 entropy/mnemonic/seed/master-xpriv vectors;
all 15 fixed-32-byte-message BIP340 verification vectors and four exact
signature-generation vectors; all seven BIP341 key-path sighash, private-key
tweak and witness vectors. Other BIP39 languages are deliberately not exposed
by this SDK. Four newer BIP340 variable-length-message vectors are outside the
pinned digest-only secp256k1 API and are explicitly counted, not silently passed.
BIP341 primitive vectors include merkle roots and hash types forbidden by the
SDK: primitive correctness does not broaden the signing policy.

`rgb-invoice-0.11.1-rc.11.json` records exact decoded outputs for canonical
invoices plus deliberate strict-policy rejections. It includes the pinned
gateway OpenAPI example and the result counts from a 6,768-case differential
run against the registry release. The upstream parser accepted 1,680 inputs;
1,412 round-tripped canonically; 407 met the RGB-lib projection and local
hardening policy; the lightweight parser accepted exactly those 407 with no
field mismatch. The corpus stores `u64` amounts as decimal strings to remain
lossless in every JSON consumer. It validates syntax and intent only, not
beneficiary ownership, asset existence, or RGB transition validity.

The upstream BIP340 test vectors/code offer BSD-2-Clause OR MIT OR CC0-1.0;
this fixture distribution records the BSD-2-Clause option. BIP341 declares
BSD-3-Clause. Both proposals are authored by Pieter Wuille, Jonas Nick and
Anthony Towns. python-mnemonic is MIT licensed; its original copyright and
license are retained in `python-mnemonic-LICENSE`. Standard BSD license texts
are distributed alongside these fixtures. RGB invoice format behavior is
derived from `rgb-invoicing` 0.11.1-rc.11 at revision
`5308b9d46c91857513ff5be2459992264687632b`, copyright (C) 2019-2024 LNP/BP
Standards Association, licensed Apache-2.0; full registry checksum, license URL,
RGB-lib projection revision, RN target revision, and gateway source revision are
embedded in the JSON. These tests are not a claim of full protocol-vector
coverage or a completed sustained fuzz audit.
