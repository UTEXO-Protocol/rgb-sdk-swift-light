# Local signer regression fixtures

All seeds in this directory are public test vectors. Never fund them on a real network.

`native-signing-smoke.json` is synthetic and uses a nonexistent Bitcoin prevout.
Regenerate its fields with
`cargo test --locked print_native_smoke_fixture -- --ignored --nocapture`.
The Swift and Kotlin packaged-native smoke tests use the same transaction.

`native-signing-multi-smoke.json` adds two synthetic inputs at vanilla external
indices 2 and 3. It exercises tightening `maximumInputs` and
`maximumChildIndex` against retained signing evidence. Reproduce with
`cargo test --locked multi_input_nonzero_derivation_profile_fixture -- --nocapture`.

`gateway-btc-pr174.psbt` was actually returned by the regtest gateway at commit
`8eebc40a44ff519bd21c818a7fbe7c11d3275e8c` on 2026-09-18. It uses the public
BIP86 mnemonic (eleven `abandon` words followed by `about`), sends 40,000 sats
to `bcrt1pjyd6wjs2nlefjehddqsvxe8r0ng5r70urvlx72u5fvpsnhs35feqsu7305`,
and pays 309 sats. Its unsigned transaction ID is
`c85326c4ef41a07740b0024b9ffd405ec0b114684b63833dd01653ad4df579fb`.
It is PSBTv0 / transaction version 2 / sequence `0xfffffffd`, with locktime 104
and vanilla change at `m/86'/1'/0'/0/3`. Core estimates 154 signed vbytes.
Full provenance and decoded maps are in the workspace's backend
`minimal-sdk/local-fixtures/send-btc.json`.

The legacy native policy must reject this fixture under `utexo.psbt.bip86.v1` because
locktime and change branch differ. The regression test also isolates the
change rejection after setting locktime to zero **only in test memory**.
These tests do not authorize changing or signing a real prepared transaction.

The additive `utexo.psbt.rgb-lib.v1` tests instead validate/sign the **untouched**
BTC fixture with an independently specified fixture height bound of 110 and a
2 sat/vB target separate from the hard fee ceilings. They preserve the original
transaction and all output/global metadata. No gateway completion is invoked.

`gateway-create-pr174.psbt` and `gateway-rgb-pr174.psbt` are byte-for-byte copies
of `prepared.psbt` from the same retained public-test gateway captures, not
synthetic replacements. Full metadata remains in `create-utxos.json` and
`send-asset.json` beside the BTC provenance in the workspace backend fixtures.

| Capture | Time (UTC), 2026-09-18 | Request / actual transaction |
| --- | --- | --- |
| Create UTXOs | 13:12:40.491 | Five 5,000-sat colored outputs; one vanilla change; fee 653 sats; 326 signed vB; locktime 104; txid `9f4b8d594d577e5b73cd941db229870965f099bf0092df8cf9444cc309986967` |
| RGB blind send | 13:23:27.376 | 40 fungible units of the captured test NIA; one zero-value OP_RETURN commitment and owned colored change; fee 309 sats; 154 signed vB; locktime 109; txid `e41e4ebdc769b0575126a5d728394d4c01206110e7eaebf6446029d5acd0d814` |

The RGB test's local canonical invoice is reconstructed from the captured
asset and blind recipient, with open schema/amount segments and the explicit
caller amount 40. It is not claimed to be an original returned receive invoice.
Its validity test covers Bitcoin authorization and the declared server-RGB
trust boundary; it is not full RGB transition validation. New witness-send
adversarial tests use a synthetic copy and are labeled separately in source.

The new policy suite also covers independent height bounds, target/hard-cap
rounding, two/128 inputs, the 252/253/256-output CompactSize boundaries, no
unapproved dust-to-fee allowance, exact create plans, self-send duplicate output
classification, invoice/witness mismatches, common sighash/ownership floors and
RGB commitment-envelope tampering.
