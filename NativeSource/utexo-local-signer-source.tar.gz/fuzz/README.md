# Native sanitizer campaigns

Harness-only package: none of these dependencies or targets enters mobile artifacts.
Use cargo-fuzz 0.13.2, libfuzzer-sys 0.4.13 and the locked harness dependencies.
Run with nightly Rust; preserve the exact compiler version and campaign output.
The mobile library is built separately with pinned Rust 1.88.0.

`psbt_bytes` exercises parsing plus the complete validate/sign/finalize pipeline on
accepted mutations. `psbt_structure` mutates valid synthetic two-input PSBTs so
mutations reach policy checks beyond framing. `key_material` exercises UTF-8,
mnemonic, seed and extended-key failures. `rgb_invoice` exercises the bounded
canonical invoice decoder and asserts the invariants of every accepted DTO. All
seed keys are PUBLIC TEST KEYS. The original synthetic targets use nonexistent
prevouts. `gateway_psbt` additionally mutates the three retained, real regtest
gateway preparations and their separate authorization context; no networking,
gateway completion, or submission is performed. It exercises raw framing,
structured PSBT maps, height/fee ceilings, and RGB invoice/asset fields. Accepted
cases must retain all transaction bytes, outputs and proprietary maps through
signing, with fee conservation, exact external value, and finalized witnesses.
The gateway target also fuzzes untrusted create-plan extraction and verifies
that every accepted create transaction can be independently validated with the
extracted exact plan bound to the original caller authorization.

These are bounded campaigns with retained corpora, not proof of exhaustive
coverage, equivalence to Bitcoin consensus or an independent security audit.
Successful signing also checks recipient totals, fee conservation, final witness,
txid and vsize; the independent Core decoder check is a separate harness.
