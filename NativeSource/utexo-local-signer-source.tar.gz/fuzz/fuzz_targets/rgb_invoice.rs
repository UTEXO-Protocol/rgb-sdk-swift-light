#![no_main]

use libfuzzer_sys::fuzz_target;
use utexo_local_signer::{
    RgbInvoiceAssignmentKind, RgbInvoiceEncodedStateKind, decode_rgb_invoice,
};

const MAX_INVOICE_BYTES: usize = 16_384;

fuzz_target!(|data: &[u8]| {
    if data.len() > MAX_INVOICE_BYTES {
        return;
    }
    let Ok(invoice) = std::str::from_utf8(data) else {
        return;
    };
    let Ok(decoded) = decode_rgb_invoice(invoice.to_owned()) else {
        return;
    };

    assert!(!decoded.recipient_id.is_empty());
    assert!(decoded.recipient_id.len() <= 1_024);
    assert!(decoded.transport_endpoints.len() <= 16);
    assert!(
        decoded
            .transport_endpoints
            .iter()
            .all(|endpoint| !endpoint.is_empty() && endpoint.len() <= 2_048)
    );
    assert!(
        decoded
            .assignment_name
            .as_ref()
            .is_none_or(|name| !name.is_empty() && name.len() <= 100)
    );
    assert!(
        decoded
            .expiration_timestamp
            .is_none_or(|expiry| expiry >= 0)
    );

    match decoded.encoded_state.kind {
        RgbInvoiceEncodedStateKind::Omitted | RgbInvoiceEncodedStateKind::NonFungible => {
            assert_eq!(decoded.encoded_state.amount, None);
        }
        RgbInvoiceEncodedStateKind::Amount => {
            assert!(decoded.encoded_state.amount.is_some());
        }
    }
    match decoded.assignment.kind {
        RgbInvoiceAssignmentKind::Fungible | RgbInvoiceAssignmentKind::InflationRight => {
            assert!(decoded.assignment.amount.is_some());
        }
        RgbInvoiceAssignmentKind::NonFungible | RgbInvoiceAssignmentKind::Any => {
            assert_eq!(decoded.assignment.amount, None);
        }
    }
});
