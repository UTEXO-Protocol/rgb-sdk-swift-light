#![allow(dead_code)]
use base64::{Engine, engine::general_purpose::STANDARD};
use std::sync::{Arc, OnceLock};
use utexo_local_signer::{
    LocalSigner, Network, OperationKind, Recipient, SigningIntent, default_signing_policy,
};

pub fn signer() -> &'static Arc<LocalSigner> {
    static SIGNER: OnceLock<Arc<LocalSigner>> = OnceLock::new();
    SIGNER.get_or_init(|| LocalSigner::from_mnemonic(Network::Mainnet,
        b"abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about".to_vec(),
        vec![]).unwrap())
}

pub fn fixture() -> &'static serde_json::Value {
    static FIXTURE: OnceLock<serde_json::Value> = OnceLock::new();
    FIXTURE.get_or_init(|| {
        serde_json::from_str(include_str!(
            "../../fixtures/native-signing-multi-smoke.json"
        ))
        .unwrap()
    })
}

pub fn intent() -> SigningIntent {
    SigningIntent {
        operation_id: "fuzz-operation".into(),
        idempotency_key: "fuzz-idempotency".into(),
        network: Network::Mainnet,
        operation: OperationKind::SendBtc,
        recipients: vec![Recipient {
            address: fixture()["recipient"].as_str().unwrap().into(),
            amount_sats: 30_000,
        }],
        policy: default_signing_policy(),
    }
}

pub fn validate_and_sign(bytes: &[u8]) {
    let input = STANDARD.encode(bytes);
    if let Ok(report) = signer().validate_psbt(input.clone(), intent()) {
        assert_eq!(report.external_output_sats, 30_000);
        assert_eq!(
            report
                .total_input_sats
                .checked_sub(report.total_output_sats),
            Some(report.fee_sats)
        );
        assert!(report.fee_sats <= intent().policy.max_absolute_fee_sats);
        assert_eq!(report.op_return_count, 0);
        let signed = signer().sign_psbt(input, intent()).unwrap();
        assert_eq!(report, signed.validation);
        assert_eq!(signed.signed_input_count, report.input_count);
        let psbt =
            bitcoin::psbt::Psbt::deserialize(&STANDARD.decode(signed.signed_psbt_base64).unwrap())
                .unwrap();
        assert!(psbt.inputs.iter().all(|input| {
            input
                .final_script_witness
                .as_ref()
                .is_some_and(|w| w.len() == 1)
        }));
        let tx = psbt.extract_tx().unwrap();
        assert_eq!(tx.compute_txid().to_string(), report.unsigned_txid);
        assert_eq!(tx.vsize() as u64, report.estimated_vbytes);
    }
}
