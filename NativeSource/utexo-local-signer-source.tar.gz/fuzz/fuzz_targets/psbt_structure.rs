#![no_main]
mod common;
use base64::{Engine, engine::general_purpose::STANDARD};
use bitcoin::{Amount, Sequence, absolute, transaction};
use libfuzzer_sys::fuzz_target;

fuzz_target!(|data: &[u8]| {
    if data.len() < 9 {
        return;
    }
    let amount = u64::from_le_bytes(data[1..9].try_into().unwrap());
    let mut psbt = bitcoin::psbt::Psbt::deserialize(
        &STANDARD
            .decode(common::fixture()["psbt"].as_str().unwrap())
            .unwrap(),
    )
    .unwrap();
    let index = data[1] as usize % psbt.inputs.len();
    match data[0] % 12 {
        0 => {}
        1 => psbt.unsigned_tx.output[0].value = Amount::from_sat(amount),
        2 => psbt.unsigned_tx.output[1].value = Amount::from_sat(amount),
        3 => psbt.inputs[index].witness_utxo.as_mut().unwrap().value = Amount::from_sat(amount),
        4 => psbt.unsigned_tx.input[index].sequence = Sequence(amount as u32),
        5 => psbt.unsigned_tx.lock_time = absolute::LockTime::from_consensus(amount as u32),
        6 => psbt.unsigned_tx.version = transaction::Version(amount as i32),
        7 => psbt.unsigned_tx.input[1].previous_output = psbt.unsigned_tx.input[0].previous_output,
        8 => psbt.inputs[index].tap_internal_key = None,
        9 => psbt.outputs[1].tap_key_origins.clear(),
        10 => {
            psbt.unknown.insert(
                bitcoin::psbt::raw::Key {
                    type_value: 255,
                    key: data.to_vec(),
                },
                vec![1],
            );
        }
        11 => {
            psbt.inputs[index].sighash_type =
                Some(bitcoin::psbt::PsbtSighashType::from_u32(amount as u32))
        }
        _ => unreachable!(),
    }
    common::validate_and_sign(&psbt.serialize());
});
