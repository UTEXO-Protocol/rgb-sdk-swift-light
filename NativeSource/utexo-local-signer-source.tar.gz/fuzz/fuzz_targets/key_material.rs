#![no_main]
use libfuzzer_sys::fuzz_target;
use utexo_local_signer::{
    Network, derive_keys_from_mnemonic, derive_keys_from_seed, derive_keys_from_xpriv,
    get_xpub_from_xpriv,
};

fuzz_target!(|data: &[u8]| {
    if data.len() > 4_096 {
        return;
    }
    let _ = derive_keys_from_mnemonic(Network::Mainnet, data.to_vec(), vec![]);
    let _ = derive_keys_from_seed(Network::Mainnet, data.to_vec());
    if let Ok(text) = std::str::from_utf8(data) {
        let _ = get_xpub_from_xpriv(text.to_owned());
        let _ = derive_keys_from_xpriv(Network::Mainnet, text.to_owned());
    }
});
