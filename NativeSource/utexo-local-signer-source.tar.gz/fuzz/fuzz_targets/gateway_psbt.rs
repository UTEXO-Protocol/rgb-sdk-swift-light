#![no_main]
use base64::{Engine, engine::general_purpose::STANDARD};
use bitcoin::{Amount, Sequence, absolute, psbt::Psbt};
use libfuzzer_sys::fuzz_target;
use std::sync::{Arc, OnceLock};
use utexo_local_signer::{
    CreateUtxosAuthorization, GatewaySigningIntent, LocalSigner, Network, OperationKind, Recipient,
    RgbBitcoinAuthorization, SigningIntent, extract_gateway_create_utxos_outputs,
    gateway_signing_policy,
};

// Public regtest test-vector key only. No network access or submission exists.
fn signer() -> &'static Arc<LocalSigner> {
    static SIGNER: OnceLock<Arc<LocalSigner>> = OnceLock::new();
    SIGNER.get_or_init(|| {
        LocalSigner::from_mnemonic(
            Network::Regtest,
            b"abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about".to_vec(),
            vec![],
        ).unwrap()
    })
}

fn intent(operation: OperationKind) -> GatewaySigningIntent {
    let asset = "rgb:9p3aZVvS-e886rs0-7XWD2vq-uh0GutQ-eK6o4xd-X29gYGo";
    GatewaySigningIntent {
        intent: SigningIntent {
            operation_id: "gateway-fuzz-operation".into(),
            idempotency_key: "gateway-fuzz-request".into(),
            network: Network::Regtest,
            operation,
            recipients: if operation == OperationKind::SendBtc {
                vec![Recipient {
                    address: "bcrt1pjyd6wjs2nlefjehddqsvxe8r0ng5r70urvlx72u5fvpsnhs35feqsu7305"
                        .into(),
                    amount_sats: 40_000,
                }]
            } else {
                vec![]
            },
            policy: gateway_signing_policy(operation),
        },
        max_block_height: 110,
        target_fee_rate_msat_per_vbyte: 2_000,
        create_utxos: (operation == OperationKind::CreateUtxos).then_some(
            CreateUtxosAuthorization {
                min_count: 5,
                max_count: 5,
                size_sats: 5_000,
                exact_outputs: None,
            },
        ),
        rgb: (operation == OperationKind::OnchainSend).then_some(RgbBitcoinAuthorization {
            invoice: format!(
                "{asset}/~/~/bcrt:utxob:rrenuOZq-sm2KkQo-w_ksB_K-ESeK4vF-N79kMAi-suQX4q2-J1tYQ"
            ),
            asset_id: asset.into(),
            amount: 40,
            witness_amount_sats: None,
            witness_blinding: None,
            donation: false,
            min_confirmations: 1,
            skip_sync: false,
            validation_time_unix_seconds: 1_800_000_000,
        }),
    }
}

fuzz_target!(|data: &[u8]| {
    if data.len() < 10 || data.len() > 65_536 {
        return;
    }
    let (operation, fixture) = match data[0] % 3 {
        0 => (
            OperationKind::SendBtc,
            include_str!("../../fixtures/gateway-btc-pr174.psbt"),
        ),
        1 => (
            OperationKind::CreateUtxos,
            include_str!("../../fixtures/gateway-create-pr174.psbt"),
        ),
        _ => (
            OperationKind::OnchainSend,
            include_str!("../../fixtures/gateway-rgb-pr174.psbt"),
        ),
    };
    let mut context = intent(operation);
    let value = u64::from_le_bytes(data[2..10].try_into().unwrap());
    let mut psbt = Psbt::deserialize(&STANDARD.decode(fixture.trim()).unwrap()).unwrap();
    match data[1] % 18 {
        0 => {}
        1 => psbt.unsigned_tx.output[0].value = Amount::from_sat(value),
        2 => psbt.inputs[0].witness_utxo.as_mut().unwrap().value = Amount::from_sat(value),
        3 => psbt.unsigned_tx.lock_time = absolute::LockTime::from_consensus(value as u32),
        4 => psbt.unsigned_tx.input[0].sequence = Sequence(value as u32),
        5 => {
            psbt.inputs[0].sighash_type =
                Some(bitcoin::psbt::PsbtSighashType::from_u32(value as u32))
        }
        6 => psbt.inputs[0].tap_key_origins.clear(),
        7 => psbt.outputs[0].tap_key_origins.clear(),
        8 => psbt.proprietary.clear(),
        9 => {
            for output in &mut psbt.outputs {
                if let Some(bytes) = output.proprietary.values_mut().next() {
                    *bytes = data[2..].to_vec();
                }
            }
        }
        10 => context.max_block_height = value as u32,
        11 => context.target_fee_rate_msat_per_vbyte = value,
        12 => context.intent.policy.max_absolute_fee_sats = value,
        13 => context.intent.policy.max_fee_rate_msat_per_vbyte = value,
        14 => {
            if let Some(create) = &mut context.create_utxos {
                create.size_sats = value;
            }
        }
        15 => {
            if let Some(rgb) = &mut context.rgb {
                rgb.invoice = String::from_utf8_lossy(&data[2..]).into_owned();
            }
        }
        16 => {
            if let Some(rgb) = &mut context.rgb {
                rgb.asset_id = String::from_utf8_lossy(&data[2..]).into_owned();
            }
        }
        _ => {}
    }
    let encoded = if data[1] % 18 == 17 {
        STANDARD.encode(&data[2..])
    } else {
        STANDARD.encode(psbt.serialize())
    };
    let extracted = extract_gateway_create_utxos_outputs(encoded.clone(), Network::Regtest);
    if let Ok(plan) = &extracted {
        assert!(!plan.is_empty() && plan.len() <= 255);
        assert!(plan.iter().all(|output| {
            output.account == utexo_local_signer::AccountKind::Colored
                && output.keychain == utexo_local_signer::Keychain::External
                && output.index <= 1_000_000
                && (330..=u64::from(u32::MAX)).contains(&output.amount_sats)
        }));
    }
    if let Ok(report) = signer().validate_gateway_psbt(encoded.clone(), context.clone()) {
        if operation == OperationKind::CreateUtxos {
            let mut exact_context = context.clone();
            exact_context.create_utxos.as_mut().unwrap().exact_outputs = Some(extracted.unwrap());
            let exact = signer().validate_gateway_psbt(encoded.clone(), exact_context).unwrap();
            assert_eq!(exact.unsigned_txid, report.unsigned_txid);
            assert_eq!(exact.fee_sats, report.fee_sats);
        }
        let before = Psbt::deserialize(&STANDARD.decode(&encoded).unwrap()).unwrap();
        let signed = signer()
            .sign_gateway_psbt(encoded, context.clone())
            .unwrap();
        let after =
            Psbt::deserialize(&STANDARD.decode(&signed.signed_psbt_base64).unwrap()).unwrap();
        assert_eq!(signed.validation, report);
        assert_eq!(signed.signed_input_count, report.input_count);
        assert_eq!(before.unsigned_tx, after.unsigned_tx);
        assert_eq!(before.outputs, after.outputs);
        assert_eq!(before.proprietary, after.proprietary);
        assert_eq!(
            report
                .total_input_sats
                .checked_sub(report.total_output_sats),
            Some(report.fee_sats)
        );
        assert!(report.fee_sats <= context.intent.policy.max_absolute_fee_sats);
        assert!(before.unsigned_tx.lock_time.to_consensus_u32() <= context.max_block_height);
        assert_eq!(
            report.external_output_sats,
            if operation == OperationKind::SendBtc {
                40_000
            } else {
                0
            }
        );
        assert_eq!(
            report.op_return_count,
            u32::from(operation == OperationKind::OnchainSend)
        );
        assert!(after.inputs.iter().all(|input| {
            input
                .final_script_witness
                .as_ref()
                .is_some_and(|w| w.len() == 1)
        }));
        let tx = after.extract_tx().unwrap();
        assert_eq!(tx.compute_txid().to_string(), report.unsigned_txid);
        assert_eq!(tx.vsize() as u64, report.estimated_vbytes);
    }
});
