# UTEXO local signer core

This crate is the single cryptographic and Bitcoin-policy implementation used
by the lightweight Swift and Kotlin SDKs. It is deliberately not a wallet,
network client, chain indexer, RGB validator, or general PSBT signer.

The initial frozen profile supports BIP39 English mnemonics and 64-byte seeds,
BIP32 derivation, UTEXO's BIP86-style paths, BIP340 Schnorr signatures, BIP341
Taproot key-path spends, PSBTv0 (BIP174) with Taproot fields (BIP371), and
Bech32m P2TR addresses (BIP350).

The original `validate_psbt` / `sign_psbt` profile remains frozen: it accepts
only vanilla `sendBtc`, locktime zero and branch-1 change. An additive,
explicitly selected `utexo.psbt.rgb-lib.v1` profile now validates/signs BTC,
create-UTXOs and single-fungible-asset RGB preparations from the branch-0
RGB-lib builder. It requires independent height/fee context and operation
authorization; it is not selected implicitly by the legacy API. `inflate`
still has no qualified gateway profile. See [gateway policy](#gateway-profile).

Bitcoin validation cannot prove RGB transition semantics or prove absence of
undisclosed RGB allocations. The gateway remains trusted for RGB state,
transition/consignment validity, beneficiary delivery and allocation-aware
selection. No supported profile claims full local RGB validation.

The core also exposes bounded, canonical RGB invoice decoding for the mobile
facades. It mirrors the RN-facing `rgb-lib` NIA/UDA/CFA/IFA/BFA assignment model,
while retaining the literal encoded state so receive validation cannot confuse
an omitted amount with a lossy projected zero or `Any` assignment. This parser
validates invoice syntax and declared intent only; it does not prove beneficiary
ownership, asset existence, consignment validity, or an RGB state transition.
Its format behavior is independently implemented from Apache-2.0
`rgb-invoicing` 0.11.1-rc.11 at revision
`5308b9d46c91857513ff5be2459992264687632b`; fixture provenance and intentional
strict divergences are recorded in `fixtures/upstream/README.md`. The proxy
protocol 1.0 `pk` (recipient Ed25519 key) and `enc` (encryption preference)
parameters follow `rgb-invoicing` 0.11.2-rc.1 at revision
`55918e00629fe103d0de1e7392bf3a20dec305d8`, which `rgb-lib-bfa` emits.

The application-facing SDKs do not expose raw PSBT methods. They construct the
intent from the app request, validate the untrusted backend PSBT here, sign
only if every check passes, persist the exact signed bytes, and submit them
under one idempotent operation identity.

Signing returns a finalized PSBT: each BIP86 input has a single-item
`final_script_witness`, with the consumed Taproot signing fields removed in
accordance with [BIP174](https://bips.dev/174/) and
[BIP371](https://bips.dev/371/). The signer verifies the extracted witness
signatures against the original previous-output scripts, and checks that the
transaction ID and actual virtual size match the local validation report.
This does not relax the transaction profile or establish compatibility with an
unversioned gateway. Real gateway fixture/profile and recovery gates remain.

## Gateway profile

`gateway_signing_policy(operation)` provides the baseline for
`LocalSigner.validate_gateway_psbt` / `sign_gateway_psbt`. Their additive
`GatewaySigningIntent` carries the existing immutable intent plus:

- `max_block_height`: an independently trusted chain-height bound, never copied
  from the untrusted PSBT. Zero and height locktimes up to that bound are
  accepted; timestamp locktimes are not. All transactions remain version 2,
  sequence `0xfffffffd`, PSBTv0 and fully owned BIP86 key-path inputs.
- `target_fee_rate_msat_per_vbyte`: exact caller target, separately enforced
  from the hard actual-signed-size rate cap and absolute fee cap in the policy.
- Optional operation authorization: create count/size/optional exact reserved
  colored outputs, or canonical RGB invoice/asset/amount/witness/caller context.

The builder profile allows only branch 0. BTC/create inputs must be vanilla;
RGB may use vanilla and colored inputs. Non-recipient outputs must re-derive to
their claimed wallet keys and remain non-dust. BTC permits at most one vanilla
change; create permits 1–255 distinct colored outputs of the authorized size
(330–4,294,967,295 sats, matching the native u32 carrier and P2TR dust floor)
and at most one vanilla change. RGB permits at most one colored and one vanilla
change. Exact create reservation plans, when supplied, cover every created
colored output and are verified rather than merely hashed. Native count/size
authorization without a plan is an explicit lower-level option, not permission
to discard a facade's existing exact-plan contract.

`extract_gateway_create_utxos_outputs` parses a prepared create transaction into
an exact ordered colored-output plan without a second PSBT parser in Swift or
Kotlin. It enforces canonical encoding, bounded counts/amounts, branch-0 BIP86
paths and internally consistent P2TR metadata. These are **untrusted hints**,
not proof of wallet ownership or authorization. The platform must retain the
original request and independently validate/sign with the exact extracted plan;
the signer re-derives keys and scripts and checks the caller's count, size, fees
and chain context. No server-reported value becomes caller intent.

The fee-target budget is a **conservative component-rounded upper bound** for
BDK's key-path construction, not an assertion of a byte-identical estimator.
Each input uses a 65-byte signature estimate; its 231-weight-unit component is
rounded up independently, as are the remaining base and an optional 172-unit
P2TR change component. For rate `r` milli-sat/vB, each component contributes
`ceil(r * weight / 4000)` sats. This explains both one-input captures (309 sats
at 154 signed vB; 653 at 326 vB, with target 2 sat/vB) and bounded per-input
rounding for larger transactions. It does **not** authorize dust to be donated
to fees. Independent absolute and actual-rate ceilings still apply; setting
the hard cap equal to the nominal target can intentionally reject rounding.
The current gateway transport accepts only whole sat/vB values. SDK defaults are
2 sat/vB; explicit fractional values are rejected rather than silently rounded.
This does not restrict the lower-level signer's exact milli-sat fee arithmetic.

Source evidence: the intended native release
[rgb-lib v0.3.0-beta.18](https://github.com/UTEXO-Protocol/rgb-lib/tree/33e3493bd3c7012a4135ade3541968dcbb8c99ed)
uses BDK 2.0.0; its wallet construction and BDK/miniscript key-path estimates
are compatible with the retained real captures. This source relation does not
establish a reproducible attestation for the published npm platform binary.

RGB authorization is limited to fungible sends. Embedded asset/amount conflicts,
NFT/inflation assignments, wrong networks and invoices expired at the supplied
caller validation time are rejected. `rgb_invoice_witness_recipient` locally
derives the exact Bitcoin output from a witness invoice; blind sends authorize
no external Bitcoin output. Only the captured OP_RETURN RGB/MPC/OPRET envelope
shapes are accepted, with a zero-value canonical 32-byte commitment whose
duplicated Bitcoin commitment fields agree. Opaque transition and MPC proof
payloads are preserved but **not cryptographically RGB-validated**. Donation,
confirmations, skip-sync and witness blinding remain hash-bound caller context;
their RGB effects are server-trusted. Other native commitment styles, notably
Tapret/script-path commitments, are not supported by this narrow profile.

Every extra authorization field is bound into a domain-separated digest. A
current validation time may change a new report's intent digest during safe
revalidation; facade recovery must retain the original signing evidence and
continue checking immutable request identity and transaction facts. Submitted
operations must not be re-signed or blindly retried.

Three **untouched**, public-test-seed gateway fixtures now pass native local
validation, signing and finalized-witness verification. No transaction was
broadcast or completed against the gateway. This is not permission to open
production spending gates: backend submission durability/recovery, deployed
profile/chain context and packaged end-to-end qualification remain required.

The Rust boundary enforces the same hard ceilings as the native facades:
1 MB PSBT, 128 inputs, 256 outputs, child index 1,000,000, fee 1,000,000 sats,
and 100 sat/vB. Input/output totals cannot exceed Bitcoin's supply bound.
Mnemonic, passphrase, seed, and xpriv input buffers are guarded for best-effort
zeroization on both successful and error exits; runtime/library copies remain
a documented memory limitation.

## Verification

```sh
scripts/verify.sh
scripts/generate-bindings.sh
scripts/build-apple.sh
scripts/build-android.sh
```

Independent Bitcoin Core signature/consensus verification is also available:

```sh
docker pull registry.gitlab.com/hashbeam/docker/bitcoind@sha256:5473c951ca8a703f7c15d9a353f99135e0a1f0cc7ef976f29d073160950098bf
node --test examples/core-consensus-cleanup.test.mjs
node examples/verify-core-consensus.mjs
```

The verifier starts and removes its own network-isolated regtest container with
no host mounts or published ports. It uses the public BIP39 test mnemonic and
locally mined valueless coins, checks DEFAULT and ALL Schnorr witnesses, requires
Core to reject tampered signatures and outputs, submits the valid transactions
only to that isolated node, and verifies mined recipient outputs. It records the
image and source fingerprints. It never contacts or changes the gateway stack.
This supplements decoder/extractor differential tests; it is not proof of mobile
facade/gateway interoperability, full RGB validation, or an independent security
review. Docker and the already-pulled pinned image are required; absence fails
the check rather than silently skipping it.

Rust is pinned by `rust-toolchain.toml`; dependencies are exactly pinned and
`Cargo.lock` is committed. Generated bindings and native artifacts must be
rebuilt together whenever the Rust API checksum changes.

## Assurance inputs and source packaging

The offline Rust suite includes pinned public English BIP39 vectors, BIP340
fixed-32-byte-message verification/signing vectors and BIP341 key-path vectors.
It also checks every sighash byte, exact policy boundaries, PSBT truncations,
deterministic byte mutations and corrupted finalized witnesses. Separately
locked, non-shipping `cargo-fuzz` targets exercise PSBT parsing/signing, key
material and invoice decoding under sanitizers. These are bounded campaigns,
not proof of exhaustive coverage or an independent cryptographic audit. See
`fixtures/upstream/README.md` and `fuzz/README.md` for provenance and scope.

```sh
node scripts/security-inventory.mjs          # regenerate SBOM and notices
node scripts/security-inventory.mjs --check --advisories
node --test scripts/osv-response.test.mjs
bash scripts/package-source.sh              # workspace packaging + negative checks
node scripts/package-provenance.mjs
```

The source inventory covers all-feature/all-platform locked Cargo dependencies,
including build/test/bindgen packages; it is not a runtime-only linked-code bill
of materials. OSV scans send only public coordinates/versions, fail on malformed,
partial or paginated responses, and record the lock hash and query time. A clean
response is not proof of absence of vulnerabilities. `license-review.json`
explicitly retains unresolved notices and owner-review requirements.

The source archive has fixed order/metadata and excludes symlinks, hidden paths,
and build directories. Identical compressed bytes additionally require identical
inputs and Node/zlib versions. Its independent platform-tar check requires the
entire curated source set, regular files and exact file bytes, with six negative
archive regressions. Checksum manifests record bundled artifacts but are not a
signed release or proof those binaries were independently reproduced.

The 2026-09-19 invoice decoder and 2026-09-21 additive gateway authorization
add native functions and records. Every Swift/Kotlin binding and native artifact
must be rebuilt and verified together before packaging. Later parser or signing
ABI changes have the same requirement.
