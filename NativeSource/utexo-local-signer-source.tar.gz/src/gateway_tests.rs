use super::*;

const BTC: &str = include_str!("../fixtures/gateway-btc-pr174.psbt");
const CREATE: &str = include_str!("../fixtures/gateway-create-pr174.psbt");
const RGB: &str = include_str!("../fixtures/gateway-rgb-pr174.psbt");
const ASSET: &str = "rgb:9p3aZVvS-e886rs0-7XWD2vq-uh0GutQ-eK6o4xd-X29gYGo";
const BLIND: &str = "bcrt:utxob:rrenuOZq-sm2KkQo-w_ksB_K-ESeK4vF-N79kMAi-suQX4q2-J1tYQ";

fn intent(operation: OperationKind) -> GatewaySigningIntent {
    GatewaySigningIntent {
        intent: SigningIntent {
            operation_id: "gateway-untouched-fixture".into(),
            idempotency_key: "gateway-local-validation".into(),
            network: Network::Regtest,
            operation,
            recipients: if operation == OperationKind::SendBtc {
                vec![Recipient {
                    address: "bcrt1pjyd6wjs2nlefjehddqsvxe8r0ng5r70urvlx72u5fvpsnhs35feqsu7305"
                        .into(),
                    amount_sats: 40_000,
                }]
            } else {
                vec![]
            },
            policy: gateway_signing_policy(operation),
        },
        // Explicit fixture chain context, not extracted from the prepared PSBT.
        max_block_height: 110,
        target_fee_rate_msat_per_vbyte: 2_000,
        create_utxos: (operation == OperationKind::CreateUtxos).then_some(
            CreateUtxosAuthorization {
                min_count: 5,
                max_count: 5,
                size_sats: 5_000,
                exact_outputs: None,
            },
        ),
        rgb: (operation == OperationKind::OnchainSend).then_some(RgbBitcoinAuthorization {
            invoice: format!("{ASSET}/~/~/{BLIND}"),
            asset_id: ASSET.into(),
            amount: 40,
            witness_amount_sats: None,
            witness_blinding: None,
            donation: false,
            min_confirmations: 1,
            skip_sync: false,
            validation_time_unix_seconds: 1_800_000_000,
        }),
    }
}

fn validate(raw: &str, value: GatewaySigningIntent) -> Result<ValidationReport> {
    signer(Network::Regtest, BIP86_MNEMONIC).validate_gateway_psbt(raw.trim().into(), value)
}

#[test]
fn untouched_gateway_fixtures_validate_sign_and_preserve_every_transaction_byte() {
    let signer = signer(Network::Regtest, BIP86_MNEMONIC);
    for (raw, kind, txid, fee, vbytes, opreturns) in [
        (
            BTC,
            OperationKind::SendBtc,
            "c85326c4ef41a07740b0024b9ffd405ec0b114684b63833dd01653ad4df579fb",
            309,
            154,
            0,
        ),
        (
            CREATE,
            OperationKind::CreateUtxos,
            "9f4b8d594d577e5b73cd941db229870965f099bf0092df8cf9444cc309986967",
            653,
            326,
            0,
        ),
        (
            RGB,
            OperationKind::OnchainSend,
            "e41e4ebdc769b0575126a5d728394d4c01206110e7eaebf6446029d5acd0d814",
            309,
            154,
            1,
        ),
    ] {
        let prepared = parse_test_psbt(raw.trim());
        let report = validate(raw, intent(kind)).expect("untouched gateway PSBT validates");
        assert_eq!(
            (
                report.unsigned_txid.as_str(),
                report.fee_sats,
                report.estimated_vbytes,
                report.op_return_count
            ),
            (txid, fee, vbytes, opreturns)
        );
        let signed = signer
            .sign_gateway_psbt(raw.trim().into(), intent(kind))
            .expect("test-only local signature");
        assert_eq!(signed.validation, report);
        let final_psbt = parse_test_psbt(&signed.signed_psbt_base64);
        assert_eq!(final_psbt.unsigned_tx, prepared.unsigned_tx);
        assert_eq!(final_psbt.outputs, prepared.outputs);
        assert_eq!(final_psbt.proprietary, prepared.proprietary);
        assert!(final_psbt.inputs.iter().all(|input| {
            input
                .final_script_witness
                .as_ref()
                .is_some_and(|witness| witness.len() == 1)
        }));
        let extracted = final_psbt.extract_tx().expect("finalized transaction");
        assert_eq!(extracted.compute_txid().to_string(), txid);
        assert_eq!(extracted.vsize(), usize::try_from(vbytes).unwrap());
    }
}

#[test]
fn independent_height_and_fixed_profile_are_not_taken_from_psbt() {
    let mut context = intent(OperationKind::SendBtc);
    context.max_block_height = 103;
    assert!(validate(BTC, context).is_err());
    for invalid_height in [500_000_000, u32::MAX] {
        let mut context = intent(OperationKind::SendBtc);
        context.max_block_height = invalid_height;
        assert!(validate(BTC, context).is_err());
    }
    for locktime in [111, 500_000_000, u32::MAX] {
        let mut prepared = parse_test_psbt(BTC.trim());
        prepared.unsigned_tx.lock_time = LockTime::from_consensus(locktime);
        assert!(validate(&encode_test_psbt(&prepared), intent(OperationKind::SendBtc)).is_err());
    }
    for kind in [
        OperationKind::SendBtc,
        OperationKind::CreateUtxos,
        OperationKind::OnchainSend,
    ] {
        let raw = match kind {
            OperationKind::SendBtc => BTC,
            OperationKind::CreateUtxos => CREATE,
            _ => RGB,
        };
        let mut context = intent(kind);
        context.intent.policy.allowed_input_scopes[0].keychain = Keychain::Change;
        assert!(validate(raw, context).is_err());
        let mut context = intent(kind);
        context.intent.policy.expected_sequence = None;
        assert!(validate(raw, context).is_err());
        let mut context = intent(kind);
        context.intent.policy.allow_unknown_fields = true;
        assert!(validate(raw, context).is_err());
    }
}

#[test]
fn weight_rounded_fee_target_and_independent_hard_caps_are_exact() {
    let mut context = intent(OperationKind::SendBtc);
    context.intent.policy.max_absolute_fee_sats = 309;
    context.intent.policy.max_fee_rate_msat_per_vbyte = 2_007;
    assert_eq!(validate(BTC, context.clone()).unwrap().fee_sats, 309);
    context.intent.policy.max_absolute_fee_sats = 308;
    assert!(validate(BTC, context.clone()).is_err());
    context.intent.policy.max_absolute_fee_sats = 309;
    context.intent.policy.max_fee_rate_msat_per_vbyte = 2_006;
    assert!(validate(BTC, context.clone()).is_err());
    context.intent.policy.max_fee_rate_msat_per_vbyte = 100_000;
    context.target_fee_rate_msat_per_vbyte = 1_990;
    assert!(validate(BTC, context).is_err());
    let mut prepared = parse_test_psbt(BTC.trim());
    prepared.unsigned_tx.output[1].value -= Amount::ONE_SAT;
    assert!(validate(&encode_test_psbt(&prepared), intent(OperationKind::SendBtc)).is_err());
}

#[test]
fn create_owned_size_count_and_optional_exact_reservations_are_authorized() {
    let mut context = intent(OperationKind::CreateUtxos);
    let plan = [6, 7, 8, 9, 10]
        .map(|index| GatewayOwnedOutput {
            account: AccountKind::Colored,
            keychain: Keychain::External,
            index,
            amount_sats: 5_000,
        })
        .to_vec();
    context.create_utxos.as_mut().unwrap().exact_outputs = Some(plan);
    assert!(validate(CREATE, context.clone()).is_ok());
    context
        .create_utxos
        .as_mut()
        .unwrap()
        .exact_outputs
        .as_mut()
        .unwrap()[0]
        .index = 5;
    assert!(validate(CREATE, context).is_err());
    for (min_count, max_count, size_sats) in [
        (0, 5, 5000),
        (6, 6, 5000),
        (1, 4, 5000),
        (1, 256, 5000),
        (5, 5, 4999),
        (5, 5, 329),
    ] {
        let mut context = intent(OperationKind::CreateUtxos);
        context.create_utxos = Some(CreateUtxosAuthorization {
            min_count,
            max_count,
            size_sats,
            exact_outputs: None,
        });
        assert!(validate(CREATE, context).is_err());
    }
    let mut prepared = parse_test_psbt(CREATE.trim());
    prepared.unsigned_tx.output[1] = prepared.unsigned_tx.output[0].clone();
    prepared.outputs[1] = prepared.outputs[0].clone();
    assert!(
        validate(
            &encode_test_psbt(&prepared),
            intent(OperationKind::CreateUtxos)
        )
        .is_err()
    );
}

#[test]
fn create_size_authorization_respects_native_u32_boundary() {
    for (size, accepted) in [
        (u64::from(u32::MAX), true),
        (u64::from(u32::MAX) + 1, false),
    ] {
        let mut context = intent(OperationKind::CreateUtxos);
        context.create_utxos.as_mut().unwrap().size_sats = size;
        let mut prepared = parse_test_psbt(CREATE.trim());
        for (output, metadata) in prepared
            .unsigned_tx
            .output
            .iter_mut()
            .zip(&prepared.outputs)
        {
            let path = &metadata.tap_key_origins.values().next().unwrap().1.1;
            if path.as_ref()[1] == (bitcoin::bip32::ChildNumber::Hardened { index: 827_167 }) {
                output.value = Amount::from_sat(size);
            }
        }
        let total = prepared
            .unsigned_tx
            .output
            .iter()
            .map(|output| output.value.to_sat())
            .sum::<u64>();
        prepared.inputs[0].witness_utxo.as_mut().unwrap().value = Amount::from_sat(total + 653);
        let raw = encode_test_psbt(&prepared);
        assert_eq!(validate(&raw, context.clone()).is_ok(), accepted);
        assert_eq!(
            signer(Network::Regtest, BIP86_MNEMONIC)
                .sign_gateway_psbt(raw, context)
                .is_ok(),
            accepted
        );
    }
}

#[test]
fn extracted_create_plan_is_exact_but_is_not_ownership_or_request_authorization() {
    let plan =
        extract_gateway_create_utxos_outputs(CREATE.trim().into(), Network::Regtest).unwrap();
    assert_eq!(
        plan,
        [6, 7, 9, 8, 10]
            .into_iter()
            .map(|index| GatewayOwnedOutput {
                account: AccountKind::Colored,
                keychain: Keychain::External,
                index,
                amount_sats: 5_000,
            })
            .collect::<Vec<_>>()
    );
    let mut context = intent(OperationKind::CreateUtxos);
    context.create_utxos.as_mut().unwrap().exact_outputs = Some(plan.clone());
    assert!(validate(CREATE, context.clone()).is_ok());

    // Structurally consistent public metadata is not proof of this wallet's
    // ownership. Extraction may succeed; the independent signer must reject.
    let mut forged = parse_test_psbt(CREATE.trim());
    forged.outputs[0]
        .tap_key_origins
        .values_mut()
        .next()
        .unwrap()
        .1
        .0 = bitcoin::bip32::Fingerprint::from([1, 2, 3, 4]);
    let raw = encode_test_psbt(&forged);
    assert_eq!(
        extract_gateway_create_utxos_outputs(raw.clone(), Network::Regtest).unwrap(),
        plan
    );
    assert!(validate(&raw, context.clone()).is_err());

    // A claimed colored path with a consistent, but different, key/script is
    // also only a hint. Even a genuine master fingerprint does not authorize it.
    let mut forged_key = parse_test_psbt(CREATE.trim());
    let original_origin = forged_key.outputs[0]
        .tap_key_origins
        .values()
        .next()
        .unwrap()
        .clone();
    let foreign = LocalSigner::from_seed(Network::Regtest, vec![73; 64])
        .unwrap()
        .derive_address(AccountKind::Colored, Keychain::External, 6)
        .unwrap();
    let other_key: bitcoin::secp256k1::XOnlyPublicKey = foreign.internal_key_hex.parse().unwrap();
    forged_key.outputs[0].tap_internal_key = Some(other_key);
    forged_key.outputs[0].tap_key_origins.clear();
    forged_key.outputs[0]
        .tap_key_origins
        .insert(other_key, original_origin);
    forged_key.unsigned_tx.output[0].script_pubkey =
        bitcoin::ScriptBuf::from_hex(&foreign.script_pubkey_hex).unwrap();
    let raw = encode_test_psbt(&forged_key);
    let hints = extract_gateway_create_utxos_outputs(raw.clone(), Network::Regtest).unwrap();
    let mut forged_context = context.clone();
    forged_context.create_utxos.as_mut().unwrap().exact_outputs = Some(hints);
    assert!(matches!(validate(&raw, forged_context.clone()),
        Err(SignerError::PolicyRejected { reason }) if reason.contains("key metadata does not match its script")));
    assert!(
        matches!(signer(Network::Regtest, BIP86_MNEMONIC).sign_gateway_psbt(raw, forged_context),
        Err(SignerError::PolicyRejected { reason }) if reason.contains("key metadata does not match its script"))
    );

    // Amounts extracted from the server do not become caller intent.
    context.create_utxos.as_mut().unwrap().size_sats = 5_001;
    assert!(validate(CREATE, context).is_err());
}

#[test]
fn create_plan_extractor_rejects_unbounded_noncanonical_and_ambiguous_metadata() {
    let extract = |raw: String| extract_gateway_create_utxos_outputs(raw, Network::Regtest);
    for raw in [
        String::new(),
        format!(" {}", CREATE.trim()),
        format!("{}\n", CREATE.trim()),
        "A".repeat(1_333_345),
        BTC.trim().into(),
        RGB.trim().into(),
    ] {
        assert!(extract(raw).is_err());
    }
    assert!(extract_gateway_create_utxos_outputs(CREATE.trim().into(), Network::Mainnet).is_err());
    let mut trailing = STANDARD.decode(CREATE.trim()).unwrap();
    trailing.push(0);
    assert!(extract(STANDARD.encode(trailing)).is_err());
    for case in 0..15 {
        let mut prepared = parse_test_psbt(CREATE.trim());
        match case {
            0 => prepared.outputs[0].tap_key_origins.clear(),
            1 => prepared.outputs[0].tap_internal_key = None,
            2 => prepared.unsigned_tx.output[0].value = Amount::from_sat(329),
            3 => prepared.unsigned_tx.output[0].value = Amount::from_sat(u64::from(u32::MAX) + 1),
            4 => {
                prepared.outputs[1] = prepared.outputs[0].clone();
                prepared.unsigned_tx.output[1] = prepared.unsigned_tx.output[0].clone();
            }
            5 => prepared.unsigned_tx.output[0].script_pubkey = bitcoin::ScriptBuf::new(),
            6 => prepared.outputs[0].redeem_script = Some(bitcoin::ScriptBuf::new()),
            7 => prepared.version = 2,
            8 => prepared.unsigned_tx.version = bitcoin::transaction::Version::ONE,
            9..=12 => {
                let path: bitcoin::bip32::DerivationPath = match case {
                    9 => "m/86'/827167'/0'/1/6",
                    10 => "m/86'/827167'/0'/0/1000001",
                    11 => "m/86'/827167'/1'/0/6",
                    _ => "m/86'/827167'/0'/0/6'",
                }
                .parse()
                .unwrap();
                prepared.outputs[0]
                    .tap_key_origins
                    .values_mut()
                    .next()
                    .unwrap()
                    .1
                    .1 = path;
            }
            13 => {
                let path = prepared.outputs[0]
                    .tap_key_origins
                    .values()
                    .next()
                    .unwrap()
                    .1
                    .1
                    .clone();
                prepared.outputs[1]
                    .tap_key_origins
                    .values_mut()
                    .next()
                    .unwrap()
                    .1
                    .1 = path;
            }
            14 => {
                prepared.outputs[0]
                    .tap_key_origins
                    .values_mut()
                    .next()
                    .unwrap()
                    .0
                    .push(bitcoin::TapLeafHash::from_script(
                        bitcoin::Script::new(),
                        bitcoin::taproot::LeafVersion::TapScript,
                    ));
            }
            _ => unreachable!(),
        }
        assert!(extract(encode_test_psbt(&prepared)).is_err(), "case {case}");
    }
}

#[test]
fn rgb_blind_context_conflicts_and_unknown_commitments_fail_closed() {
    let mut context = intent(OperationKind::OnchainSend);
    context.rgb.as_mut().unwrap().witness_amount_sats = Some(1_000);
    assert!(validate(RGB, context).is_err());
    let mut context = intent(OperationKind::OnchainSend);
    context
        .rgb
        .as_mut()
        .unwrap()
        .invoice
        .push_str("?expiry=1800000000");
    assert!(validate(RGB, context).is_err());
    let mut context = intent(OperationKind::OnchainSend);
    context.rgb.as_mut().unwrap().invoice =
        format!("{ASSET}/~/~/{}", BLIND.replacen("bcrt:", "bc:", 1));
    assert!(validate(RGB, context).is_err());
    let mut context = intent(OperationKind::OnchainSend);
    context.rgb.as_mut().unwrap().invoice = format!("{ASSET}/~/ae/{BLIND}");
    assert!(validate(RGB, context).is_err());
    let mut context = intent(OperationKind::OnchainSend);
    context
        .rgb
        .as_mut()
        .unwrap()
        .invoice
        .push_str("?assignment_name=inflationAllowance");
    assert!(validate(RGB, context).is_err());
    let mut prepared = parse_test_psbt(RGB.trim());
    prepared.proprietary.insert(
        bitcoin::psbt::raw::ProprietaryKey {
            prefix: b"RGB".to_vec(),
            subtype: 255,
            key: vec![],
        },
        vec![0],
    );
    assert!(
        validate(
            &encode_test_psbt(&prepared),
            intent(OperationKind::OnchainSend)
        )
        .is_err()
    );
    let mut prepared = parse_test_psbt(RGB.trim());
    let key = prepared.outputs[0]
        .proprietary
        .keys()
        .find(|key| key.prefix == b"OPRET")
        .unwrap()
        .clone();
    prepared.outputs[0].proprietary.get_mut(&key).unwrap()[0] ^= 1;
    assert!(
        validate(
            &encode_test_psbt(&prepared),
            intent(OperationKind::OnchainSend)
        )
        .is_err()
    );
}

#[test]
fn rgb_witness_script_is_derived_from_invoice_not_server_metadata() {
    let mut context = intent(OperationKind::OnchainSend);
    let invoice = "rgb:~/~/~/bcrt:wvout:Be7zrr7L-VM9RP6X-pBRQduY-5ujGu~3-GqxY7TP-Tk5abpc-6cGRkrQ";
    let decoded = decode_rgb_invoice(invoice.into()).unwrap();
    let script = crate::invoice::witness_script(&decoded.recipient_id).unwrap();
    let address = bitcoin::Address::from_script(&script, bitcoin::Network::Regtest).unwrap();
    context.rgb.as_mut().unwrap().invoice = invoice.into();
    context.rgb.as_mut().unwrap().witness_amount_sats = Some(1_000);
    context.intent.recipients = vec![Recipient {
        address: address.to_string(),
        amount_sats: 1_000,
    }];
    let mut prepared = parse_test_psbt(RGB.trim());
    prepared.unsigned_tx.output[1].value -= Amount::from_sat(1_000);
    prepared.unsigned_tx.output.push(TxOut {
        value: Amount::from_sat(1_000),
        script_pubkey: script,
    });
    prepared.outputs.push(bitcoin::psbt::Output::default());
    assert!(validate(&encode_test_psbt(&prepared), context.clone()).is_ok());
    context.intent.recipients[0].address = intent(OperationKind::SendBtc).intent.recipients[0]
        .address
        .clone();
    assert!(validate(&encode_test_psbt(&prepared), context).is_err());
}

#[test]
fn gateway_context_digest_binds_every_additive_authorization() {
    let context = intent(OperationKind::OnchainSend);
    let report = validate(RGB, context.clone()).unwrap();
    for changed in 0..6 {
        let mut altered = context.clone();
        match changed {
            0 => altered.max_block_height += 1,
            1 => altered.target_fee_rate_msat_per_vbyte += 1,
            2 => altered.rgb.as_mut().unwrap().donation = true,
            3 => altered.rgb.as_mut().unwrap().min_confirmations += 1,
            4 => altered.rgb.as_mut().unwrap().skip_sync = true,
            _ => altered.rgb.as_mut().unwrap().validation_time_unix_seconds += 1,
        }
        assert_ne!(
            validate(RGB, altered).unwrap().intent_sha256,
            report.intent_sha256
        );
    }
}

#[test]
fn a_self_recipient_is_consumed_once_before_counting_owned_change() {
    let mut prepared = parse_test_psbt(BTC.trim());
    let mut context = intent(OperationKind::SendBtc);
    let change_script = prepared.unsigned_tx.output[1].script_pubkey.clone();
    context.intent.recipients[0].address =
        bitcoin::Address::from_script(&change_script, bitcoin::Network::Regtest)
            .unwrap()
            .to_string();
    prepared.unsigned_tx.output[0].script_pubkey = change_script.clone();
    prepared.outputs[0] = prepared.outputs[1].clone();
    // This self-send and its single change are legitimate.
    assert!(validate(&encode_test_psbt(&prepared), context.clone()).is_ok());
    prepared.unsigned_tx.output[1].value -= Amount::from_sat(40_000);
    prepared.unsigned_tx.output.push(TxOut {
        value: Amount::from_sat(40_000),
        script_pubkey: change_script,
    });
    prepared.outputs.push(prepared.outputs[0].clone());
    // The second 40k occurrence is change, not a second match of one recipient.
    assert!(validate(&encode_test_psbt(&prepared), context).is_err());
}

#[test]
fn all_gateway_operations_preserve_common_sighash_ownership_and_shape_floors() {
    for (raw, kind) in [
        (BTC, OperationKind::SendBtc),
        (CREATE, OperationKind::CreateUtxos),
        (RGB, OperationKind::OnchainSend),
    ] {
        let prepared = parse_test_psbt(raw.trim());
        for sighash in [2, 3, 0x80, 0x81, 0x82, 0x83, 0xff] {
            let mut changed = prepared.clone();
            changed.inputs[0].sighash_type =
                Some(bitcoin::psbt::PsbtSighashType::from_u32(sighash));
            assert!(validate(&encode_test_psbt(&changed), intent(kind)).is_err());
        }
        let mut changed = prepared.clone();
        changed.inputs[0].sighash_type = Some(bitcoin::psbt::PsbtSighashType::from_u32(1));
        let signed = signer(Network::Regtest, BIP86_MNEMONIC)
            .sign_gateway_psbt(encode_test_psbt(&changed), intent(kind))
            .unwrap();
        assert_eq!(
            parse_test_psbt(&signed.signed_psbt_base64).inputs[0]
                .final_script_witness
                .as_ref()
                .unwrap()
                .iter()
                .next()
                .unwrap()
                .len(),
            65
        );
        for mutation in 0..6 {
            let mut changed = prepared.clone();
            match mutation {
                0 => changed.unsigned_tx.version = Version::ONE,
                1 => changed.unsigned_tx.input[0].sequence = Sequence::MAX,
                2 => changed.inputs[0].witness_utxo = None,
                3 => changed.inputs[0].tap_key_origins.clear(),
                4 => changed.inputs[0].tap_internal_key = None,
                _ => changed.unsigned_tx.input[0].previous_output = OutPoint::null(),
            }
            assert!(validate(&encode_test_psbt(&changed), intent(kind)).is_err());
        }
        assert!(
            signer(Network::Regtest, RN_VECTOR_MNEMONIC)
                .validate_gateway_psbt(raw.trim().into(), intent(kind))
                .is_err()
        );
    }
}

#[test]
fn witness_recipient_helper_rejects_blind_network_dust_and_supply_mismatches() {
    let invoice = "rgb:~/~/~/bcrt:wvout:Be7zrr7L-VM9RP6X-pBRQduY-5ujGu~3-GqxY7TP-Tk5abpc-6cGRkrQ";
    let recipient = rgb_invoice_witness_recipient(invoice.into(), Network::Regtest, 1_000).unwrap();
    assert_eq!(recipient.amount_sats, 1_000);
    assert!(recipient.address.starts_with("bcrt1p"));
    assert!(rgb_invoice_witness_recipient(invoice.into(), Network::Mainnet, 1_000).is_err());
    for amount in [0, 329, bitcoin::Amount::MAX_MONEY.to_sat() + 1, u64::MAX] {
        assert!(rgb_invoice_witness_recipient(invoice.into(), Network::Regtest, amount).is_err());
    }
    assert!(
        rgb_invoice_witness_recipient(format!("{ASSET}/~/~/{BLIND}"), Network::Regtest, 1_000)
            .is_err()
    );
}

#[test]
fn component_fee_rounding_supports_two_and_128_inputs_without_unbounded_slack() {
    for count in [2_usize, 128] {
        let mut prepared = parse_test_psbt(BTC.trim());
        let input = prepared.unsigned_tx.input[0].clone();
        let input_map = prepared.inputs[0].clone();
        prepared.unsigned_tx.input = (0..count)
            .map(|index| {
                let mut next = input.clone();
                next.previous_output.vout = u32::try_from(index).unwrap();
                next
            })
            .collect();
        prepared.inputs = vec![input_map; count];
        for input in &mut prepared.inputs {
            input.witness_utxo.as_mut().unwrap().value = Amount::from_sat(100_000);
        }
        // P2TR input component ceil(231wu * 2sat/vB / 4)=116 sat.
        // Non-input base including marker/flag and both outputs is 386wu,
        // with the 172wu change component separately rounded: 107+86 sats.
        let budget = 193 + u64::try_from(count).unwrap() * 116;
        prepared.unsigned_tx.output[1].value =
            Amount::from_sat(u64::try_from(count).unwrap() * 100_000 - 40_000 - budget);
        assert_eq!(
            validate(&encode_test_psbt(&prepared), intent(OperationKind::SendBtc))
                .unwrap()
                .fee_sats,
            budget
        );
        prepared.unsigned_tx.output[1].value -= Amount::ONE_SAT;
        assert!(validate(&encode_test_psbt(&prepared), intent(OperationKind::SendBtc)).is_err());
    }
}

#[test]
fn create_output_compactsize_252_253_and_256_boundaries_remain_exact() {
    let signer = signer(Network::Regtest, BIP86_MNEMONIC);
    let root = signer.root().unwrap();
    let fingerprint = master_fingerprint(&root);
    for colored_count in [251_u32, 252, 255] {
        let mut prepared = parse_test_psbt(CREATE.trim());
        let change = prepared.unsigned_tx.output[4].clone();
        let change_map = prepared.outputs[4].clone();
        prepared.unsigned_tx.output.clear();
        prepared.outputs.clear();
        for index in 0..colored_count {
            let path = address_path(
                Network::Regtest,
                AccountKind::Colored,
                Keychain::External,
                index,
            )
            .unwrap();
            let (key, script) = derive_owned_script(&root, Network::Regtest, &path).unwrap();
            prepared.unsigned_tx.output.push(TxOut {
                value: Amount::from_sat(1_000),
                script_pubkey: script,
            });
            let mut output = bitcoin::psbt::Output {
                tap_internal_key: Some(key),
                ..Default::default()
            };
            output
                .tap_key_origins
                .insert(key, (vec![], (fingerprint, path)));
            prepared.outputs.push(output);
        }
        prepared.unsigned_tx.output.push(change);
        prepared.outputs.push(change_map);
        let unsigned_bytes =
            if colored_count == 251 { 10 } else { 12 } + 41 + (u64::from(colored_count) + 1) * 43;
        let budget = unsigned_bytes * 2 + 35;
        prepared.unsigned_tx.output.last_mut().unwrap().value =
            Amount::from_sat(1_000_000 - u64::from(colored_count) * 1_000 - budget);
        let mut context = intent(OperationKind::CreateUtxos);
        context.create_utxos = Some(CreateUtxosAuthorization {
            min_count: colored_count,
            max_count: colored_count,
            size_sats: 1_000,
            exact_outputs: None,
        });
        let report = validate(&encode_test_psbt(&prepared), context.clone()).unwrap();
        assert_eq!(report.fee_sats, budget);
        assert_eq!(report.output_count, colored_count + 1);
        assert_eq!(report.estimated_vbytes, unsigned_bytes + 17);
        prepared.unsigned_tx.output.last_mut().unwrap().value -= Amount::ONE_SAT;
        assert!(validate(&encode_test_psbt(&prepared), context).is_err());
    }
}

#[test]
fn no_change_does_not_authorize_dust_to_be_added_to_fee() {
    let mut prepared = parse_test_psbt(BTC.trim());
    prepared.unsigned_tx.output.pop();
    prepared.outputs.pop();
    // The one-recipient, one-input transaction has 94 unsigned bytes. Its
    // component-rounded 2 sat/vB budget is 223 sats, independent of funding.
    prepared.inputs[0].witness_utxo.as_mut().unwrap().value = Amount::from_sat(40_223);
    assert_eq!(
        validate(&encode_test_psbt(&prepared), intent(OperationKind::SendBtc))
            .unwrap()
            .fee_sats,
        223
    );
    prepared.inputs[0].witness_utxo.as_mut().unwrap().value += Amount::ONE_SAT;
    assert!(validate(&encode_test_psbt(&prepared), intent(OperationKind::SendBtc)).is_err());
}
