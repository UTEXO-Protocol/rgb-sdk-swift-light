use bitcoin::{Network as BitcoinNetwork, NetworkKind};

pub const DERIVATION_PROFILE_V1: &str = "utexo.bip86.v1";
pub const VANILLA_COIN_MAINNET: u32 = 0;
pub const VANILLA_COIN_TESTNET: u32 = 1;
pub const COLORED_COIN_MAINNET: u32 = 827_166;
pub const COLORED_COIN_TESTNET: u32 = 827_167;
pub const PURPOSE_BIP86: u32 = 86;
pub const ACCOUNT_ZERO: u32 = 0;

#[derive(Clone, Copy, Debug, PartialEq, Eq, uniffi::Enum)]
pub enum Network {
    Mainnet,
    Testnet,
    Testnet4,
    Signet,
    Regtest,
    Utexo,
}

impl Network {
    pub(crate) const fn bitcoin(self) -> BitcoinNetwork {
        match self {
            Self::Mainnet => BitcoinNetwork::Bitcoin,
            Self::Testnet => BitcoinNetwork::Testnet,
            Self::Testnet4 => BitcoinNetwork::Testnet4,
            Self::Signet | Self::Utexo => BitcoinNetwork::Signet,
            Self::Regtest => BitcoinNetwork::Regtest,
        }
    }

    pub(crate) const fn network_kind(self) -> NetworkKind {
        match self {
            Self::Mainnet => NetworkKind::Main,
            Self::Testnet | Self::Testnet4 | Self::Signet | Self::Regtest | Self::Utexo => {
                NetworkKind::Test
            }
        }
    }

    pub(crate) const fn coin_type(self, account: AccountKind) -> u32 {
        match (self, account) {
            (Self::Mainnet, AccountKind::Vanilla) => VANILLA_COIN_MAINNET,
            (Self::Mainnet, AccountKind::Colored) => COLORED_COIN_MAINNET,
            (_, AccountKind::Vanilla) => VANILLA_COIN_TESTNET,
            (_, AccountKind::Colored) => COLORED_COIN_TESTNET,
        }
    }

    pub(crate) const fn chain_name(self) -> &'static str {
        match self {
            Self::Mainnet => "mainnet",
            Self::Testnet => "testnet",
            Self::Testnet4 => "testnet4",
            Self::Signet | Self::Utexo => "signet",
            Self::Regtest => "regtest",
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, uniffi::Enum)]
pub enum AccountKind {
    Vanilla,
    Colored,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, uniffi::Enum)]
pub enum Keychain {
    External,
    Change,
}

impl Keychain {
    pub(crate) const fn index(self) -> u32 {
        match self {
            Self::External => 0,
            Self::Change => 1,
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, uniffi::Enum)]
pub enum OperationKind {
    SendBtc,
    CreateUtxos,
    OnchainSend,
    Inflate,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, uniffi::Enum)]
pub enum RbfPolicy {
    Required,
    Allowed,
    Forbidden,
}

/// The beneficiary construction encoded by an RGB invoice.
///
/// This is intentionally explicit so the mobile facades can verify that a
/// gateway response for a blind or witness receive request returned the same
/// recipient mode in the encoded invoice.
#[derive(Clone, Copy, Debug, PartialEq, Eq, uniffi::Enum)]
pub enum RgbInvoiceRecipientType {
    Blind,
    Witness,
}

/// RN-compatible assignment categories returned by RGB invoice decoding.
#[derive(Clone, Copy, Debug, PartialEq, Eq, uniffi::Enum)]
pub enum RgbInvoiceAssignmentKind {
    Fungible,
    NonFungible,
    InflationRight,
    Any,
}

/// Assignment requested by an RGB invoice. `amount` is present only for
/// fungible and inflation-right assignments and retains the complete `u64`
/// domain without crossing a floating-point boundary.
#[derive(Clone, Debug, PartialEq, Eq, uniffi::Record)]
pub struct RgbInvoiceAssignment {
    pub kind: RgbInvoiceAssignmentKind,
    pub amount: Option<u64>,
}

/// The assignment state literally encoded in the invoice path, before the
/// RGB-lib compatibility projection into [`RgbInvoiceAssignment`].
///
/// This evidence is required when validating a receive response: for example,
/// an omitted state under a known NIA schema projects to `Fungible(0)`, while
/// an explicit amount with no schema and no assignment name projects to `Any`.
#[derive(Clone, Copy, Debug, PartialEq, Eq, uniffi::Enum)]
pub enum RgbInvoiceEncodedStateKind {
    Omitted,
    Amount,
    NonFungible,
}

#[derive(Clone, Debug, PartialEq, Eq, uniffi::Record)]
pub struct RgbInvoiceEncodedState {
    pub kind: RgbInvoiceEncodedStateKind,
    pub amount: Option<u64>,
}

/// Locally decoded, compatibility-shaped RGB invoice data.
///
/// The original invoice is intentionally not duplicated in this native DTO;
/// Swift and Kotlin already hold the bounded input value and attach it to their
/// public `InvoiceData` model.
#[derive(Clone, Debug, PartialEq, Eq, uniffi::Record)]
pub struct DecodedRgbInvoice {
    pub recipient_id: String,
    pub recipient_type: RgbInvoiceRecipientType,
    pub asset_schema: Option<String>,
    pub asset_id: Option<String>,
    pub network: Network,
    pub assignment: RgbInvoiceAssignment,
    pub encoded_state: RgbInvoiceEncodedState,
    pub assignment_name: Option<String>,
    pub expiration_timestamp: Option<i64>,
    pub transport_endpoints: Vec<String>,
}

#[derive(Clone, Debug, PartialEq, Eq, uniffi::Record)]
pub struct KeyScope {
    pub account: AccountKind,
    pub keychain: Keychain,
}

#[derive(Clone, Debug, PartialEq, Eq, uniffi::Record)]
pub struct Recipient {
    pub address: String,
    pub amount_sats: u64,
}

/// Default-deny signing constraints. All numeric limits are exact integers.
/// Fee rate is milli-satoshis per virtual byte to avoid floating point at the
/// authorization boundary (1.5 sat/vB = 1500).
#[derive(Clone, Debug, PartialEq, Eq, uniffi::Record)]
pub struct SigningPolicy {
    pub max_psbt_bytes: u32,
    pub max_inputs: u32,
    pub max_outputs: u32,
    pub max_child_index: u32,
    pub max_absolute_fee_sats: u64,
    pub max_fee_rate_msat_per_vbyte: u64,
    pub rbf: RbfPolicy,
    pub expected_lock_time: Option<u32>,
    pub expected_sequence: Option<u32>,
    pub allow_sighash_all: bool,
    pub allow_unknown_fields: bool,
    pub allowed_proprietary_prefixes: Vec<String>,
    pub max_op_return_outputs: u32,
    pub max_op_return_script_bytes: u32,
    pub allowed_input_scopes: Vec<KeyScope>,
    pub allowed_change_scopes: Vec<KeyScope>,
}

#[derive(Clone, Debug, PartialEq, Eq, uniffi::Record)]
pub struct SigningIntent {
    pub operation_id: String,
    pub idempotency_key: String,
    pub network: Network,
    pub operation: OperationKind,
    pub recipients: Vec<Recipient>,
    pub policy: SigningPolicy,
}

/// Additive, explicitly selected profile for the RGB-lib branch-0 builder.
/// `max_block_height` must come from an independently trusted chain context,
/// never from the prepared PSBT. The fee target is not the independent hard
/// maximum in `intent.policy`; both constraints are enforced.
#[derive(Clone, Debug, PartialEq, Eq, uniffi::Record)]
pub struct GatewaySigningIntent {
    pub intent: SigningIntent,
    pub max_block_height: u32,
    pub target_fee_rate_msat_per_vbyte: u64,
    pub create_utxos: Option<CreateUtxosAuthorization>,
    pub rgb: Option<RgbBitcoinAuthorization>,
}

/// Locally authorized range of newly created colored outputs. Bounds must be
/// derived from the caller's request, not copied from the server's PSBT.
#[derive(Clone, Debug, PartialEq, Eq, uniffi::Record)]
pub struct CreateUtxosAuthorization {
    pub min_count: u32,
    pub max_count: u32,
    pub size_sats: u64,
    pub exact_outputs: Option<Vec<GatewayOwnedOutput>>,
}

/// An optional exact reservation of a created colored output, re-derived
/// locally and compared to the transaction. Vanilla change is not in this plan.
#[derive(Clone, Debug, PartialEq, Eq, uniffi::Record)]
pub struct GatewayOwnedOutput {
    pub account: AccountKind,
    pub keychain: Keychain,
    pub index: u32,
    pub amount_sats: u64,
}

/// Bitcoin authorization and immutable caller context for a fungible RGB
/// send. This deliberately does not claim RGB transition/consignment validity.
/// The gateway remains trusted for RGB state and transition correctness.
#[derive(Clone, Debug, PartialEq, Eq, uniffi::Record)]
pub struct RgbBitcoinAuthorization {
    pub invoice: String,
    pub asset_id: String,
    pub amount: u64,
    pub witness_amount_sats: Option<u64>,
    pub witness_blinding: Option<u64>,
    pub donation: bool,
    pub min_confirmations: u32,
    pub skip_sync: bool,
    pub validation_time_unix_seconds: u64,
}

#[derive(Clone, Debug, PartialEq, Eq, uniffi::Record)]
pub struct WalletIdentity {
    pub network: Network,
    pub chain_network: String,
    pub derivation_profile: String,
    pub master_fingerprint: String,
    pub xpub: String,
    pub account_xpub_vanilla: String,
    pub account_xpub_colored: String,
}

/// Compatibility-shaped key result. `mnemonic` and `xpriv` are secrets and the
/// native facades wrap them in redacting secret-bearing types before exposing
/// them to applications.
#[derive(Clone, PartialEq, Eq, uniffi::Record)]
pub struct GeneratedKeys {
    pub mnemonic: String,
    pub xpub: String,
    pub account_xpub_vanilla: String,
    pub account_xpub_colored: String,
    pub master_fingerprint: String,
    pub xpriv: String,
}

impl std::fmt::Debug for GeneratedKeys {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter
            .debug_struct("GeneratedKeys")
            .field("mnemonic", &"[REDACTED]")
            .field("xpub", &self.xpub)
            .field("account_xpub_vanilla", &self.account_xpub_vanilla)
            .field("account_xpub_colored", &self.account_xpub_colored)
            .field("master_fingerprint", &self.master_fingerprint)
            .field("xpriv", &"[REDACTED]")
            .finish()
    }
}

#[derive(Clone, Debug, PartialEq, Eq, uniffi::Record)]
pub struct DerivedAddress {
    pub address: String,
    pub script_pubkey_hex: String,
    pub derivation_path: String,
    pub internal_key_hex: String,
}

#[derive(Clone, Debug, PartialEq, Eq, uniffi::Record)]
pub struct ValidationReport {
    pub psbt_sha256: String,
    pub intent_sha256: String,
    pub unsigned_txid: String,
    pub total_input_sats: u64,
    pub total_output_sats: u64,
    pub fee_sats: u64,
    pub estimated_vbytes: u64,
    pub fee_rate_msat_per_vbyte: u64,
    pub external_output_sats: u64,
    pub change_sats: u64,
    pub input_count: u32,
    pub output_count: u32,
    pub op_return_count: u32,
}

#[derive(Clone, Debug, PartialEq, Eq, uniffi::Record)]
pub struct SigningResult {
    pub signed_psbt_base64: String,
    pub signed_input_count: u32,
    pub validation: ValidationReport,
}

/// Returns the fail-closed baseline for a plain Bitcoin send.
#[must_use]
#[uniffi::export]
pub fn default_signing_policy() -> SigningPolicy {
    SigningPolicy {
        max_psbt_bytes: 1_000_000,
        max_inputs: 128,
        max_outputs: 256,
        max_child_index: 1_000_000,
        max_absolute_fee_sats: 1_000_000,
        max_fee_rate_msat_per_vbyte: 100_000,
        // Profile v1 deliberately freezes transaction-level behavior. A
        // backend that needs different locktime/sequence semantics must
        // negotiate a new profile instead of silently widening this one.
        rbf: RbfPolicy::Required,
        expected_lock_time: Some(0),
        expected_sequence: Some(0xffff_fffd),
        allow_sighash_all: true,
        allow_unknown_fields: false,
        allowed_proprietary_prefixes: Vec::new(),
        max_op_return_outputs: 0,
        max_op_return_script_bytes: 83,
        // A plain BTC send must never select the RGB/colorable account: doing
        // so could burn an allocation that cannot be detected from Bitcoin
        // transaction data alone.
        allowed_input_scopes: vec![
            KeyScope {
                account: AccountKind::Vanilla,
                keychain: Keychain::External,
            },
            KeyScope {
                account: AccountKind::Vanilla,
                keychain: Keychain::Change,
            },
        ],
        allowed_change_scopes: vec![KeyScope {
            account: AccountKind::Vanilla,
            keychain: Keychain::Change,
        }],
    }
}

/// Baseline for the additive `utexo.psbt.rgb-lib.v1` profile. This policy is
/// accepted only by `validate_gateway_psbt` / `sign_gateway_psbt`, which also
/// require independent height, fee target and operation-specific context.
#[must_use]
#[uniffi::export]
pub fn gateway_signing_policy(operation: OperationKind) -> SigningPolicy {
    let mut policy = default_signing_policy();
    policy.expected_lock_time = None;
    let vanilla = KeyScope {
        account: AccountKind::Vanilla,
        keychain: Keychain::External,
    };
    let colored = KeyScope {
        account: AccountKind::Colored,
        keychain: Keychain::External,
    };
    policy.allowed_input_scopes = vec![vanilla.clone()];
    policy.allowed_change_scopes = vec![vanilla];
    match operation {
        OperationKind::CreateUtxos => policy.allowed_change_scopes.push(colored),
        OperationKind::OnchainSend => {
            policy.allowed_input_scopes.push(colored.clone());
            policy.allowed_change_scopes.push(colored);
            policy.max_op_return_outputs = 1;
            policy.max_op_return_script_bytes = 34;
            policy.allowed_proprietary_prefixes = vec!["RGB".into(), "MPC".into(), "OPRET".into()];
        }
        // No gateway inflation primitive or retained fixture is available.
        // The operation validator rejects this even with a constructed policy.
        OperationKind::Inflate | OperationKind::SendBtc => {}
    }
    policy
}
