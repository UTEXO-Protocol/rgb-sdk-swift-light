use std::collections::HashSet;
use std::io::Cursor;
use std::str::FromStr;

use base64::Engine;
use base64::engine::general_purpose::STANDARD;
use bitcoin::bip32::{ChildNumber, DerivationPath, KeySource, Xpriv};
use bitcoin::hashes::{Hash, sha256};
use bitcoin::psbt::{Input as PsbtInput, Output as PsbtOutput, Psbt};
use bitcoin::transaction::Version;
use bitcoin::{Address, Amount, Script, Transaction, TxOut, Witness};
use sha2::{Digest, Sha256};

use crate::error::{Result, SignerError, invalid_argument, invalid_psbt, rejected};
use crate::keys::{derive_owned_script, master_fingerprint};
use crate::model::{
    ACCOUNT_ZERO, AccountKind, KeyScope, Keychain, Network, OperationKind, PURPOSE_BIP86,
    RbfPolicy, SigningIntent, SigningPolicy, ValidationReport,
};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct OwnedPath {
    account: AccountKind,
    keychain: Keychain,
    index: u32,
}

pub(crate) struct ValidatedPsbt {
    pub psbt: Psbt,
    pub report: ValidationReport,
}

pub(crate) fn decode_psbt(value: &str, max_bytes: u32) -> Result<(Vec<u8>, Psbt)> {
    let trimmed = value.trim();
    if trimmed != value {
        return Err(invalid_psbt("PSBT must not contain surrounding whitespace"));
    }
    if trimmed.is_empty() {
        return Err(invalid_argument("psbt must not be empty"));
    }
    let max_encoded = usize::try_from(max_bytes)
        .unwrap_or(usize::MAX)
        .saturating_mul(4)
        .saturating_div(3)
        .saturating_add(8);
    if trimmed.len() > max_encoded {
        return Err(rejected("PSBT exceeds the encoded size limit"));
    }
    let bytes = STANDARD
        .decode(trimmed)
        .map_err(|_| invalid_psbt("base64 decoding failed"))?;
    if STANDARD.encode(&bytes) != trimmed {
        return Err(invalid_psbt("PSBT must use canonical padded base64"));
    }
    if bytes.len() > usize::try_from(max_bytes).unwrap_or(usize::MAX) {
        return Err(rejected("PSBT exceeds the decoded size limit"));
    }
    let mut cursor = Cursor::new(bytes.as_slice());
    let psbt = Psbt::deserialize_from_reader(&mut cursor)
        .map_err(|_| invalid_psbt("binary PSBT parsing failed"))?;
    if usize::try_from(cursor.position()).unwrap_or(usize::MAX) != bytes.len() {
        return Err(invalid_psbt("trailing bytes are not permitted"));
    }
    Ok((bytes, psbt))
}

/// A parser, not an ownership/authorization oracle. Keep the path interpretation
/// shared with the signer, and never turn this result into a `ValidationReport`.
pub(crate) fn extract_gateway_create_outputs(
    value: &str,
    network: Network,
) -> Result<Vec<crate::model::GatewayOwnedOutput>> {
    let policy = crate::model::gateway_signing_policy(OperationKind::CreateUtxos);
    let (_, psbt) = decode_psbt(value, policy.max_psbt_bytes)?;
    validate_shape(&psbt, &policy)?;
    validate_input_extra_maps(&policy, &psbt)?;
    validate_transaction_policy(&psbt.unsigned_tx, &policy)?;
    for (index, input) in psbt.inputs.iter().enumerate() {
        validate_unsigned_input(index, input)?;
    }
    let mut plan = Vec::new();
    let mut colored_indices = HashSet::new();
    let mut scripts = HashSet::new();
    let mut vanilla_count = 0_u32;
    let mut total = 0_u64;
    let secp = bitcoin::secp256k1::Secp256k1::verification_only();
    for (index, (txout, output)) in psbt
        .unsigned_tx
        .output
        .iter()
        .zip(&psbt.outputs)
        .enumerate()
    {
        validate_output_extra_maps(&policy, output, index)?;
        if !txout.script_pubkey.is_p2tr()
            || output.redeem_script.is_some()
            || output.witness_script.is_some()
            || !output.bip32_derivation.is_empty()
            || output.tap_tree.is_some()
            || output.tap_key_origins.len() != 1
            || !scripts.insert(txout.script_pubkey.clone())
        {
            return Err(rejected(
                "create output has ambiguous or unsupported metadata",
            ));
        }
        let (key, (leaves, (_, path))) = output
            .tap_key_origins
            .iter()
            .next()
            .ok_or_else(|| invalid_psbt("create output origin is missing"))?;
        if !leaves.is_empty()
            || output.tap_internal_key != Some(*key)
            || bitcoin::ScriptBuf::new_p2tr(&secp, *key, None) != txout.script_pubkey
        {
            return Err(rejected(
                "create output key metadata does not match its script",
            ));
        }
        let hint = parse_owned_path(network, path, policy.max_child_index)?;
        if hint.keychain != Keychain::External {
            return Err(rejected(
                "RGB-lib create outputs must use derivation branch zero",
            ));
        }
        let amount = txout.value.to_sat();
        total = total
            .checked_add(amount)
            .ok_or_else(|| rejected("create output amount overflow"))?;
        if amount < txout.script_pubkey.minimal_non_dust().to_sat()
            || total > Amount::MAX_MONEY.to_sat()
        {
            return Err(rejected("create output amount is outside supported bounds"));
        }
        if hint.account == AccountKind::Colored {
            if amount > u64::from(u32::MAX) || !colored_indices.insert(hint.index) {
                return Err(rejected("invalid or duplicate colored output hint"));
            }
            plan.push(crate::model::GatewayOwnedOutput {
                account: hint.account,
                keychain: hint.keychain,
                index: hint.index,
                amount_sats: amount,
            });
        } else {
            vanilla_count += 1;
        }
    }
    if plan.is_empty() || plan.len() > 255 || vanilla_count > 1 {
        return Err(rejected(
            "create preparation has an invalid colored/change output count",
        ));
    }
    Ok(plan)
}

#[allow(clippy::too_many_lines)] // Ordered validation pipeline is easier to audit in one place.
pub(crate) fn validate(
    root: &Xpriv,
    signer_network: Network,
    psbt_base64: &str,
    intent: &SigningIntent,
) -> Result<ValidatedPsbt> {
    validate_profile(root, signer_network, psbt_base64, intent, None)
}

#[allow(clippy::too_many_lines)]
pub(crate) fn validate_gateway(
    root: &Xpriv,
    signer_network: Network,
    psbt_base64: &str,
    gateway: &crate::model::GatewaySigningIntent,
) -> Result<ValidatedPsbt> {
    crate::gateway::validate_intent(gateway)?;
    validate_profile(
        root,
        signer_network,
        psbt_base64,
        &gateway.intent,
        Some(gateway),
    )
}

#[allow(clippy::too_many_lines)]
fn validate_profile(
    root: &Xpriv,
    signer_network: Network,
    psbt_base64: &str,
    intent: &SigningIntent,
    gateway: Option<&crate::model::GatewaySigningIntent>,
) -> Result<ValidatedPsbt> {
    validate_intent(signer_network, intent, gateway.is_some())?;
    let (raw_psbt, psbt) = decode_psbt(psbt_base64, intent.policy.max_psbt_bytes)?;
    validate_shape(&psbt, &intent.policy)?;
    validate_input_extra_maps(&intent.policy, &psbt)?;

    let fingerprint = master_fingerprint(root);
    let mut input_total = 0_u64;
    let mut seen_outpoints = HashSet::with_capacity(psbt.inputs.len());
    let mut signature_sizes = Vec::with_capacity(psbt.inputs.len());

    for (index, (tx_input, input)) in psbt.unsigned_tx.input.iter().zip(&psbt.inputs).enumerate() {
        if tx_input.previous_output.is_null() {
            return Err(rejected(format!("input {index} has a null outpoint")));
        }
        if !seen_outpoints.insert(tx_input.previous_output) {
            return Err(rejected(format!("input {index} repeats an outpoint")));
        }
        validate_unsigned_input(index, input)?;
        let witness_utxo = input
            .witness_utxo
            .as_ref()
            .ok_or_else(|| rejected(format!("input {index} is missing witness UTXO")))?;
        validate_non_witness_utxo(
            index,
            tx_input.previous_output.vout,
            tx_input.previous_output.txid,
            input,
            witness_utxo,
        )?;

        let owned = validate_taproot_metadata(
            root,
            signer_network,
            fingerprint,
            input.tap_internal_key,
            &input.tap_key_origins,
            &witness_utxo.script_pubkey,
            &intent.policy.allowed_input_scopes,
            intent.policy.max_child_index,
            index,
            "input",
        )?;
        let _ = owned;

        let sighash = input
            .sighash_type
            .map_or(0_u32, bitcoin::psbt::PsbtSighashType::to_u32);
        match sighash {
            0 => signature_sizes.push(64_usize),
            1 if intent.policy.allow_sighash_all => signature_sizes.push(65_usize),
            _ => {
                return Err(rejected(format!(
                    "input {index} uses a forbidden Taproot sighash type"
                )));
            }
        }
        input_total = input_total
            .checked_add(witness_utxo.value.to_sat())
            .ok_or_else(|| invalid_psbt("input amount overflow"))?;
        if input_total > Amount::MAX_MONEY.to_sat() {
            return Err(rejected("input amounts exceed the Bitcoin supply bound"));
        }
    }

    validate_transaction_policy(&psbt.unsigned_tx, &intent.policy)?;
    let output_analysis = validate_outputs(root, signer_network, fingerprint, &psbt, intent)?;
    let output_total = output_analysis.total;
    let fee = input_total
        .checked_sub(output_total)
        .ok_or_else(|| rejected("outputs exceed inputs"))?;
    if fee > intent.policy.max_absolute_fee_sats {
        return Err(rejected("absolute fee exceeds policy"));
    }

    let estimated_vbytes = estimate_signed_vbytes(&psbt.unsigned_tx, &signature_sizes)?;
    let fee_times_1000 = fee
        .checked_mul(1_000)
        .ok_or_else(|| invalid_psbt("fee-rate calculation overflow"))?;
    let max_fee_numerator = intent
        .policy
        .max_fee_rate_msat_per_vbyte
        .checked_mul(estimated_vbytes)
        .ok_or_else(|| invalid_psbt("fee-rate policy overflow"))?;
    if fee_times_1000 > max_fee_numerator {
        return Err(rejected("fee rate exceeds policy"));
    }
    let fee_rate = fee_times_1000
        .checked_add(estimated_vbytes.saturating_sub(1))
        .ok_or_else(|| invalid_psbt("fee-rate calculation overflow"))?
        / estimated_vbytes;

    let psbt_sha256 = hex_sha256(&raw_psbt);
    let mut intent_sha256 = intent_digest(intent)?;
    if let Some(gateway) = gateway {
        crate::gateway::validate_transaction(&psbt, gateway, fee, &signature_sizes)?;
        intent_sha256 = crate::gateway::intent_digest(gateway, &intent_sha256)?;
    }

    Ok(ValidatedPsbt {
        report: ValidationReport {
            psbt_sha256,
            intent_sha256,
            unsigned_txid: psbt.unsigned_tx.compute_txid().to_string(),
            total_input_sats: input_total,
            total_output_sats: output_total,
            fee_sats: fee,
            estimated_vbytes,
            fee_rate_msat_per_vbyte: fee_rate,
            external_output_sats: output_analysis.external,
            change_sats: output_analysis.change,
            input_count: u32::try_from(psbt.inputs.len())
                .map_err(|_| invalid_psbt("input count overflow"))?,
            output_count: u32::try_from(psbt.outputs.len())
                .map_err(|_| invalid_psbt("output count overflow"))?,
            op_return_count: output_analysis.op_returns,
        },
        psbt,
    })
}

#[allow(clippy::too_many_lines)] // Keeps every mandatory profile floor visibly contiguous.
fn validate_intent(signer_network: Network, intent: &SigningIntent, gateway: bool) -> Result<()> {
    if signer_network != intent.network {
        return Err(SignerError::InvalidNetwork {
            reason: "intent network does not match signer".to_owned(),
        });
    }
    validate_identifier("operationId", &intent.operation_id)?;
    validate_identifier("idempotencyKey", &intent.idempotency_key)?;
    if intent.policy.max_psbt_bytes < 100 || intent.policy.max_psbt_bytes > 1_000_000 {
        return Err(invalid_argument(
            "maxPsbtBytes must be between 100 and 1000000",
        ));
    }
    if intent.policy.max_inputs == 0 || intent.policy.max_outputs == 0 {
        return Err(invalid_argument("input and output limits must be positive"));
    }
    if intent.policy.max_inputs > 128 || intent.policy.max_outputs > 256 {
        return Err(invalid_argument(
            "input and output limits cannot exceed 128 and 256",
        ));
    }
    if intent.policy.max_child_index > 1_000_000 {
        return Err(invalid_argument(
            "maximum child index cannot exceed 1000000",
        ));
    }
    if intent.policy.max_absolute_fee_sats > 2_100_000_000_000_000 {
        return Err(invalid_argument("maximum fee exceeds the Bitcoin supply"));
    }
    if intent.policy.max_fee_rate_msat_per_vbyte == 0 {
        return Err(invalid_argument("maximum fee rate must be positive"));
    }
    if intent.policy.max_absolute_fee_sats > 1_000_000 {
        return Err(invalid_argument(
            "maximum absolute fee cannot exceed 1000000 sats",
        ));
    }
    if intent.policy.max_fee_rate_msat_per_vbyte > 100_000 {
        return Err(invalid_argument(
            "maximum fee rate cannot exceed 100 sat/vB",
        ));
    }
    if intent.policy.allowed_input_scopes.is_empty() {
        return Err(invalid_argument("at least one input scope is required"));
    }
    if intent.policy.allowed_input_scopes.len() > 16
        || intent.policy.allowed_change_scopes.len() > 16
    {
        return Err(invalid_argument("too many key scopes"));
    }
    if intent.recipients.len() > usize::try_from(intent.policy.max_outputs).unwrap_or(usize::MAX) {
        return Err(invalid_argument("recipient count exceeds output policy"));
    }
    for (index, recipient) in intent.recipients.iter().enumerate() {
        if recipient.address.len() > 128 {
            return Err(invalid_argument(format!(
                "recipient {index} address is too long"
            )));
        }
    }
    if gateway {
        // The additive profile validates its own mandatory operation floors
        // before entering this common ownership/amount/signature pipeline.
        return Ok(());
    }
    match intent.operation {
        OperationKind::SendBtc => {
            if intent.recipients.is_empty() {
                return Err(invalid_argument("sendBtc requires at least one recipient"));
            }
            // This is a mandatory safety floor, independent of the
            // caller-supplied limits. A compromised backend or accidental
            // facade configuration cannot authorize spending colored keys in
            // a BTC-only operation.
            if intent
                .policy
                .allowed_input_scopes
                .iter()
                .any(|scope| scope.account != AccountKind::Vanilla)
            {
                return Err(rejected(
                    "sendBtc cannot authorize inputs from the colored account",
                ));
            }
            if intent.policy.rbf != RbfPolicy::Required
                || intent.policy.expected_lock_time != Some(0)
                || intent.policy.expected_sequence != Some(0xffff_fffd)
            {
                return Err(rejected(
                    "sendBtc profile v1 requires locktime 0 and sequence 0xfffffffd",
                ));
            }
            if intent.policy.allow_unknown_fields
                || !intent.policy.allowed_proprietary_prefixes.is_empty()
            {
                return Err(rejected(
                    "sendBtc profile v1 forbids unknown and proprietary PSBT fields",
                ));
            }
            if intent.policy.max_op_return_outputs != 0 {
                return Err(rejected("sendBtc profile v1 forbids OP_RETURN outputs"));
            }
            if intent.policy.allowed_change_scopes.iter().any(|scope| {
                scope.account != AccountKind::Vanilla || scope.keychain != Keychain::Change
            }) {
                return Err(rejected(
                    "sendBtc change must use the vanilla change keychain",
                ));
            }
        }
        OperationKind::CreateUtxos => {
            return Err(rejected(
                "createUtxos signing is unavailable until its exact owned-output contract is negotiated",
            ));
        }
        OperationKind::OnchainSend | OperationKind::Inflate => {
            return Err(rejected(
                "RGB signing requires validated transition evidence and is unavailable in profile v1",
            ));
        }
    }
    Ok(())
}

fn validate_identifier(field: &str, value: &str) -> Result<()> {
    if value.is_empty() || value.len() > 128 {
        return Err(invalid_argument(format!(
            "{field} must contain between 1 and 128 bytes"
        )));
    }
    if !value
        .bytes()
        .all(|byte| byte.is_ascii_alphanumeric() || matches!(byte, b'-' | b'_' | b'.' | b':'))
    {
        return Err(invalid_argument(format!(
            "{field} contains unsupported characters"
        )));
    }
    Ok(())
}

fn validate_shape(psbt: &Psbt, policy: &SigningPolicy) -> Result<()> {
    if psbt.version != 0 {
        return Err(rejected("only PSBT v0 is supported by signing profile v1"));
    }
    if psbt.unsigned_tx.version != Version::TWO {
        return Err(rejected("transaction version must be 2"));
    }
    if psbt.inputs.is_empty() || psbt.inputs.len() != psbt.unsigned_tx.input.len() {
        return Err(invalid_psbt("input maps do not match transaction inputs"));
    }
    if psbt.outputs.is_empty() || psbt.outputs.len() != psbt.unsigned_tx.output.len() {
        return Err(invalid_psbt("output maps do not match transaction outputs"));
    }
    if psbt.inputs.len() > usize::try_from(policy.max_inputs).unwrap_or(usize::MAX) {
        return Err(rejected("input count exceeds policy"));
    }
    if psbt.outputs.len() > usize::try_from(policy.max_outputs).unwrap_or(usize::MAX) {
        return Err(rejected("output count exceeds policy"));
    }
    validate_extra_maps(policy, &psbt.proprietary, &psbt.unknown, "global")?;
    if !psbt.xpub.is_empty() {
        return Err(rejected("global xpub records are not accepted"));
    }
    Ok(())
}

fn validate_unsigned_input(index: usize, input: &PsbtInput) -> Result<()> {
    if !input.partial_sigs.is_empty()
        || input.tap_key_sig.is_some()
        || !input.tap_script_sigs.is_empty()
        || input.final_script_sig.is_some()
        || input.final_script_witness.is_some()
    {
        return Err(rejected(format!(
            "input {index} is already signed or finalized"
        )));
    }
    if input.redeem_script.is_some()
        || input.witness_script.is_some()
        || !input.bip32_derivation.is_empty()
        || !input.tap_scripts.is_empty()
        || input.tap_merkle_root.is_some()
    {
        return Err(rejected(format!(
            "input {index} is not a BIP86 key-path-only input"
        )));
    }
    if !input.ripemd160_preimages.is_empty()
        || !input.sha256_preimages.is_empty()
        || !input.hash160_preimages.is_empty()
        || !input.hash256_preimages.is_empty()
    {
        return Err(rejected(format!(
            "input {index} contains unsupported preimages"
        )));
    }
    Ok(())
}

fn validate_non_witness_utxo(
    index: usize,
    vout: u32,
    txid: bitcoin::Txid,
    input: &PsbtInput,
    witness_utxo: &TxOut,
) -> Result<()> {
    if let Some(transaction) = &input.non_witness_utxo {
        if transaction.compute_txid() != txid {
            return Err(rejected(format!(
                "input {index} non-witness transaction ID does not match"
            )));
        }
        let previous = transaction
            .output
            .get(usize::try_from(vout).unwrap_or(usize::MAX))
            .ok_or_else(|| rejected(format!("input {index} previous output is missing")))?;
        if previous != witness_utxo {
            return Err(rejected(format!(
                "input {index} witness and non-witness UTXO data disagree"
            )));
        }
    }
    Ok(())
}

#[allow(clippy::too_many_arguments)]
fn validate_taproot_metadata(
    root: &Xpriv,
    network: Network,
    expected_fingerprint: bitcoin::bip32::Fingerprint,
    tap_internal_key: Option<bitcoin::secp256k1::XOnlyPublicKey>,
    origins: &std::collections::BTreeMap<
        bitcoin::secp256k1::XOnlyPublicKey,
        (Vec<bitcoin::TapLeafHash>, KeySource),
    >,
    script_pubkey: &Script,
    scopes: &[KeyScope],
    max_child_index: u32,
    index: usize,
    location: &str,
) -> Result<OwnedPath> {
    if !script_pubkey.is_p2tr() {
        return Err(rejected(format!("{location} {index} is not P2TR")));
    }
    let internal_key = tap_internal_key
        .ok_or_else(|| rejected(format!("{location} {index} has no Taproot internal key")))?;
    if origins.len() != 1 {
        return Err(rejected(format!(
            "{location} {index} must contain exactly one Taproot key origin"
        )));
    }
    let (origin_key, (leaf_hashes, (fingerprint, path))) = origins
        .iter()
        .next()
        .ok_or_else(|| invalid_psbt("Taproot origin unexpectedly missing"))?;
    if !leaf_hashes.is_empty() || *origin_key != internal_key {
        return Err(rejected(format!(
            "{location} {index} contains a script-path origin"
        )));
    }
    if *fingerprint != expected_fingerprint {
        return Err(rejected(format!(
            "{location} {index} belongs to another master key"
        )));
    }
    let owned = parse_owned_path(network, path, max_child_index)?;
    if !scopes
        .iter()
        .any(|scope| scope.account == owned.account && scope.keychain == owned.keychain)
    {
        return Err(rejected(format!(
            "{location} {index} uses a derivation scope forbidden by policy"
        )));
    }
    let (expected_key, expected_script) = derive_owned_script(root, network, path)?;
    if expected_key != internal_key || expected_script.as_script() != script_pubkey {
        return Err(rejected(format!(
            "{location} {index} key metadata does not match its script"
        )));
    }
    Ok(owned)
}

fn parse_owned_path(network: Network, path: &DerivationPath, max_index: u32) -> Result<OwnedPath> {
    let children: Vec<ChildNumber> = path.into_iter().copied().collect();
    if children.len() != 5 {
        return Err(rejected("derivation path must contain exactly five levels"));
    }
    let purpose = hardened_index(children[0])?;
    let coin = hardened_index(children[1])?;
    let account_index = hardened_index(children[2])?;
    let branch = normal_index(children[3])?;
    let index = normal_index(children[4])?;
    if purpose != PURPOSE_BIP86 || account_index != ACCOUNT_ZERO {
        return Err(rejected(
            "derivation path is outside profile utexo.bip86.v1",
        ));
    }
    if index > max_index {
        return Err(rejected("child index exceeds policy"));
    }
    let account = if coin == network.coin_type(AccountKind::Vanilla) {
        AccountKind::Vanilla
    } else if coin == network.coin_type(AccountKind::Colored) {
        AccountKind::Colored
    } else {
        return Err(rejected("coin type is outside profile utexo.bip86.v1"));
    };
    let keychain = match branch {
        0 => Keychain::External,
        1 => Keychain::Change,
        _ => return Err(rejected("keychain must be 0 or 1")),
    };
    Ok(OwnedPath {
        account,
        keychain,
        index,
    })
}

fn hardened_index(child: ChildNumber) -> Result<u32> {
    match child {
        ChildNumber::Hardened { index } => Ok(index),
        ChildNumber::Normal { .. } => Err(rejected("expected a hardened derivation level")),
    }
}

fn normal_index(child: ChildNumber) -> Result<u32> {
    match child {
        ChildNumber::Normal { index } => Ok(index),
        ChildNumber::Hardened { .. } => Err(rejected("expected a normal derivation level")),
    }
}

fn validate_transaction_policy(transaction: &Transaction, policy: &SigningPolicy) -> Result<()> {
    if transaction
        .input
        .iter()
        .any(|input| input.sequence.is_relative_lock_time())
    {
        return Err(rejected("BIP68 relative-lock sequences are not supported"));
    }
    let rbf = transaction
        .input
        .iter()
        .any(|input| input.sequence.is_rbf());
    match policy.rbf {
        RbfPolicy::Required if !rbf => return Err(rejected("RBF is required")),
        RbfPolicy::Forbidden if rbf => return Err(rejected("RBF is forbidden")),
        _ => {}
    }
    if let Some(expected) = policy.expected_lock_time {
        if transaction.lock_time.to_consensus_u32() != expected {
            return Err(rejected("locktime does not match intent"));
        }
    }
    if let Some(expected) = policy.expected_sequence {
        if transaction
            .input
            .iter()
            .any(|input| input.sequence.to_consensus_u32() != expected)
        {
            return Err(rejected("input sequence does not match intent"));
        }
    }
    if transaction
        .input
        .iter()
        .any(|input| !input.script_sig.is_empty() || !input.witness.is_empty())
    {
        return Err(invalid_psbt("unsigned transaction contains signatures"));
    }
    Ok(())
}

struct OutputAnalysis {
    total: u64,
    external: u64,
    change: u64,
    op_returns: u32,
}

#[allow(clippy::too_many_lines)]
fn validate_outputs(
    root: &Xpriv,
    network: Network,
    fingerprint: bitcoin::bip32::Fingerprint,
    psbt: &Psbt,
    intent: &SigningIntent,
) -> Result<OutputAnalysis> {
    let mut expected = Vec::with_capacity(intent.recipients.len());
    for (index, recipient) in intent.recipients.iter().enumerate() {
        let address = Address::from_str(recipient.address.trim())
            .map_err(|_| invalid_argument(format!("recipient {index} has an invalid address")))?
            .require_network(network.bitcoin())
            .map_err(|_| SignerError::InvalidNetwork {
                reason: format!("recipient {index} belongs to another network"),
            })?;
        if recipient.amount_sats == 0 || recipient.amount_sats > Amount::MAX_MONEY.to_sat() {
            return Err(invalid_argument(format!(
                "recipient {index} amount must be positive and within the Bitcoin supply bound"
            )));
        }
        let minimum = address.script_pubkey().minimal_non_dust().to_sat();
        if recipient.amount_sats < minimum {
            return Err(invalid_argument(format!(
                "recipient {index} amount is below dust"
            )));
        }
        expected.push((address.script_pubkey(), recipient.amount_sats, false));
    }

    let mut result = OutputAnalysis {
        total: 0,
        external: 0,
        change: 0,
        op_returns: 0,
    };
    for (index, (txout, output)) in psbt
        .unsigned_tx
        .output
        .iter()
        .zip(&psbt.outputs)
        .enumerate()
    {
        result.total = result
            .total
            .checked_add(txout.value.to_sat())
            .ok_or_else(|| invalid_psbt("output amount overflow"))?;
        if result.total > Amount::MAX_MONEY.to_sat() {
            return Err(rejected("output amounts exceed the Bitcoin supply bound"));
        }
        validate_output_extra_maps(&intent.policy, output, index)?;

        if txout.script_pubkey.is_op_return() {
            result.op_returns = result
                .op_returns
                .checked_add(1)
                .ok_or_else(|| invalid_psbt("OP_RETURN count overflow"))?;
            if txout.value != Amount::ZERO {
                return Err(rejected(format!(
                    "OP_RETURN output {index} must carry zero satoshis"
                )));
            }
            if txout.script_pubkey.len()
                > usize::try_from(intent.policy.max_op_return_script_bytes).unwrap_or(usize::MAX)
            {
                return Err(rejected(format!("OP_RETURN output {index} is too large")));
            }
            if output_has_derivation(output) {
                return Err(rejected(format!(
                    "OP_RETURN output {index} must not contain key derivation metadata"
                )));
            }
            continue;
        }

        if let Some((_, _, matched)) = expected.iter_mut().find(|(script, amount, matched)| {
            !*matched && script == &txout.script_pubkey && *amount == txout.value.to_sat()
        }) {
            *matched = true;
            result.external = result
                .external
                .checked_add(txout.value.to_sat())
                .ok_or_else(|| invalid_psbt("external amount overflow"))?;
            continue;
        }

        if txout.value.to_sat() < txout.script_pubkey.minimal_non_dust().to_sat() {
            return Err(rejected(format!("change output {index} is below dust")));
        }
        if output.redeem_script.is_some()
            || output.witness_script.is_some()
            || !output.bip32_derivation.is_empty()
            || output.tap_tree.is_some()
        {
            return Err(rejected(format!(
                "change output {index} is not BIP86 key-path-only"
            )));
        }
        validate_taproot_metadata(
            root,
            network,
            fingerprint,
            output.tap_internal_key,
            &output.tap_key_origins,
            &txout.script_pubkey,
            &intent.policy.allowed_change_scopes,
            intent.policy.max_child_index,
            index,
            "output",
        )?;
        result.change = result
            .change
            .checked_add(txout.value.to_sat())
            .ok_or_else(|| invalid_psbt("change amount overflow"))?;
    }

    if expected.iter().any(|(_, _, matched)| !*matched) {
        return Err(rejected(
            "one or more intended recipient outputs are missing",
        ));
    }
    if result.op_returns > intent.policy.max_op_return_outputs {
        return Err(rejected("OP_RETURN output count exceeds policy"));
    }
    Ok(result)
}

fn output_has_derivation(output: &PsbtOutput) -> bool {
    output.tap_internal_key.is_some()
        || !output.tap_key_origins.is_empty()
        || !output.bip32_derivation.is_empty()
        || output.tap_tree.is_some()
}

fn validate_output_extra_maps(
    policy: &SigningPolicy,
    output: &PsbtOutput,
    index: usize,
) -> Result<()> {
    validate_extra_maps(
        policy,
        &output.proprietary,
        &output.unknown,
        &format!("output {index}"),
    )
}

fn validate_extra_maps(
    policy: &SigningPolicy,
    proprietary: &std::collections::BTreeMap<bitcoin::psbt::raw::ProprietaryKey, Vec<u8>>,
    unknown: &std::collections::BTreeMap<bitcoin::psbt::raw::Key, Vec<u8>>,
    location: &str,
) -> Result<()> {
    if !policy.allow_unknown_fields && !unknown.is_empty() {
        return Err(rejected(format!("{location} contains unknown PSBT fields")));
    }
    for key in proprietary.keys() {
        let prefix = std::str::from_utf8(&key.prefix)
            .map_err(|_| rejected(format!("{location} has a non-UTF8 proprietary prefix")))?;
        if !policy
            .allowed_proprietary_prefixes
            .iter()
            .any(|allowed| allowed == prefix)
        {
            return Err(rejected(format!(
                "{location} contains a forbidden proprietary PSBT field"
            )));
        }
    }
    Ok(())
}

fn validate_input_extra_maps(policy: &SigningPolicy, psbt: &Psbt) -> Result<()> {
    for (index, input) in psbt.inputs.iter().enumerate() {
        validate_extra_maps(
            policy,
            &input.proprietary,
            &input.unknown,
            &format!("input {index}"),
        )?;
    }
    Ok(())
}

fn estimate_signed_vbytes(transaction: &Transaction, signature_sizes: &[usize]) -> Result<u64> {
    let mut signed = transaction.clone();
    if signed.input.len() != signature_sizes.len() {
        return Err(invalid_psbt(
            "signature estimate does not match input count",
        ));
    }
    for (input, size) in signed.input.iter_mut().zip(signature_sizes) {
        input.witness = Witness::from_slice(&[vec![0_u8; *size]]);
    }
    if signed.weight() > Transaction::MAX_STANDARD_WEIGHT {
        return Err(rejected("signed transaction exceeds standard weight"));
    }
    u64::try_from(signed.vsize()).map_err(|_| invalid_psbt("transaction size overflow"))
}

fn hex_sha256(bytes: &[u8]) -> String {
    sha256::Hash::hash(bytes).to_string()
}

fn intent_digest(intent: &SigningIntent) -> Result<String> {
    let mut hash = Sha256::new();
    hash.update(b"UTEXO_SIGNING_INTENT_V1\0");
    hash_string(&mut hash, &intent.operation_id)?;
    hash_string(&mut hash, &intent.idempotency_key)?;
    hash.update([intent.network as u8, intent.operation as u8]);
    hash.update(
        u32::try_from(intent.recipients.len())
            .map_err(|_| invalid_argument("too many recipients"))?
            .to_be_bytes(),
    );
    for recipient in &intent.recipients {
        hash_string(&mut hash, recipient.address.trim())?;
        hash.update(recipient.amount_sats.to_be_bytes());
    }
    let policy = &intent.policy;
    hash.update(policy.max_psbt_bytes.to_be_bytes());
    hash.update(policy.max_inputs.to_be_bytes());
    hash.update(policy.max_outputs.to_be_bytes());
    hash.update(policy.max_child_index.to_be_bytes());
    hash.update(policy.max_absolute_fee_sats.to_be_bytes());
    hash.update(policy.max_fee_rate_msat_per_vbyte.to_be_bytes());
    hash.update([policy.rbf as u8]);
    hash.update(policy.expected_lock_time.unwrap_or(u32::MAX).to_be_bytes());
    hash.update(policy.expected_sequence.unwrap_or(u32::MAX).to_be_bytes());
    hash.update([
        u8::from(policy.allow_sighash_all),
        u8::from(policy.allow_unknown_fields),
    ]);
    hash.update(policy.max_op_return_outputs.to_be_bytes());
    hash.update(policy.max_op_return_script_bytes.to_be_bytes());
    hash_scopes(&mut hash, &policy.allowed_input_scopes)?;
    hash_scopes(&mut hash, &policy.allowed_change_scopes)?;
    hash.update(
        u32::try_from(policy.allowed_proprietary_prefixes.len())
            .map_err(|_| invalid_argument("too many proprietary prefixes"))?
            .to_be_bytes(),
    );
    for prefix in &policy.allowed_proprietary_prefixes {
        hash_string(&mut hash, prefix)?;
    }
    Ok(format!("{:x}", hash.finalize()))
}

fn hash_scopes(hash: &mut Sha256, scopes: &[KeyScope]) -> Result<()> {
    hash.update(
        u32::try_from(scopes.len())
            .map_err(|_| invalid_argument("too many key scopes"))?
            .to_be_bytes(),
    );
    for scope in scopes {
        hash.update([scope.account as u8, scope.keychain as u8]);
    }
    Ok(())
}

pub(crate) fn hash_string(hash: &mut Sha256, value: &str) -> Result<()> {
    let bytes = value.as_bytes();
    hash.update(
        u32::try_from(bytes.len())
            .map_err(|_| invalid_argument("intent string is too long"))?
            .to_be_bytes(),
    );
    hash.update(bytes);
    Ok(())
}
