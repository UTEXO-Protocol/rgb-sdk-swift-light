//! Additive RGB-lib builder Bitcoin authorization. Opaque RGB transitions stay
//! server-trusted; recognizing their PSBT envelopes is not RGB validation.

use std::{collections::HashSet, str::FromStr};

use bitcoin::{Address, Witness, bip32::ChildNumber, psbt::Psbt};
use sha2::{Digest, Sha256};

use crate::{
    error::{Result, invalid_argument, rejected},
    invoice::{decode_rgb_invoice, witness_script},
    model::{
        AccountKind, GatewaySigningIntent, Keychain, OperationKind, RgbInvoiceEncodedStateKind,
        RgbInvoiceRecipientType, gateway_signing_policy,
    },
    policy::hash_string,
};

pub(crate) fn validate_intent(gateway: &GatewaySigningIntent) -> Result<()> {
    let intent = &gateway.intent;
    let policy = &intent.policy;
    if gateway.max_block_height >= 500_000_000 {
        return Err(invalid_argument(
            "maximum block height must be a block height, not a timestamp",
        ));
    }
    if gateway.target_fee_rate_msat_per_vbyte == 0
        || gateway.target_fee_rate_msat_per_vbyte > policy.max_fee_rate_msat_per_vbyte
    {
        return Err(invalid_argument(
            "fee target must be positive and not exceed the independent rate cap",
        ));
    }
    let baseline = gateway_signing_policy(intent.operation);
    if policy.rbf != baseline.rbf
        || policy.expected_sequence != baseline.expected_sequence
        || policy.expected_lock_time.is_some()
        || policy.allow_unknown_fields
        || policy.allowed_input_scopes != baseline.allowed_input_scopes
        || policy.allowed_change_scopes != baseline.allowed_change_scopes
        || policy.allowed_proprietary_prefixes != baseline.allowed_proprietary_prefixes
        || policy.max_op_return_outputs != baseline.max_op_return_outputs
        || policy.max_op_return_script_bytes > baseline.max_op_return_script_bytes
    {
        return Err(rejected(
            "policy does not match the branch-0 RGB-lib signing profile",
        ));
    }
    match intent.operation {
        OperationKind::SendBtc => {
            if intent.recipients.is_empty()
                || gateway.create_utxos.is_some()
                || gateway.rgb.is_some()
            {
                return Err(invalid_argument(
                    "BTC send requires recipients and no unrelated operation context",
                ));
            }
        }
        OperationKind::CreateUtxos => {
            let create = gateway
                .create_utxos
                .as_ref()
                .ok_or_else(|| invalid_argument("create-UTXOs authorization is required"))?;
            if !intent.recipients.is_empty()
                || gateway.rgb.is_some()
                || create.min_count == 0
                || create.min_count > create.max_count
                || create.max_count > 255
                || create.max_count > policy.max_outputs
                || create.size_sats < 330
                || create.size_sats > u64::from(u32::MAX)
            {
                return Err(invalid_argument(
                    "invalid create-UTXOs owned-output authorization",
                ));
            }
            if let Some(outputs) = &create.exact_outputs {
                let mut indices = HashSet::new();
                if outputs.len() < create.min_count as usize
                    || outputs.len() > create.max_count as usize
                    || outputs.iter().any(|output| {
                        output.account != AccountKind::Colored
                            || output.keychain != Keychain::External
                            || output.index > policy.max_child_index
                            || output.amount_sats != create.size_sats
                            || !indices.insert(output.index)
                    })
                {
                    return Err(invalid_argument("invalid exact created-output plan"));
                }
            }
        }
        OperationKind::OnchainSend => validate_rgb_intent(gateway)?,
        OperationKind::Inflate => {
            return Err(rejected(
                "inflation has no qualified gateway Bitcoin profile",
            ));
        }
    }
    Ok(())
}

fn validate_rgb_intent(gateway: &GatewaySigningIntent) -> Result<()> {
    let intent = &gateway.intent;
    let rgb = gateway
        .rgb
        .as_ref()
        .ok_or_else(|| invalid_argument("RGB Bitcoin authorization is required"))?;
    if gateway.create_utxos.is_some()
        || rgb.amount == 0
        || rgb.asset_id.len() > 128
        || rgb.min_confirmations > 255
        || rgb.validation_time_unix_seconds == 0
        || rgb.validation_time_unix_seconds > i64::MAX as u64
    {
        return Err(invalid_argument("invalid RGB caller context"));
    }
    let decoded = decode_rgb_invoice(rgb.invoice.clone())?;
    if decoded.network.bitcoin() != intent.network.bitcoin() {
        return Err(rejected(
            "RGB invoice network differs from the signing network",
        ));
    }
    if decoded.expiration_timestamp.is_some_and(|expiry| {
        expiry <= 0
            || u64::try_from(expiry)
                .map_or(true, |expiry| expiry <= rgb.validation_time_unix_seconds)
    }) {
        return Err(rejected(
            "RGB invoice is expired at the caller validation time",
        ));
    }
    if decoded
        .asset_id
        .as_ref()
        .is_some_and(|asset| asset != &rgb.asset_id)
        || decoded
            .encoded_state
            .amount
            .is_some_and(|amount| amount != rgb.amount)
        || decoded.encoded_state.kind == RgbInvoiceEncodedStateKind::NonFungible
        || decoded.asset_schema.as_deref() == Some("Uda")
        || decoded
            .assignment_name
            .as_ref()
            .is_some_and(|name| name != "assetOwner")
    {
        return Err(rejected(
            "RGB invoice conflicts with the fungible send authorization",
        ));
    }
    // Validate even an override for an open invoice as a canonical contract ID.
    let contract = rgb
        .asset_id
        .strip_prefix("rgb:")
        .ok_or_else(|| invalid_argument("RGB asset identifier is invalid"))?;
    let asset_probe = decode_rgb_invoice(format!("rgb:{contract}/~/~/{}", decoded.recipient_id))?;
    if asset_probe.asset_id.as_deref() != Some(rgb.asset_id.as_str()) {
        return Err(invalid_argument("RGB asset identifier is not canonical"));
    }
    match decoded.recipient_type {
        RgbInvoiceRecipientType::Blind => {
            if !intent.recipients.is_empty()
                || rgb.witness_amount_sats.is_some()
                || rgb.witness_blinding.is_some()
            {
                return Err(rejected(
                    "blind RGB send cannot authorize external Bitcoin outputs or witness data",
                ));
            }
        }
        RgbInvoiceRecipientType::Witness => {
            let amount = rgb
                .witness_amount_sats
                .ok_or_else(|| invalid_argument("witness satoshi amount is required"))?;
            if intent.recipients.len() != 1 || intent.recipients[0].amount_sats != amount {
                return Err(rejected(
                    "witness Bitcoin recipient amount is not bound to the caller intent",
                ));
            }
            let script = witness_script(&decoded.recipient_id)?;
            let address = Address::from_str(&intent.recipients[0].address)
                .map_err(|_| invalid_argument("witness Bitcoin address is invalid"))?
                .require_network(intent.network.bitcoin())
                .map_err(|_| rejected("witness Bitcoin address has a different network"))?;
            if address.script_pubkey() != script {
                return Err(rejected(
                    "witness Bitcoin output differs from the invoice beneficiary",
                ));
            }
        }
    }
    Ok(())
}

pub(crate) fn validate_transaction(
    psbt: &Psbt,
    gateway: &GatewaySigningIntent,
    fee: u64,
    signature_sizes: &[usize],
) -> Result<()> {
    if psbt.unsigned_tx.lock_time.to_consensus_u32() > gateway.max_block_height {
        return Err(rejected(
            "transaction locktime exceeds the independently authorized block height",
        ));
    }
    let has_owned_output = validate_owned_outputs(psbt, gateway)?;
    // BDK estimates 65-byte Schnorr signatures, then rounds base, each input
    // and an optional P2TR change output separately. Summing first and rounding
    // once incorrectly rejects legitimate multi-input transactions. This is a
    // derivable component bound, not an arbitrary dust/tolerance allowance.
    let mut estimated = psbt.unsigned_tx.clone();
    for (input, size) in estimated.input.iter_mut().zip(signature_sizes) {
        input.witness = Witness::from_slice(&[vec![0_u8; (*size).max(65)]]);
    }
    let rounded_fee = |weight: u64| -> Result<u64> {
        gateway
            .target_fee_rate_msat_per_vbyte
            .checked_mul(weight)
            .and_then(|value| value.checked_add(3_999))
            .map(|value| value / 4_000)
            .ok_or_else(|| rejected("target fee overflow"))
    };
    let mut base_weight = estimated.weight().to_wu();
    let mut target_budget = 0_u64;
    for input in &estimated.input {
        let weight = input.segwit_weight().to_wu();
        base_weight = base_weight
            .checked_sub(weight)
            .ok_or_else(|| rejected("target weight underflow"))?;
        target_budget = target_budget
            .checked_add(rounded_fee(weight)?)
            .ok_or_else(|| rejected("target fee overflow"))?;
    }
    if has_owned_output {
        // Any native drain/change output allowed by this profile is P2TR:
        // 8-byte amount + 1-byte length + 34-byte script, at 4 weight units/byte.
        let change_weight = 43 * 4;
        base_weight = base_weight
            .checked_sub(change_weight)
            .ok_or_else(|| rejected("target weight underflow"))?;
        target_budget = target_budget
            .checked_add(rounded_fee(change_weight)?)
            .ok_or_else(|| rejected("target fee overflow"))?;
    }
    target_budget = target_budget
        .checked_add(rounded_fee(base_weight)?)
        .ok_or_else(|| rejected("target fee overflow"))?;
    if fee > target_budget {
        return Err(rejected(
            "fee exceeds the weight-rounded caller target budget",
        ));
    }
    if gateway.intent.operation == OperationKind::OnchainSend {
        validate_rgb_maps(psbt)?;
    }
    Ok(())
}

fn validate_owned_outputs(psbt: &Psbt, gateway: &GatewaySigningIntent) -> Result<bool> {
    let intent = &gateway.intent;
    let mut colored = 0_u32;
    let mut vanilla = 0_u32;
    let mut owned_scripts = HashSet::new();
    let mut matched_recipients = vec![false; intent.recipients.len()];
    for (txout, output) in psbt.unsigned_tx.output.iter().zip(&psbt.outputs) {
        // The common validator has already verified every non-recipient output
        // by deriving its exact owned script, fingerprint and key scope.
        let external = intent
            .recipients
            .iter()
            .enumerate()
            .position(|(index, recipient)| {
                !matched_recipients[index]
                    && recipient.amount_sats == txout.value.to_sat()
                    && Address::from_str(recipient.address.trim()).is_ok_and(|address| {
                        address.assume_checked().script_pubkey() == txout.script_pubkey
                    })
            });
        if let Some(index) = external {
            matched_recipients[index] = true;
            continue;
        }
        if txout.script_pubkey.is_op_return() {
            continue;
        }
        if !owned_scripts.insert(txout.script_pubkey.clone()) {
            return Err(rejected("owned outputs must use distinct scripts"));
        }
        let (_, (_, (_, path))) = output
            .tap_key_origins
            .iter()
            .next()
            .ok_or_else(|| rejected("owned output origin is missing"))?;
        let coin = path.as_ref().get(1).copied();
        if coin
            == Some(ChildNumber::Hardened {
                index: intent.network.coin_type(AccountKind::Colored),
            })
        {
            colored += 1;
            if gateway
                .create_utxos
                .as_ref()
                .is_some_and(|create| txout.value.to_sat() != create.size_sats)
            {
                return Err(rejected(
                    "created colored output size differs from caller authorization",
                ));
            }
            if let Some(outputs) = gateway
                .create_utxos
                .as_ref()
                .and_then(|create| create.exact_outputs.as_ref())
            {
                if !outputs.iter().any(|output| {
                    path.as_ref().get(4)
                        == Some(&ChildNumber::Normal {
                            index: output.index,
                        })
                        && txout.value.to_sat() == output.amount_sats
                }) {
                    return Err(rejected(
                        "colored output differs from the exact locally checked reservation plan",
                    ));
                }
            }
        } else {
            vanilla += 1;
        }
    }
    if vanilla > 1 {
        return Err(rejected(
            "the RGB-lib profile permits at most one vanilla change output",
        ));
    }
    if let Some(create) = &gateway.create_utxos {
        if colored < create.min_count || colored > create.max_count {
            return Err(rejected(
                "created colored output count differs from caller authorization",
            ));
        }
        if create
            .exact_outputs
            .as_ref()
            .is_some_and(|outputs| outputs.len() != colored as usize)
        {
            return Err(rejected("an exactly authorized created output is missing"));
        }
    } else if colored > 1 {
        return Err(rejected(
            "the single-asset RGB profile permits at most one colored change output",
        ));
    }
    Ok(vanilla + colored > 0)
}

/// This is only an envelope/Bitcoin commitment consistency check. The encoded
/// transition and MPC proof remain opaque, server-trusted data.
fn validate_rgb_maps(psbt: &Psbt) -> Result<()> {
    let mut transitions = 0;
    let mut close_method = 0;
    let mut bindings = 0;
    for (key, value) in &psbt.proprietary {
        let accepted = key.prefix == b"RGB"
            && match key.subtype {
                1 => {
                    transitions += 1;
                    key.key.len() == 32 && !value.is_empty()
                }
                2 => {
                    close_method += 1;
                    key.key.is_empty() && value.as_slice() == [0]
                }
                4 => {
                    bindings += 1;
                    key.key.len() == 32 && !value.is_empty()
                }
                _ => false,
            };
        if !accepted {
            return Err(rejected("unsupported global RGB PSBT envelope"));
        }
    }
    if transitions == 0
        || bindings == 0
        || close_method != 1
        || psbt
            .inputs
            .iter()
            .any(|input| !input.proprietary.is_empty())
    {
        return Err(rejected("incomplete or unsupported RGB PSBT envelope"));
    }
    let mut commitments = 0;
    for (txout, output) in psbt.unsigned_tx.output.iter().zip(&psbt.outputs) {
        if !txout.script_pubkey.is_op_return() {
            if !output.proprietary.is_empty() {
                return Err(rejected(
                    "RGB metadata is only supported on its OP_RETURN output",
                ));
            }
            continue;
        }
        let script = txout.script_pubkey.as_bytes();
        if script.len() != 34 || script[0..2] != [0x6a, 0x20] {
            return Err(rejected(
                "RGB commitment must be a canonical 32-byte OP_RETURN push",
            ));
        }
        commitments += 1;
        let mut opret = false;
        let mut mpc_commitment = false;
        let mut mpc_messages = 0;
        let mut mpc_entropy = false;
        let mut mpc_proof = false;
        for (key, value) in &output.proprietary {
            let accepted = match (key.prefix.as_slice(), key.subtype) {
                (b"OPRET", 1) => {
                    opret = true;
                    key.key.is_empty() && value == &script[2..]
                }
                (b"MPC", 0) => {
                    mpc_messages += 1;
                    key.key.len() == 32 && value.len() == 32
                }
                (b"MPC", 1) => {
                    mpc_entropy = true;
                    key.key.is_empty() && value.len() == 8
                }
                (b"MPC", 16) => {
                    mpc_commitment = true;
                    key.key.is_empty() && value == &script[2..]
                }
                (b"MPC", 17) => {
                    mpc_proof = true;
                    key.key.is_empty() && !value.is_empty()
                }
                _ => false,
            };
            if !accepted {
                return Err(rejected(
                    "unsupported or inconsistent RGB commitment envelope",
                ));
            }
        }
        if !(opret && mpc_commitment && mpc_messages > 0 && mpc_entropy && mpc_proof) {
            return Err(rejected("RGB commitment envelope is incomplete"));
        }
    }
    if commitments != 1 {
        return Err(rejected("one RGB OP_RETURN commitment is required"));
    }
    Ok(())
}

pub(crate) fn intent_digest(gateway: &GatewaySigningIntent, legacy_digest: &str) -> Result<String> {
    let mut hash = Sha256::new();
    hash.update(b"UTEXO_RGB_LIB_SIGNING_INTENT_V1\0");
    hash_string(&mut hash, legacy_digest)?;
    hash.update(gateway.max_block_height.to_be_bytes());
    hash.update(gateway.target_fee_rate_msat_per_vbyte.to_be_bytes());
    hash.update([
        u8::from(gateway.create_utxos.is_some()),
        u8::from(gateway.rgb.is_some()),
    ]);
    if let Some(create) = &gateway.create_utxos {
        hash.update(create.min_count.to_be_bytes());
        hash.update(create.max_count.to_be_bytes());
        hash.update(create.size_sats.to_be_bytes());
        hash.update([u8::from(create.exact_outputs.is_some())]);
        if let Some(outputs) = &create.exact_outputs {
            hash.update(
                u32::try_from(outputs.len())
                    .map_err(|_| invalid_argument("too many exact outputs"))?
                    .to_be_bytes(),
            );
            for output in outputs {
                hash.update([output.account as u8, output.keychain as u8]);
                hash.update(output.index.to_be_bytes());
                hash.update(output.amount_sats.to_be_bytes());
            }
        }
    }
    if let Some(rgb) = &gateway.rgb {
        hash_string(&mut hash, &rgb.invoice)?;
        hash_string(&mut hash, &rgb.asset_id)?;
        hash.update(rgb.amount.to_be_bytes());
        for value in [rgb.witness_amount_sats, rgb.witness_blinding] {
            hash.update([u8::from(value.is_some())]);
            hash.update(value.unwrap_or(0).to_be_bytes());
        }
        hash.update([u8::from(rgb.donation), u8::from(rgb.skip_sync)]);
        hash.update(rgb.min_confirmations.to_be_bytes());
        hash.update(rgb.validation_time_unix_seconds.to_be_bytes());
    }
    Ok(format!("{:x}", hash.finalize()))
}
