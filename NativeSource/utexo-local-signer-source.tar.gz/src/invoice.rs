//! Size-bounded RGB invoice decoding for the native mobile facade.
//!
//! The grammar and canonical display rules are independently implemented from
//! the Apache-2.0 `rgb-invoicing` 0.11.1-rc.11 sources (upstream revision
//! `5308b9d46c91857513ff5be2459992264687632b`) and the assignment mapping in
//! UTEXO `rgb-lib` v0.3.0-beta.34 (revision
//! `62a8c3a045901147b3b06aed9f1e61f345695dce`). The narrow implementation keeps
//! consensus, wallet, chain, and storage dependencies out of the lightweight
//! SDK while preserving the invoice syntax used by the current gateway.
//!
//! Original format implementation copyright (C) 2019-2024 LNP/BP Standards
//! Association. Licensed under Apache-2.0.

use std::fmt::{self, Display, Formatter};
use std::str::FromStr;

use baid64::{Baid64ParseError, DisplayBaid64, FromBaid64Str};
use bitcoin::key::XOnlyPublicKey;
use fluent_uri::Uri;
use fluent_uri::encoding::EStr;
use fluent_uri::encoding::encoder::Query;
use percent_encoding::{AsciiSet, CONTROLS, utf8_percent_encode};

use crate::error::{Result, invalid_rgb_invoice};
use crate::model::{
    DecodedRgbInvoice, Network, RgbInvoiceAssignment, RgbInvoiceAssignmentKind,
    RgbInvoiceEncodedState, RgbInvoiceEncodedStateKind, RgbInvoiceRecipientType,
};

const MAX_INVOICE_BYTES: usize = 16_384;
const MAX_RECIPIENT_BYTES: usize = 1_024;
const MAX_ENDPOINTS: usize = 16;
const MAX_ENDPOINT_BYTES: usize = 2_048;
const MAX_ASSIGNMENT_NAME_BYTES: usize = 100;

const OMITTED: &str = "~";
const ASSIGNMENT_NAME_PARAM: &str = "assignment_name";
const EXPIRY_PARAM: &str = "expiry";
const ENDPOINTS_PARAM: &str = "endpoints";

const NIA_SCHEMA_ID: &str =
    "rgb:sch:RWhwUfTMpuP2Zfx1~j4nswCANGeJrYOqDcKelaMV4zU#remote-digital-pegasus";
const UDA_SCHEMA_ID: &str =
    "rgb:sch:~6rjymf3GTE840lb5JoXm2aFwE8eWCk3mCjOf_mUztE#spider-montana-fantasy";
const CFA_SCHEMA_ID: &str = "rgb:sch:JgqK5hJX9YBT4osCV7VcW_iLTcA5csUCnLzvaKTTrNY#mars-house-friend";
const IFA_SCHEMA_ID: &str =
    "rgb:sch:IpjJhFLz3oywYKQxO3KmFgR0Aa415nlTNrNyEFqMZCE#shoe-colombo-mango";

const ASSET_OWNER: &str = "assetOwner";
const INFLATION_ALLOWANCE: &str = "inflationAllowance";

const QUERY_ENCODE: &AsciiSet = &CONTROLS
    .add(b' ')
    .add(b'"')
    .add(b'#')
    .add(b'<')
    .add(b'>')
    .add(b'[')
    .add(b']')
    .add(b'&')
    .add(b'=');

const AMOUNT_ALPHABET: &[u8; 32] = b"abcdefghkmnABCDEFGHKMNPQRSTVWXYZ";
fast32::make_base32_alpha!(AMOUNT_BASE32, AMOUNT_DECODER, AMOUNT_ALPHABET);

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct ContractId([u8; 32]);

impl From<[u8; 32]> for ContractId {
    fn from(payload: [u8; 32]) -> Self {
        Self(payload)
    }
}

impl DisplayBaid64 for ContractId {
    const HRI: &'static str = "rgb";
    const CHUNKING: bool = true;
    const PREFIX: bool = true;
    const EMBED_CHECKSUM: bool = false;
    const MNEMONIC: bool = false;

    fn to_baid64_payload(&self) -> [u8; 32] {
        self.0
    }
}

impl FromBaid64Str for ContractId {}

impl FromStr for ContractId {
    type Err = Baid64ParseError;

    fn from_str(value: &str) -> std::result::Result<Self, Self::Err> {
        Self::from_baid64_str(value)
    }
}

impl Display for ContractId {
    fn fmt(&self, formatter: &mut Formatter<'_>) -> fmt::Result {
        self.fmt_baid64(formatter)
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct SchemaId([u8; 32]);

impl From<[u8; 32]> for SchemaId {
    fn from(payload: [u8; 32]) -> Self {
        Self(payload)
    }
}

impl DisplayBaid64 for SchemaId {
    const HRI: &'static str = "rgb:sch";
    const CHUNKING: bool = false;
    const PREFIX: bool = true;
    const EMBED_CHECKSUM: bool = false;
    const MNEMONIC: bool = true;

    fn to_baid64_payload(&self) -> [u8; 32] {
        self.0
    }
}

impl FromBaid64Str for SchemaId {}

impl FromStr for SchemaId {
    type Err = Baid64ParseError;

    fn from_str(value: &str) -> std::result::Result<Self, Self::Err> {
        Self::from_baid64_str(value)
    }
}

impl Display for SchemaId {
    fn fmt(&self, formatter: &mut Formatter<'_>) -> fmt::Result {
        self.fmt_baid64(formatter)
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct SecretSeal([u8; 32]);

impl From<[u8; 32]> for SecretSeal {
    fn from(payload: [u8; 32]) -> Self {
        Self(payload)
    }
}

impl DisplayBaid64 for SecretSeal {
    const HRI: &'static str = "utxob";
    const CHUNKING: bool = true;
    const PREFIX: bool = true;
    const EMBED_CHECKSUM: bool = true;
    const MNEMONIC: bool = false;

    fn to_baid64_payload(&self) -> [u8; 32] {
        self.0
    }
}

impl FromBaid64Str for SecretSeal {}

impl FromStr for SecretSeal {
    type Err = Baid64ParseError;

    fn from_str(value: &str) -> std::result::Result<Self, Self::Err> {
        Self::from_baid64_str(value)
    }
}

impl Display for SecretSeal {
    fn fmt(&self, formatter: &mut Formatter<'_>) -> fmt::Result {
        self.fmt_baid64(formatter)
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct Pay2Vout([u8; 33]);

#[derive(Debug)]
struct InvalidPay2Vout;

impl Display for InvalidPay2Vout {
    fn fmt(&self, formatter: &mut Formatter<'_>) -> fmt::Result {
        formatter.write_str("invalid witness beneficiary payload")
    }
}

impl std::error::Error for InvalidPay2Vout {}

impl TryFrom<[u8; 33]> for Pay2Vout {
    type Error = InvalidPay2Vout;

    fn try_from(mut payload: [u8; 33]) -> std::result::Result<Self, Self::Error> {
        match payload[0] {
            // The upstream address conversion retains only the 20-byte payload
            // for these address families and canonical display zero-fills the
            // remainder.
            1..=3 => payload[21..].fill(0),
            4 => {}
            5 => {
                XOnlyPublicKey::from_slice(&payload[1..]).map_err(|_| InvalidPay2Vout)?;
            }
            _ => return Err(InvalidPay2Vout),
        }
        Ok(Self(payload))
    }
}

impl DisplayBaid64<33> for Pay2Vout {
    const HRI: &'static str = "wvout";
    const CHUNKING: bool = true;
    const PREFIX: bool = true;
    const EMBED_CHECKSUM: bool = true;
    const MNEMONIC: bool = false;

    fn to_baid64_payload(&self) -> [u8; 33] {
        self.0
    }
}

impl FromBaid64Str<33> for Pay2Vout {}

impl FromStr for Pay2Vout {
    type Err = Baid64ParseError;

    fn from_str(value: &str) -> std::result::Result<Self, Self::Err> {
        Self::from_baid64_str(value)
    }
}

impl Display for Pay2Vout {
    fn fmt(&self, formatter: &mut Formatter<'_>) -> fmt::Result {
        self.fmt_baid64(formatter)
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum SchemaKind {
    Nia,
    Uda,
    Cfa,
    Ifa,
}

impl SchemaKind {
    const fn wire_name(self) -> &'static str {
        match self {
            Self::Nia => "Nia",
            Self::Uda => "Uda",
            Self::Cfa => "Cfa",
            Self::Ifa => "Ifa",
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum AssignmentState {
    Amount(u64),
    Data,
}

#[derive(Clone, Debug, PartialEq, Eq)]
struct ParsedState {
    state: Option<AssignmentState>,
    canonical: String,
}

#[derive(Clone, Debug, PartialEq, Eq)]
enum Transport {
    JsonRpc { tls: bool, host: String },
    RestHttp { tls: bool, host: String },
    WebSocket { tls: bool, host: String },
    Storm,
}

impl Display for Transport {
    fn fmt(&self, formatter: &mut Formatter<'_>) -> fmt::Result {
        match self {
            Self::JsonRpc { tls, host } => {
                let secure = if *tls { "s" } else { "" };
                write!(formatter, "rpc{secure}://{host}")
            }
            Self::RestHttp { tls, host } => {
                let secure = if *tls { "s" } else { "" };
                write!(formatter, "http{secure}://{host}")
            }
            Self::WebSocket { tls, host } => {
                let secure = if *tls { "s" } else { "" };
                write!(formatter, "ws{secure}://{host}")
            }
            Self::Storm => formatter.write_str("storm://_/"),
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
struct QueryData {
    assignment_name: Option<String>,
    expiry: Option<i64>,
    transports: Vec<Transport>,
}

/// Decodes and strictly validates a canonical RGB invoice without requiring a
/// wallet, seed, network call, or persistent state.
///
/// This validates invoice syntax, identifiers, checksums, supported schema and
/// assignment combinations, and bounded transport metadata. It does not prove
/// that an asset exists, that the beneficiary is owned by the caller, or that a
/// future RGB state transition is valid.
///
/// # Errors
///
/// Returns `InvalidRgbInvoice` for malformed, non-canonical, oversized, or
/// unsupported invoices. Error messages never include invoice contents.
#[uniffi::export]
#[allow(clippy::needless_pass_by_value)] // UniFFI owns strings crossing the boundary.
pub fn decode_rgb_invoice(invoice: String) -> Result<DecodedRgbInvoice> {
    if invoice.is_empty() {
        return Err(invalid_rgb_invoice("invoice must not be empty"));
    }
    if invoice.len() > MAX_INVOICE_BYTES {
        return Err(invalid_rgb_invoice("invoice exceeds the size limit"));
    }

    let uri = Uri::parse(invoice.as_str())
        .map_err(|_| invalid_rgb_invoice("invoice URI syntax is invalid"))?;
    if uri.scheme().as_str() != "rgb" {
        return Err(invalid_rgb_invoice("invoice scheme must be rgb"));
    }
    if uri.authority().is_some() || uri.path().is_absolute() {
        return Err(invalid_rgb_invoice("invoice authority is not allowed"));
    }
    if uri.fragment().is_some() {
        return Err(invalid_rgb_invoice("invoice fragment is not allowed"));
    }

    let mut segments = uri.path().split('/');
    let contract_segment = segments
        .next()
        .ok_or_else(|| invalid_rgb_invoice("contract segment is missing"))?;
    let schema_segment = segments
        .next()
        .ok_or_else(|| invalid_rgb_invoice("schema segment is missing"))?;
    let state_segment = segments
        .next()
        .ok_or_else(|| invalid_rgb_invoice("assignment state segment is missing"))?;
    let recipient_segment = segments
        .next()
        .ok_or_else(|| invalid_rgb_invoice("beneficiary segment is missing"))?;
    if segments.next().is_some() {
        return Err(invalid_rgb_invoice("invoice has extra path segments"));
    }

    let contract = parse_contract(contract_segment.as_str())?;
    let (schema, schema_kind) = parse_schema(schema_segment.as_str())?;
    let parsed_state = parse_assignment_state(state_segment.as_str())?;
    let (recipient_id, recipient_type, network) = parse_recipient(recipient_segment.as_str())?;
    let query = parse_query(&uri)?;
    let encoded_state = encoded_state(parsed_state.state);
    let assignment = map_assignment(
        schema_kind,
        parsed_state.state,
        query.assignment_name.as_deref(),
    )?;

    let canonical = canonical_invoice(
        contract.as_ref(),
        schema.as_ref(),
        &parsed_state.canonical,
        &recipient_id,
        &query,
    );
    if canonical != invoice {
        return Err(invalid_rgb_invoice("invoice is not canonical"));
    }

    let endpoints = query.transports.iter().map(ToString::to_string).collect();
    Ok(DecodedRgbInvoice {
        recipient_id,
        recipient_type,
        asset_schema: schema_kind.map(|kind| kind.wire_name().to_owned()),
        asset_id: contract.map(|id| id.to_string()),
        network,
        assignment,
        encoded_state,
        assignment_name: query.assignment_name,
        expiration_timestamp: query.expiry,
        transport_endpoints: endpoints,
    })
}

fn encoded_state(state: Option<AssignmentState>) -> RgbInvoiceEncodedState {
    match state {
        None => RgbInvoiceEncodedState {
            kind: RgbInvoiceEncodedStateKind::Omitted,
            amount: None,
        },
        Some(AssignmentState::Amount(amount)) => RgbInvoiceEncodedState {
            kind: RgbInvoiceEncodedStateKind::Amount,
            amount: Some(amount),
        },
        Some(AssignmentState::Data) => RgbInvoiceEncodedState {
            kind: RgbInvoiceEncodedStateKind::NonFungible,
            amount: None,
        },
    }
}

fn parse_contract(segment: &str) -> Result<Option<ContractId>> {
    if segment == OMITTED {
        return Ok(None);
    }
    ContractId::from_str(segment)
        .map(Some)
        .map_err(|_| invalid_rgb_invoice("contract identifier is invalid"))
}

fn parse_schema(segment: &str) -> Result<(Option<SchemaId>, Option<SchemaKind>)> {
    if segment == OMITTED {
        return Ok((None, None));
    }
    let schema = SchemaId::from_str(segment)
        .map_err(|_| invalid_rgb_invoice("schema identifier is invalid"))?;
    let kind = match schema.to_string().as_str() {
        NIA_SCHEMA_ID => SchemaKind::Nia,
        UDA_SCHEMA_ID => SchemaKind::Uda,
        CFA_SCHEMA_ID => SchemaKind::Cfa,
        IFA_SCHEMA_ID => SchemaKind::Ifa,
        _ => return Err(invalid_rgb_invoice("schema is not supported")),
    };
    Ok((Some(schema), Some(kind)))
}

fn parse_assignment_state(segment: &str) -> Result<ParsedState> {
    if segment == OMITTED {
        return Ok(ParsedState {
            state: None,
            canonical: OMITTED.to_owned(),
        });
    }
    if segment.is_empty() {
        return Err(invalid_rgb_invoice("assignment state is invalid"));
    }

    if segment.contains('@') {
        let (fraction, token_index) = segment
            .split_once('@')
            .ok_or_else(|| invalid_rgb_invoice("non-fungible assignment is invalid"))?;
        let fraction = fraction
            .parse::<u64>()
            .map_err(|_| invalid_rgb_invoice("non-fungible assignment is invalid"))?;
        let token_index = token_index
            .parse::<u32>()
            .map_err(|_| invalid_rgb_invoice("non-fungible assignment is invalid"))?;
        let canonical = format!("{fraction}@{token_index}");
        if canonical != segment {
            return Err(invalid_rgb_invoice("assignment state is not canonical"));
        }
        return Ok(ParsedState {
            state: Some(AssignmentState::Data),
            canonical,
        });
    }

    let bytes = AMOUNT_BASE32
        .decode_str(segment)
        .map_err(|_| invalid_rgb_invoice("fungible assignment amount is invalid"))?;
    if bytes.len() > 8 {
        return Err(invalid_rgb_invoice("fungible assignment amount is invalid"));
    }
    let mut little_endian = [0_u8; 8];
    little_endian[..bytes.len()].copy_from_slice(&bytes);
    let amount = u64::from_le_bytes(little_endian);
    let canonical = encode_amount(amount);
    if canonical != segment {
        return Err(invalid_rgb_invoice("assignment state is not canonical"));
    }
    Ok(ParsedState {
        state: Some(AssignmentState::Amount(amount)),
        canonical,
    })
}

fn encode_amount(amount: u64) -> String {
    let bytes = amount.to_le_bytes();
    let length = bytes.iter().rposition(|byte| *byte != 0).unwrap_or(0) + 1;
    AMOUNT_BASE32.encode(&bytes[..length])
}

fn parse_recipient(segment: &str) -> Result<(String, RgbInvoiceRecipientType, Network)> {
    if segment.is_empty() || segment.len() > MAX_RECIPIENT_BYTES {
        return Err(invalid_rgb_invoice("beneficiary is invalid"));
    }
    let (chain, beneficiary) = segment
        .split_once(':')
        .ok_or_else(|| invalid_rgb_invoice("beneficiary network is missing"))?;
    let (prefix, network) = match chain.to_ascii_lowercase().as_str() {
        "bc" => ("bc", Network::Mainnet),
        "tb3" => ("tb3", Network::Testnet),
        "tb4" => ("tb4", Network::Testnet4),
        "sb" => ("sb", Network::Signet),
        "bcrt" => ("bcrt", Network::Regtest),
        "sbc" => return Err(invalid_rgb_invoice("custom signet is not supported")),
        "lq" | "tl" => return Err(invalid_rgb_invoice("Liquid invoices are not supported")),
        _ => return Err(invalid_rgb_invoice("beneficiary network is invalid")),
    };

    if let Ok(seal) = SecretSeal::from_str(beneficiary) {
        return Ok((
            format!("{prefix}:{seal}"),
            RgbInvoiceRecipientType::Blind,
            network,
        ));
    }

    let (pay_to_vout, internal_key) = beneficiary
        .split_once('+')
        .map_or((beneficiary, None), |(pay_to_vout, key)| {
            (pay_to_vout, Some(key))
        });
    let pay_to_vout = Pay2Vout::from_str(pay_to_vout)
        .map_err(|_| invalid_rgb_invoice("beneficiary is invalid"))?;
    let internal_key = internal_key
        .map(|key| {
            if key.is_empty() {
                return Err(invalid_rgb_invoice("beneficiary internal key is missing"));
            }
            XOnlyPublicKey::from_str(key)
                .map_err(|_| invalid_rgb_invoice("beneficiary internal key is invalid"))
        })
        .transpose()?;
    let internal_key = internal_key.map_or_else(String::new, |key| format!("+{key}"));
    Ok((
        format!("{prefix}:{pay_to_vout}{internal_key}"),
        RgbInvoiceRecipientType::Witness,
        network,
    ))
}

/// Decode the already canonical, checksummed witness beneficiary into its
/// exact Bitcoin script. The optional internal key is metadata, not a license
/// to substitute a different output key or apply an additional tweak.
pub(crate) fn witness_script(recipient: &str) -> Result<bitcoin::ScriptBuf> {
    use bitcoin::hashes::Hash;
    use bitcoin::{PubkeyHash, ScriptBuf, ScriptHash, WPubkeyHash, WScriptHash};
    let (_, kind, _) = parse_recipient(recipient)?;
    if kind != RgbInvoiceRecipientType::Witness {
        return Err(invalid_rgb_invoice("a witness beneficiary is required"));
    }
    let (_, beneficiary) = recipient
        .split_once(':')
        .ok_or_else(|| invalid_rgb_invoice("beneficiary network is missing"))?;
    let payload = Pay2Vout::from_str(beneficiary.split('+').next().unwrap_or_default())
        .map_err(|_| invalid_rgb_invoice("beneficiary payload is invalid"))?
        .0;
    let bad = |_| invalid_rgb_invoice("beneficiary payload length is invalid");
    Ok(match payload[0] {
        1 => ScriptBuf::new_p2pkh(&PubkeyHash::from_slice(&payload[1..21]).map_err(bad)?),
        2 => ScriptBuf::new_p2sh(&ScriptHash::from_slice(&payload[1..21]).map_err(bad)?),
        3 => ScriptBuf::new_p2wpkh(&WPubkeyHash::from_slice(&payload[1..21]).map_err(bad)?),
        4 => ScriptBuf::new_p2wsh(&WScriptHash::from_slice(&payload[1..]).map_err(bad)?),
        5 => {
            let mut bytes = vec![0x51, 0x20];
            bytes.extend_from_slice(&payload[1..]);
            ScriptBuf::from_bytes(bytes)
        }
        _ => return Err(invalid_rgb_invoice("unsupported witness beneficiary")),
    })
}

/// Derives the exact Bitcoin recipient encoded by a canonical RGB witness
/// invoice. This is local syntax/output authorization, not RGB validation.
///
/// # Errors
/// Rejects blind/malformed invoices, network mismatch and invalid/dust amounts.
#[uniffi::export]
pub fn rgb_invoice_witness_recipient(
    invoice: String,
    network: Network,
    amount_sats: u64,
) -> Result<crate::model::Recipient> {
    let decoded = decode_rgb_invoice(invoice)?;
    if decoded.network.bitcoin() != network.bitcoin() {
        return Err(invalid_rgb_invoice(
            "witness invoice network differs from the requested network",
        ));
    }
    let script = witness_script(&decoded.recipient_id)?;
    if amount_sats > bitcoin::Amount::MAX_MONEY.to_sat()
        || amount_sats < script.minimal_non_dust().to_sat()
    {
        return Err(invalid_rgb_invoice(
            "witness amount is below dust or exceeds Bitcoin supply",
        ));
    }
    let address = bitcoin::Address::from_script(&script, network.bitcoin())
        .map_err(|_| invalid_rgb_invoice("witness beneficiary script is unsupported"))?;
    Ok(crate::model::Recipient {
        address: address.to_string(),
        amount_sats,
    })
}

fn parse_query(uri: &Uri<&str>) -> Result<QueryData> {
    let mut assignment_name = None;
    let mut expiry = None;
    let mut transports = None;

    if let Some(query) = uri.query() {
        for parameter in query.split('&') {
            let (encoded_key, encoded_value) = parameter
                .split_once('=')
                .ok_or_else(|| invalid_rgb_invoice("query parameter is invalid"))?;
            let key = percent_decode(encoded_key)?;
            let value = percent_decode(encoded_value)?;
            match key.as_str() {
                ASSIGNMENT_NAME_PARAM => {
                    if assignment_name.is_some() {
                        return Err(invalid_rgb_invoice("query parameter is duplicated"));
                    }
                    validate_assignment_name(&value)?;
                    assignment_name = Some(value);
                }
                EXPIRY_PARAM => {
                    if expiry.is_some() {
                        return Err(invalid_rgb_invoice("query parameter is duplicated"));
                    }
                    let timestamp = value
                        .parse::<i64>()
                        .map_err(|_| invalid_rgb_invoice("expiration timestamp is invalid"))?;
                    if timestamp < 0 {
                        return Err(invalid_rgb_invoice(
                            "expiration timestamp must not be negative",
                        ));
                    }
                    expiry = Some(timestamp);
                }
                ENDPOINTS_PARAM => {
                    if transports.is_some() {
                        return Err(invalid_rgb_invoice("query parameter is duplicated"));
                    }
                    transports = Some(parse_transports(&value)?);
                }
                _ => return Err(invalid_rgb_invoice("query parameter is not supported")),
            }
        }
    }

    Ok(QueryData {
        assignment_name,
        expiry,
        transports: transports.unwrap_or_default(),
    })
}

fn percent_decode(value: &EStr<Query>) -> Result<String> {
    value
        .decode()
        .into_string()
        .map(|decoded| decoded.to_string())
        .map_err(|_| invalid_rgb_invoice("query parameter encoding is invalid"))
}

fn validate_assignment_name(value: &str) -> Result<()> {
    let bytes = value.as_bytes();
    if bytes.is_empty() || bytes.len() > MAX_ASSIGNMENT_NAME_BYTES {
        return Err(invalid_rgb_invoice("assignment name is invalid"));
    }
    let first = bytes[0];
    if !(first == b'_' || first.is_ascii_lowercase())
        || bytes[1..]
            .iter()
            .any(|byte| !(*byte == b'_' || byte.is_ascii_alphanumeric()))
    {
        return Err(invalid_rgb_invoice("assignment name is invalid"));
    }
    Ok(())
}

fn parse_transports(value: &str) -> Result<Vec<Transport>> {
    let parts: Vec<_> = value.split(',').collect();
    if parts.is_empty() || parts.len() > MAX_ENDPOINTS {
        return Err(invalid_rgb_invoice("transport endpoint count is invalid"));
    }
    parts.into_iter().map(parse_transport).collect()
}

fn parse_transport(value: &str) -> Result<Transport> {
    if value.is_empty() || value.len() > MAX_ENDPOINT_BYTES {
        return Err(invalid_rgb_invoice("transport endpoint is invalid"));
    }
    let (scheme, host) = value
        .split_once("://")
        .ok_or_else(|| invalid_rgb_invoice("transport endpoint is invalid"))?;
    if host.is_empty()
        || host
            .chars()
            .any(|character| character.is_control() || character.is_whitespace())
    {
        return Err(invalid_rgb_invoice("transport endpoint host is invalid"));
    }
    match scheme {
        "rpc" => Ok(Transport::JsonRpc {
            tls: false,
            host: host.to_owned(),
        }),
        "rpcs" => Ok(Transport::JsonRpc {
            tls: true,
            host: host.to_owned(),
        }),
        "http" => Ok(Transport::RestHttp {
            tls: false,
            host: host.to_owned(),
        }),
        "https" => Ok(Transport::RestHttp {
            tls: true,
            host: host.to_owned(),
        }),
        "ws" => Ok(Transport::WebSocket {
            tls: false,
            host: host.to_owned(),
        }),
        "wss" => Ok(Transport::WebSocket {
            tls: true,
            host: host.to_owned(),
        }),
        "storm" => Ok(Transport::Storm),
        _ => Err(invalid_rgb_invoice(
            "transport endpoint scheme is not supported",
        )),
    }
}

fn map_assignment(
    schema: Option<SchemaKind>,
    state: Option<AssignmentState>,
    assignment_name: Option<&str>,
) -> Result<RgbInvoiceAssignment> {
    use RgbInvoiceAssignmentKind::{Any, Fungible, InflationRight, NonFungible};

    let (kind, amount) = match schema {
        None => match (state, assignment_name) {
            (Some(AssignmentState::Amount(amount)), Some(ASSET_OWNER)) => (Fungible, Some(amount)),
            (Some(AssignmentState::Amount(amount)), Some(INFLATION_ALLOWANCE)) => {
                (InflationRight, Some(amount))
            }
            (Some(AssignmentState::Amount(_)), _) | (None, None) => (Any, None),
            (Some(AssignmentState::Data), Some(ASSET_OWNER) | None) => (NonFungible, None),
            _ => return Err(invalid_rgb_invoice("assignment is not supported")),
        },
        Some(SchemaKind::Nia | SchemaKind::Cfa) => match (state, assignment_name) {
            (Some(AssignmentState::Amount(amount)), Some(ASSET_OWNER) | None) => {
                (Fungible, Some(amount))
            }
            (None, Some(ASSET_OWNER) | None) => (Fungible, Some(0)),
            _ => return Err(invalid_rgb_invoice("assignment is invalid for the schema")),
        },
        Some(SchemaKind::Uda) => match (state, assignment_name) {
            (Some(AssignmentState::Data) | None, Some(ASSET_OWNER) | None) => (NonFungible, None),
            _ => return Err(invalid_rgb_invoice("assignment is invalid for the schema")),
        },
        Some(SchemaKind::Ifa) => match (state, assignment_name) {
            (Some(AssignmentState::Amount(amount)), Some(ASSET_OWNER)) => (Fungible, Some(amount)),
            (None, Some(ASSET_OWNER)) => (Fungible, Some(0)),
            (Some(AssignmentState::Amount(amount)), Some(INFLATION_ALLOWANCE)) => {
                (InflationRight, Some(amount))
            }
            (None, Some(INFLATION_ALLOWANCE)) => (InflationRight, Some(0)),
            (Some(AssignmentState::Amount(_)) | None, None) => (Any, None),
            _ => return Err(invalid_rgb_invoice("assignment is invalid for the schema")),
        },
    };

    Ok(RgbInvoiceAssignment { kind, amount })
}

fn canonical_invoice(
    contract: Option<&ContractId>,
    schema: Option<&SchemaId>,
    state: &str,
    recipient: &str,
    query: &QueryData,
) -> String {
    let mut invoice = contract.map_or_else(|| "rgb:~".to_owned(), ToString::to_string);
    invoice.push('/');
    invoice.push_str(&schema.map_or_else(|| OMITTED.to_owned(), |schema| format!("{schema:-#}")));
    invoice.push('/');
    invoice.push_str(state);
    invoice.push('/');
    invoice.push_str(recipient);

    let mut parameters = Vec::with_capacity(3);
    if let Some(name) = &query.assignment_name {
        parameters.push((ASSIGNMENT_NAME_PARAM, name.clone()));
    }
    if let Some(expiry) = query.expiry {
        parameters.push((EXPIRY_PARAM, expiry.to_string()));
    }
    if !query.transports.is_empty() {
        let endpoints = query
            .transports
            .iter()
            .map(ToString::to_string)
            .collect::<Vec<_>>()
            .join(",");
        parameters.push((ENDPOINTS_PARAM, endpoints));
    }

    for (index, (key, value)) in parameters.into_iter().enumerate() {
        invoice.push(if index == 0 { '?' } else { '&' });
        invoice.push_str(&utf8_percent_encode(key, QUERY_ENCODE).to_string());
        invoice.push('=');
        invoice.push_str(&utf8_percent_encode(&value, QUERY_ENCODE).to_string());
    }
    invoice
}

#[cfg(test)]
#[allow(clippy::panic)]
mod tests {
    use super::*;

    const BLIND_RECIPIENT: &str =
        "bcrt:utxob:tjVmHbI2-U0_umHn-bU4cmP6-l3VW00H-ewoi2uz-XZG6O3i-wUFBW";
    const WITNESS_INVOICE: &str = "rgb:~/~/~/bcrt:wvout:Be7zrr7L-VM9RP6X-pBRQduY-5ujGu~3-GqxY7TP-Tk5abpc-6cGRkrQ?expiry=2000000000&endpoints=rpc://localhost:3000/json-rpc";
    const CURRENT_GATEWAY_OPENAPI_INVOICE: &str = "rgb:icfqnK9y-wObZKTu-XJcDL98-sKbE5Mh-OuDJhiI-brRJrzE/RWhwUfTMpuP2Zfx1~j4nswCANGeJrYOqDcKelaMV4zU/~/bcrt:utxob:cbgHUJ4e-7QyKY4U-Jsj5AZw-oI0gxZh-7fxQY2_-tFFUAZN-4CgpX?expiry=1749906951&endpoints=rpcs://proxy.iriswallet.com/0.2/json-rpc";
    const GENERIC_UPSTREAM_INVOICE: &str = "rgb:eIbQx5Am-XRDjj01-RM~5eo7-rv2nluD-OnBJRAy-S9~Yfts/XvmU3d4_nQQ8S7oagbXi07x5vjMm7P~ERukQNX6SC4M/BF/bc:utxob:4vm1CX2Z-K8hMo59-e7dgGBS-Jka7mYn-Xe~yP85-yUiHHxr-aVlYa";

    const NIA_SEGMENT: &str = "RWhwUfTMpuP2Zfx1~j4nswCANGeJrYOqDcKelaMV4zU";
    const UDA_SEGMENT: &str = "~6rjymf3GTE840lb5JoXm2aFwE8eWCk3mCjOf_mUztE";
    const CFA_SEGMENT: &str = "JgqK5hJX9YBT4osCV7VcW_iLTcA5csUCnLzvaKTTrNY";
    const IFA_SEGMENT: &str = "IpjJhFLz3oywYKQxO3KmFgR0Aa415nlTNrNyEFqMZCE";

    fn invoice(schema: &str, state: &str, query: &str) -> String {
        format!("rgb:~/{schema}/{state}/{BLIND_RECIPIENT}{query}")
    }

    #[test]
    fn decodes_current_gateway_witness_fixture() {
        let decoded = decode_rgb_invoice(WITNESS_INVOICE.to_owned())
            .unwrap_or_else(|error| panic!("fixture should decode: {error}"));
        assert_eq!(decoded.recipient_type, RgbInvoiceRecipientType::Witness);
        assert_eq!(decoded.network, Network::Regtest);
        assert_eq!(decoded.asset_schema, None);
        assert_eq!(decoded.asset_id, None);
        assert_eq!(decoded.assignment.kind, RgbInvoiceAssignmentKind::Any);
        assert_eq!(decoded.assignment.amount, None);
        assert_eq!(
            decoded.encoded_state.kind,
            RgbInvoiceEncodedStateKind::Omitted
        );
        assert_eq!(decoded.encoded_state.amount, None);
        assert_eq!(decoded.expiration_timestamp, Some(2_000_000_000));
        assert_eq!(
            decoded.transport_endpoints,
            vec!["rpc://localhost:3000/json-rpc"]
        );
    }

    #[test]
    fn decodes_current_gateway_openapi_asset_fixture() {
        let decoded = decode_rgb_invoice(CURRENT_GATEWAY_OPENAPI_INVOICE.to_owned())
            .unwrap_or_else(|error| panic!("gateway fixture should decode: {error}"));
        assert_eq!(decoded.asset_schema.as_deref(), Some("Nia"));
        assert_eq!(
            decoded.asset_id.as_deref(),
            Some("rgb:icfqnK9y-wObZKTu-XJcDL98-sKbE5Mh-OuDJhiI-brRJrzE")
        );
        assert_eq!(decoded.recipient_type, RgbInvoiceRecipientType::Blind);
        assert_eq!(
            decoded.encoded_state.kind,
            RgbInvoiceEncodedStateKind::Omitted
        );
        assert_eq!(decoded.assignment.kind, RgbInvoiceAssignmentKind::Fungible);
        assert_eq!(decoded.assignment.amount, Some(0));
        assert_eq!(decoded.expiration_timestamp, Some(1_749_906_951));
        assert_eq!(
            decoded.transport_endpoints,
            vec!["rpcs://proxy.iriswallet.com/0.2/json-rpc"]
        );
    }

    #[test]
    fn decodes_blind_amount_and_preserves_assignment_name() {
        let value = invoice("~", "ae", "?assignment_name=assetOwner");
        let decoded = decode_rgb_invoice(value)
            .unwrap_or_else(|error| panic!("fixture should decode: {error}"));
        assert_eq!(decoded.recipient_id, BLIND_RECIPIENT);
        assert_eq!(decoded.recipient_type, RgbInvoiceRecipientType::Blind);
        assert_eq!(decoded.assignment.kind, RgbInvoiceAssignmentKind::Fungible);
        assert_eq!(decoded.assignment.amount, Some(1));
        assert_eq!(
            decoded.encoded_state.kind,
            RgbInvoiceEncodedStateKind::Amount
        );
        assert_eq!(decoded.encoded_state.amount, Some(1));
        assert_eq!(decoded.assignment_name.as_deref(), Some(ASSET_OWNER));
    }

    #[test]
    fn maps_all_supported_schema_assignment_branches() {
        let cases = [
            (
                NIA_SEGMENT,
                "ae",
                "",
                "Nia",
                RgbInvoiceAssignmentKind::Fungible,
                Some(1),
            ),
            (
                NIA_SEGMENT,
                "~",
                "",
                "Nia",
                RgbInvoiceAssignmentKind::Fungible,
                Some(0),
            ),
            (
                CFA_SEGMENT,
                "ae",
                "",
                "Cfa",
                RgbInvoiceAssignmentKind::Fungible,
                Some(1),
            ),
            (
                UDA_SEGMENT,
                "1@0",
                "",
                "Uda",
                RgbInvoiceAssignmentKind::NonFungible,
                None,
            ),
            (
                UDA_SEGMENT,
                "~",
                "",
                "Uda",
                RgbInvoiceAssignmentKind::NonFungible,
                None,
            ),
            (
                IFA_SEGMENT,
                "ae",
                "?assignment_name=assetOwner",
                "Ifa",
                RgbInvoiceAssignmentKind::Fungible,
                Some(1),
            ),
            (
                IFA_SEGMENT,
                "ae",
                "?assignment_name=inflationAllowance",
                "Ifa",
                RgbInvoiceAssignmentKind::InflationRight,
                Some(1),
            ),
            (
                IFA_SEGMENT,
                "ae",
                "",
                "Ifa",
                RgbInvoiceAssignmentKind::Any,
                None,
            ),
            (
                IFA_SEGMENT,
                "~",
                "",
                "Ifa",
                RgbInvoiceAssignmentKind::Any,
                None,
            ),
        ];

        for (schema, state, query, schema_name, kind, amount) in cases {
            let decoded = decode_rgb_invoice(invoice(schema, state, query))
                .unwrap_or_else(|error| panic!("schema fixture should decode: {error}"));
            assert_eq!(decoded.asset_schema.as_deref(), Some(schema_name));
            assert_eq!(decoded.assignment.kind, kind);
            assert_eq!(decoded.assignment.amount, amount);
        }
    }

    #[test]
    fn matches_rgb_lib_no_schema_assignment_matrix() {
        let cases = [
            (
                "BF",
                "?assignment_name=assetOwner",
                RgbInvoiceAssignmentKind::Fungible,
                Some(100),
            ),
            (
                "BF",
                "?assignment_name=inflationAllowance",
                RgbInvoiceAssignmentKind::InflationRight,
                Some(100),
            ),
            ("BF", "", RgbInvoiceAssignmentKind::Any, None),
            (
                "BF",
                "?assignment_name=otherState",
                RgbInvoiceAssignmentKind::Any,
                None,
            ),
            (
                "1@0",
                "?assignment_name=assetOwner",
                RgbInvoiceAssignmentKind::NonFungible,
                None,
            ),
            ("1@0", "", RgbInvoiceAssignmentKind::NonFungible, None),
            ("~", "", RgbInvoiceAssignmentKind::Any, None),
        ];

        for (state, query, kind, amount) in cases {
            let decoded = decode_rgb_invoice(invoice("~", state, query))
                .unwrap_or_else(|error| panic!("no-schema fixture should decode: {error}"));
            assert_eq!(decoded.assignment.kind, kind);
            assert_eq!(decoded.assignment.amount, amount);
        }
    }

    #[test]
    fn raw_state_evidence_prevents_lossy_assignment_projection_from_hiding_intent() {
        let explicit_amount = decode_rgb_invoice(invoice("~", "BF", ""))
            .unwrap_or_else(|error| panic!("explicit amount should decode: {error}"));
        assert_eq!(
            explicit_amount.assignment.kind,
            RgbInvoiceAssignmentKind::Any
        );
        assert_eq!(explicit_amount.assignment.amount, None);
        assert_eq!(
            explicit_amount.encoded_state,
            RgbInvoiceEncodedState {
                kind: RgbInvoiceEncodedStateKind::Amount,
                amount: Some(100),
            }
        );

        let omitted_known_schema = decode_rgb_invoice(invoice(NIA_SEGMENT, "~", ""))
            .unwrap_or_else(|error| panic!("omitted state should decode: {error}"));
        assert_eq!(
            omitted_known_schema.assignment,
            RgbInvoiceAssignment {
                kind: RgbInvoiceAssignmentKind::Fungible,
                amount: Some(0),
            }
        );
        assert_eq!(
            omitted_known_schema.encoded_state,
            RgbInvoiceEncodedState {
                kind: RgbInvoiceEncodedStateKind::Omitted,
                amount: None,
            }
        );

        let non_fungible = decode_rgb_invoice(invoice(UDA_SEGMENT, "1@0", ""))
            .unwrap_or_else(|error| panic!("non-fungible state should decode: {error}"));
        assert_eq!(
            non_fungible.encoded_state,
            RgbInvoiceEncodedState {
                kind: RgbInvoiceEncodedStateKind::NonFungible,
                amount: None,
            }
        );
    }

    #[test]
    fn matches_rgb_lib_zero_and_named_schema_assignment_matrix() {
        let cases = [
            (
                NIA_SEGMENT,
                "BF",
                "?assignment_name=assetOwner",
                RgbInvoiceAssignmentKind::Fungible,
                Some(100),
            ),
            (
                CFA_SEGMENT,
                "~",
                "?assignment_name=assetOwner",
                RgbInvoiceAssignmentKind::Fungible,
                Some(0),
            ),
            (
                UDA_SEGMENT,
                "1@0",
                "?assignment_name=assetOwner",
                RgbInvoiceAssignmentKind::NonFungible,
                None,
            ),
            (
                IFA_SEGMENT,
                "~",
                "?assignment_name=assetOwner",
                RgbInvoiceAssignmentKind::Fungible,
                Some(0),
            ),
            (
                IFA_SEGMENT,
                "~",
                "?assignment_name=inflationAllowance",
                RgbInvoiceAssignmentKind::InflationRight,
                Some(0),
            ),
        ];

        for (schema, state, query, kind, amount) in cases {
            let decoded = decode_rgb_invoice(invoice(schema, state, query))
                .unwrap_or_else(|error| panic!("named-schema fixture should decode: {error}"));
            assert_eq!(decoded.assignment.kind, kind);
            assert_eq!(decoded.assignment.amount, amount);
        }
    }

    #[test]
    fn maps_every_supported_bitcoin_chain_prefix() {
        let cases = [
            ("bc", Network::Mainnet),
            ("tb3", Network::Testnet),
            ("tb4", Network::Testnet4),
            ("sb", Network::Signet),
            ("bcrt", Network::Regtest),
        ];
        for (prefix, expected) in cases {
            let value = invoice("~", "~", "").replace("bcrt:", &format!("{prefix}:"));
            let decoded = decode_rgb_invoice(value)
                .unwrap_or_else(|error| panic!("network fixture should decode: {error}"));
            assert_eq!(decoded.network, expected);
        }
    }

    #[test]
    fn validates_and_preserves_all_official_transport_schemes() {
        let endpoints = [
            "rpc://host/json-rpc",
            "rpcs://host/json-rpc",
            "http://host/path",
            "https://host/path",
            "ws://host/path",
            "wss://host/path",
            "storm://_/",
        ]
        .join(",");
        let decoded = decode_rgb_invoice(invoice("~", "~", &format!("?endpoints={endpoints}")))
            .unwrap_or_else(|error| panic!("transport fixture should decode: {error}"));
        assert_eq!(decoded.transport_endpoints.join(","), endpoints);
    }

    #[test]
    fn preserves_full_u64_assignment_amounts() {
        let encoded = encode_amount(u64::MAX);
        let decoded = decode_rgb_invoice(invoice(
            IFA_SEGMENT,
            &encoded,
            "?assignment_name=inflationAllowance",
        ))
        .unwrap_or_else(|error| panic!("u64 fixture should decode: {error}"));
        assert_eq!(decoded.assignment.amount, Some(u64::MAX));
    }

    #[test]
    fn decodes_contract_id_and_witness_internal_key_canonically() {
        let value = "rgb:eIbQx5Am-XRDjj01-RM~5eo7-rv2nluD-OnBJRAy-S9~Yfts/~/Sa/bc:wvout:A8cJ7Ww3-NIzADo3-Tzp_5aD-7CTBWmA-AAAAAAA-AAAAAAA-ALSQkcw+750f58bcca0fdb11891e7979d829b8c56e0963dba08c44f54a256cf7dbc09caf";
        let decoded = decode_rgb_invoice(value.to_owned())
            .unwrap_or_else(|error| panic!("fixture should decode: {error}"));
        assert_eq!(
            decoded.asset_id.as_deref(),
            Some("rgb:eIbQx5Am-XRDjj01-RM~5eo7-rv2nluD-OnBJRAy-S9~Yfts")
        );
        assert_eq!(decoded.recipient_type, RgbInvoiceRecipientType::Witness);
    }

    #[test]
    fn rejects_unknown_schema_accepted_by_the_low_level_parser() {
        assert!(decode_rgb_invoice(GENERIC_UPSTREAM_INVOICE.to_owned()).is_err());
    }

    #[test]
    fn rejects_noncanonical_and_hardened_upstream_edge_cases() {
        let valid = invoice("~", "~", "");
        let unchunked_recipient = valid.replace('-', "");
        let bad_checksum = format!("{}A", &valid[..valid.len() - 1]);
        let invalid = [
            valid.replace("rgb:", "RGB:"),
            valid.replace("bcrt:", "BCRT:"),
            valid.replace("bcrt:", "tb:"),
            unchunked_recipient,
            bad_checksum,
            format!("{valid}/extra"),
            format!("{valid}#ignored"),
            format!("{valid}?unknown=value"),
            format!("{valid}?expiry=-1"),
            format!("{valid}?expiry=1&expiry=2"),
            format!("{valid}?expiry=1&assignment_name=assetOwner"),
            format!("{valid}?exp%69ry=1"),
            format!("{valid}?endpoints=rpc://a,,rpc://b"),
            format!("{valid}?endpoints=ftp://example.com"),
            format!("{valid}?endpoints=storm://evil"),
            format!("{valid}?endpoints=rpc://host%20name"),
            format!("{valid}?flag"),
            invoice("~", "01@0", ""),
            invoice("~", "aeaa", ""),
        ];
        for malformed in invalid {
            assert!(
                decode_rgb_invoice(malformed).is_err(),
                "malformed fixture unexpectedly decoded"
            );
        }
    }

    #[test]
    fn rejects_unsupported_networks_and_invalid_assignment_combinations() {
        let custom_signet = invoice("~", "~", "").replace("bcrt:", "sbc:");
        let liquid = invoice("~", "~", "").replace("bcrt:", "lq:");
        let invalid_nia = invoice(NIA_SEGMENT, "1@0", "?assignment_name=assetOwner");
        let invalid_uda = invoice(UDA_SEGMENT, "ae", "");
        let invalid_ifa = invoice(IFA_SEGMENT, "1@0", "");
        for malformed in [custom_signet, liquid, invalid_nia, invalid_uda, invalid_ifa] {
            assert!(decode_rgb_invoice(malformed).is_err());
        }
    }

    #[test]
    fn enforces_invoice_and_endpoint_bounds() {
        assert!(decode_rgb_invoice("x".repeat(MAX_INVOICE_BYTES + 1)).is_err());

        let prefix = format!("{}?endpoints=", invoice("~", "~", ""));
        let separator_bytes = 7;
        let endpoint_bytes = MAX_INVOICE_BYTES - prefix.len() - separator_bytes;
        let base_endpoint_bytes = endpoint_bytes / 8;
        let remainder = endpoint_bytes % 8;
        let exact_endpoints = (0..8)
            .map(|index| {
                let len = base_endpoint_bytes + usize::from(index < remainder);
                format!("rpc://{}", "z".repeat(len - "rpc://".len()))
            })
            .collect::<Vec<_>>()
            .join(",");
        let exact_maximum = format!("{prefix}{exact_endpoints}");
        assert_eq!(exact_maximum.len(), MAX_INVOICE_BYTES);
        assert!(decode_rgb_invoice(exact_maximum.clone()).is_ok());
        assert!(decode_rgb_invoice(format!("{exact_maximum}z")).is_err());

        let too_many = (0..=MAX_ENDPOINTS)
            .map(|index| format!("rpc://host{index}"))
            .collect::<Vec<_>>()
            .join(",");
        assert!(decode_rgb_invoice(invoice("~", "~", &format!("?endpoints={too_many}"))).is_err());

        let maximum_count = (0..MAX_ENDPOINTS)
            .map(|index| format!("rpc://host{index}"))
            .collect::<Vec<_>>()
            .join(",");
        let decoded = decode_rgb_invoice(invoice("~", "~", &format!("?endpoints={maximum_count}")))
            .unwrap_or_else(|error| panic!("maximum endpoint count should decode: {error}"));
        assert_eq!(decoded.transport_endpoints.len(), MAX_ENDPOINTS);

        let oversized = format!("rpc://{}", "a".repeat(MAX_ENDPOINT_BYTES));
        assert!(decode_rgb_invoice(invoice("~", "~", &format!("?endpoints={oversized}"))).is_err());

        let boundary = format!("rpc://{}", "a".repeat(MAX_ENDPOINT_BYTES - "rpc://".len()));
        let decoded = decode_rgb_invoice(invoice("~", "~", &format!("?endpoints={boundary}")))
            .unwrap_or_else(|error| panic!("boundary endpoint should decode: {error}"));
        assert_eq!(decoded.transport_endpoints, vec![boundary]);
    }

    #[test]
    fn validates_every_witness_payload_kind_and_canonical_unused_bytes() {
        for kind in 1_u8..=5 {
            let mut payload = [0_u8; 33];
            payload[0] = kind;
            if kind == 5 {
                payload[1..].copy_from_slice(
                    &hex::decode(
                        "750f58bcca0fdb11891e7979d829b8c56e0963dba08c44f54a256cf7dbc09caf",
                    )
                    .unwrap_or_else(|error| panic!("fixed x-only key must decode: {error}")),
                );
            } else {
                for (index, byte) in payload[1..].iter_mut().enumerate() {
                    *byte = u8::try_from(index + 1)
                        .unwrap_or_else(|error| panic!("fixed payload index must fit: {error}"));
                }
                if kind <= 3 {
                    payload[21..].fill(0);
                }
            }
            let recipient = format!("bcrt:{}", Pay2Vout(payload));
            let value = format!("rgb:~/~/~/{recipient}");
            let decoded = decode_rgb_invoice(value)
                .unwrap_or_else(|error| panic!("witness kind {kind} should decode: {error}"));
            assert_eq!(decoded.recipient_type, RgbInvoiceRecipientType::Witness);
        }

        for kind in [0_u8, 6] {
            let mut payload = [0_u8; 33];
            payload[0] = kind;
            let value = format!("rgb:~/~/~/bcrt:{}", Pay2Vout(payload));
            assert!(decode_rgb_invoice(value).is_err());
        }

        let mut noncanonical_tail = [9_u8; 33];
        noncanonical_tail[0] = 1;
        let value = format!("rgb:~/~/~/bcrt:{}", Pay2Vout(noncanonical_tail));
        assert!(decode_rgb_invoice(value).is_err());
    }

    #[test]
    fn preserves_canonical_query_encoding_names_and_three_key_order() {
        let encoded_endpoints = [
            ("rpc://host%23tag", "rpc://host#tag"),
            ("rpc://%5B::1%5D:3000", "rpc://[::1]:3000"),
            ("rpc://host%3Dtag", "rpc://host=tag"),
            ("rpc://host%26tag", "rpc://host&tag"),
        ];
        for (encoded, expected) in encoded_endpoints {
            let decoded = decode_rgb_invoice(invoice("~", "~", &format!("?endpoints={encoded}")))
                .unwrap_or_else(|error| panic!("canonical endpoint should decode: {error}"));
            assert_eq!(decoded.transport_endpoints, vec![expected]);
        }

        for name in ["_".to_owned(), format!("a{}", "A".repeat(99))] {
            let decoded =
                decode_rgb_invoice(invoice("~", "ae", &format!("?assignment_name={name}")))
                    .unwrap_or_else(|error| {
                        panic!("boundary assignment name should decode: {error}")
                    });
            assert_eq!(decoded.assignment_name.as_deref(), Some(name.as_str()));
        }
        let oversized_name = format!("a{}", "A".repeat(100));
        assert!(
            decode_rgb_invoice(invoice(
                "~",
                "ae",
                &format!("?assignment_name={oversized_name}"),
            ))
            .is_err()
        );

        let all_keys = invoice(
            "~",
            "ae",
            "?assignment_name=assetOwner&expiry=9&endpoints=rpc://host",
        );
        let decoded = decode_rgb_invoice(all_keys)
            .unwrap_or_else(|error| panic!("canonical three-key query should decode: {error}"));
        assert_eq!(decoded.assignment.amount, Some(1));
        assert_eq!(decoded.expiration_timestamp, Some(9));
        assert_eq!(decoded.transport_endpoints, vec!["rpc://host"]);
    }

    fn network_fixture_name(network: Network) -> &'static str {
        match network {
            Network::Mainnet => "Mainnet",
            Network::Testnet => "Testnet",
            Network::Testnet4 => "Testnet4",
            Network::Signet => "Signet",
            Network::Regtest => "Regtest",
            Network::Utexo => "Utexo",
        }
    }

    fn recipient_fixture_name(recipient: RgbInvoiceRecipientType) -> &'static str {
        match recipient {
            RgbInvoiceRecipientType::Blind => "Blind",
            RgbInvoiceRecipientType::Witness => "Witness",
        }
    }

    fn assignment_fixture_name(kind: RgbInvoiceAssignmentKind) -> &'static str {
        match kind {
            RgbInvoiceAssignmentKind::Fungible => "Fungible",
            RgbInvoiceAssignmentKind::NonFungible => "NonFungible",
            RgbInvoiceAssignmentKind::InflationRight => "InflationRight",
            RgbInvoiceAssignmentKind::Any => "Any",
        }
    }

    fn encoded_state_fixture_name(kind: RgbInvoiceEncodedStateKind) -> &'static str {
        match kind {
            RgbInvoiceEncodedStateKind::Omitted => "Omitted",
            RgbInvoiceEncodedStateKind::Amount => "Amount",
            RgbInvoiceEncodedStateKind::NonFungible => "NonFungible",
        }
    }

    fn fixture_value(decoded: &DecodedRgbInvoice) -> serde_json::Value {
        serde_json::json!({
            "recipientId": decoded.recipient_id,
            "recipientType": recipient_fixture_name(decoded.recipient_type),
            "assetSchema": decoded.asset_schema,
            "assetId": decoded.asset_id,
            "network": network_fixture_name(decoded.network),
            "assignment": {
                "kind": assignment_fixture_name(decoded.assignment.kind),
                "amountDecimal": decoded.assignment.amount.map(|amount| amount.to_string()),
            },
            "encodedState": {
                "kind": encoded_state_fixture_name(decoded.encoded_state.kind),
                "amountDecimal": decoded.encoded_state.amount.map(|amount| amount.to_string()),
            },
            "assignmentName": decoded.assignment_name,
            "expirationTimestamp": decoded.expiration_timestamp,
            "transportEndpoints": decoded.transport_endpoints,
        })
    }

    #[test]
    fn pinned_upstream_differential_corpus_matches_exact_outputs_and_rejections() {
        let corpus: serde_json::Value = serde_json::from_str(include_str!(
            "../fixtures/upstream/rgb-invoice-0.11.1-rc.11.json"
        ))
        .unwrap_or_else(|error| panic!("differential corpus must be valid JSON: {error}"));

        let accepted = corpus["accepted"]
            .as_array()
            .unwrap_or_else(|| panic!("differential corpus must contain accepted cases"));
        for case in accepted {
            let name = case["name"]
                .as_str()
                .unwrap_or_else(|| panic!("accepted case must have a name"));
            let value = case["invoice"]
                .as_str()
                .unwrap_or_else(|| panic!("accepted case {name} must have an invoice"));
            let decoded = decode_rgb_invoice(value.to_owned())
                .unwrap_or_else(|error| panic!("accepted case {name} failed: {error}"));
            assert_eq!(fixture_value(&decoded), case["expected"], "case {name}");
        }

        let rejected = corpus["rejected"]
            .as_array()
            .unwrap_or_else(|| panic!("differential corpus must contain rejected cases"));
        for case in rejected {
            let name = case["name"]
                .as_str()
                .unwrap_or_else(|| panic!("rejected case must have a name"));
            let value = case["invoice"]
                .as_str()
                .unwrap_or_else(|| panic!("rejected case {name} must have an invoice"));
            assert!(
                matches!(
                    decode_rgb_invoice(value.to_owned()),
                    Err(crate::SignerError::InvalidRgbInvoice { .. })
                ),
                "strict-divergence case {name} was not rejected"
            );
        }
    }

    #[test]
    fn deterministic_truncation_and_mutation_corpus_never_panics() {
        for end in 0..=WITNESS_INVOICE.len() {
            let _ = decode_rgb_invoice(WITNESS_INVOICE[..end].to_owned());
        }

        let mut bytes = WITNESS_INVOICE.as_bytes().to_vec();
        for index in 0..bytes.len() {
            let original = bytes[index];
            bytes[index] = b'!';
            if let Ok(candidate) = String::from_utf8(bytes.clone()) {
                let _ = decode_rgb_invoice(candidate);
            }
            bytes[index] = original;
        }
    }
}
