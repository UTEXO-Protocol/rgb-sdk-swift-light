//! Pinned upstream vectors and bounded deterministic adversarial campaigns.
//! These supplement, not replace, independent review and continuous fuzzing.

use std::str::FromStr;

use bitcoin::key::TapTweak;
use bitcoin::secp256k1::{Keypair, Message, Secp256k1, SecretKey, XOnlyPublicKey, schnorr};
use bitcoin::sighash::{Prevouts, SighashCache};
use bitcoin::{TapNodeHash, TapSighashType};

use super::*;

#[test]
fn official_english_bip39_vectors_match_seed_and_bip32_root() {
    let vectors: serde_json::Value =
        serde_json::from_str(include_str!("../fixtures/upstream/bip39.json")).unwrap();
    let english = vectors["english"].as_array().unwrap();
    assert_eq!(english.len(), 24);
    for (index, vector) in english.iter().enumerate() {
        let entropy = hex::decode(vector[0].as_str().unwrap()).unwrap();
        let words = vector[1].as_str().unwrap();
        assert_eq!(Mnemonic::from_entropy(&entropy).unwrap().to_string(), words);
        let seed =
            derive_seed_from_mnemonic(words.as_bytes().to_vec(), b"TREZOR".to_vec()).unwrap();
        assert_eq!(
            hex::encode(&seed),
            vector[2].as_str().unwrap(),
            "vector {index}"
        );
        let keys = derive_keys_from_seed(Network::Mainnet, seed).unwrap();
        assert_eq!(keys.xpriv, vector[3].as_str().unwrap(), "vector {index}");
    }
}

#[test]
fn official_bip340_fixed_digest_vectors_verify_and_sign_exactly() {
    let secp = Secp256k1::new();
    let mut verified = 0;
    let mut signed = 0;
    let mut variable_length = 0;
    for line in include_str!("../fixtures/upstream/bip340.csv")
        .lines()
        .skip(1)
    {
        let row: Vec<_> = line.splitn(8, ',').collect();
        assert_eq!(row.len(), 8);
        let message = hex::decode(row[4]).unwrap();
        // The SDK signs SHA256 digests / BIP341 sighashes only. The pinned
        // secp256k1 Message API deliberately takes exactly 32 bytes.
        if message.len() != 32 {
            variable_length += 1;
            continue;
        }
        let message = Message::from_digest_slice(&message).unwrap();
        let valid = XOnlyPublicKey::from_str(row[2]).ok().is_some_and(|key| {
            schnorr::Signature::from_str(row[5])
                .ok()
                .is_some_and(|signature| secp.verify_schnorr(&signature, &message, &key).is_ok())
        });
        assert_eq!(valid, row[6] == "TRUE", "BIP340 vector {}", row[0]);
        verified += 1;
        if !row[1].is_empty() {
            let key = Keypair::from_secret_key(&secp, &SecretKey::from_str(row[1]).unwrap());
            let randomness: [u8; 32] = hex::decode(row[3]).unwrap().try_into().unwrap();
            let signature = secp.sign_schnorr_with_aux_rand(&message, &key, &randomness);
            assert_eq!(signature.to_string(), row[5].to_lowercase());
            signed += 1;
        }
    }
    assert_eq!((verified, signed, variable_length), (15, 4, 4));
}

#[test]
fn official_bip341_key_path_sighashes_tweaks_and_witnesses() {
    let vectors: serde_json::Value =
        serde_json::from_str(include_str!("../fixtures/upstream/bip341.json")).unwrap();
    let secp = Secp256k1::new();
    let mut count = 0;
    for vector in vectors["keyPathSpending"].as_array().unwrap() {
        let raw = hex::decode(vector["given"]["rawUnsignedTx"].as_str().unwrap()).unwrap();
        let tx: Transaction = bitcoin::consensus::deserialize(&raw).unwrap();
        let previous: Vec<TxOut> = vector["given"]["utxosSpent"]
            .as_array()
            .unwrap()
            .iter()
            .map(|utxo| TxOut {
                value: Amount::from_sat(utxo["amountSats"].as_u64().unwrap()),
                script_pubkey: ScriptBuf::from_hex(utxo["scriptPubKey"].as_str().unwrap()).unwrap(),
            })
            .collect();
        let mut cache = SighashCache::new(&tx);
        for input in vector["inputSpending"].as_array().unwrap() {
            let index = usize::try_from(input["given"]["txinIndex"].as_u64().unwrap()).unwrap();
            let hash_type = TapSighashType::from_consensus_u8(
                u8::try_from(input["given"]["hashType"].as_u64().unwrap()).unwrap(),
            )
            .unwrap();
            let digest = cache
                .taproot_key_spend_signature_hash(index, &Prevouts::All(&previous), hash_type)
                .unwrap();
            assert_eq!(
                digest.to_string(),
                input["intermediary"]["sigHash"].as_str().unwrap()
            );
            let root = input["given"]["merkleRoot"]
                .as_str()
                .map(|hex| TapNodeHash::from_str(hex).unwrap());
            let private =
                SecretKey::from_str(input["given"]["internalPrivkey"].as_str().unwrap()).unwrap();
            let key = Keypair::from_secret_key(&secp, &private)
                .tap_tweak(&secp, root)
                .to_keypair();
            assert_eq!(
                hex::encode(key.secret_bytes()),
                input["intermediary"]["tweakedPrivkey"].as_str().unwrap()
            );
            let signature = bitcoin::taproot::Signature {
                signature: secp.sign_schnorr_with_aux_rand(
                    &Message::from_digest(digest.to_byte_array()),
                    &key,
                    &[0; 32],
                ),
                sighash_type: hash_type,
            };
            assert_eq!(
                hex::encode(signature.to_vec()),
                input["expected"]["witness"][0].as_str().unwrap()
            );
            let output_key =
                XOnlyPublicKey::from_slice(&previous[index].script_pubkey.as_bytes()[2..]).unwrap();
            secp.verify_schnorr(
                &signature.signature,
                &Message::from_digest(digest.to_byte_array()),
                &output_key,
            )
            .unwrap();
            count += 1;
        }
    }
    // Primitive vectors exercise all seven BIP341 hash types; SDK policy
    // separately rejects every type other than DEFAULT and ALL.
    assert_eq!(count, 7);
}

#[test]
fn every_non_approved_sighash_byte_is_rejected() {
    let signer = signer(Network::Mainnet, BIP86_MNEMONIC);
    let original = parse_test_psbt(&test_psbt(&signer, 30_000, 69_500));
    for hash_type in 0..=255 {
        let mut psbt = original.clone();
        psbt.inputs[0].sighash_type = Some(bitcoin::psbt::PsbtSighashType::from_u32(hash_type));
        let result = signer.validate_psbt(encode_test_psbt(&psbt), send_intent(&signer));
        assert_eq!(result.is_ok(), hash_type <= 1, "sighash {hash_type}");
    }
}

#[test]
fn psbt_truncations_and_trailing_bytes_always_fail_closed() {
    let signer = signer(Network::Mainnet, BIP86_MNEMONIC);
    let encoded = test_psbt(&signer, 30_000, 69_500);
    let bytes = STANDARD.decode(&encoded).unwrap();
    let intent = send_intent(&signer);
    for length in 0..bytes.len() {
        assert!(
            signer
                .validate_psbt(STANDARD.encode(&bytes[..length]), intent.clone())
                .is_err(),
            "truncation {length}"
        );
    }
    for tail in [vec![0], vec![0xff], vec![0; 64], bytes.clone()] {
        let mut trailing = bytes.clone();
        trailing.extend(tail);
        assert!(
            signer
                .validate_psbt(STANDARD.encode(trailing), intent.clone())
                .is_err()
        );
    }
    let mut exact = intent.clone();
    exact.policy.max_psbt_bytes = u32::try_from(bytes.len()).unwrap();
    assert!(signer.validate_psbt(encoded.clone(), exact.clone()).is_ok());
    exact.policy.max_psbt_bytes -= 1;
    assert!(signer.validate_psbt(encoded, exact).is_err());
}

#[test]
fn deterministic_psbt_byte_mutations_never_panic_or_change_authorized_value() {
    let signer = signer(Network::Mainnet, BIP86_MNEMONIC);
    let bytes = STANDARD.decode(test_psbt(&signer, 30_000, 69_500)).unwrap();
    let intent = send_intent(&signer);
    for index in 0..bytes.len() {
        for bit in [1_u8, 0x80, 0xff] {
            let mut mutation = bytes.clone();
            mutation[index] ^= bit;
            if let Ok(report) = signer.validate_psbt(STANDARD.encode(mutation), intent.clone()) {
                // An outpoint mutation can remain authorized: existence is
                // deliberately not claimed. Output/fee invariants must hold.
                assert_eq!(report.external_output_sats, 30_000);
                assert_eq!(
                    report.total_input_sats - report.total_output_sats,
                    report.fee_sats
                );
                assert!(report.fee_sats <= intent.policy.max_absolute_fee_sats);
                assert!(
                    report.fee_rate_msat_per_vbyte <= intent.policy.max_fee_rate_msat_per_vbyte
                );
                assert_eq!(
                    (
                        report.input_count,
                        report.output_count,
                        report.op_return_count
                    ),
                    (1, 2, 0)
                );
            }
        }
    }
}

#[test]
fn amount_and_fee_boundaries_remain_exact() {
    let signer = signer(Network::Mainnet, BIP86_MNEMONIC);
    for fee in [0, 1, 499, 500, 501, 999, 1_000, 1_001, 10_000] {
        let psbt = test_psbt(&signer, 30_000, 70_000 - fee);
        let mut intent = send_intent(&signer);
        intent.policy.max_absolute_fee_sats = 1_000;
        let result = signer.validate_psbt(psbt, intent);
        assert_eq!(result.is_ok(), fee <= 1_000, "fee {fee}");
        if let Ok(report) = result {
            assert_eq!(report.fee_sats, fee);
        }
    }
    let psbt = test_psbt(&signer, 30_000, 69_500);
    let report = signer
        .validate_psbt(psbt.clone(), send_intent(&signer))
        .unwrap();
    let mut exact = send_intent(&signer);
    exact.policy.max_fee_rate_msat_per_vbyte = report.fee_rate_msat_per_vbyte;
    assert!(signer.validate_psbt(psbt.clone(), exact.clone()).is_ok());
    exact.policy.max_fee_rate_msat_per_vbyte -= 1;
    assert!(signer.validate_psbt(psbt, exact).is_err());
}

#[test]
fn signed_transaction_mutations_are_detected_for_every_signature_byte() {
    let signer = signer(Network::Mainnet, BIP86_MNEMONIC);
    let encoded = test_psbt(&signer, 30_000, 69_500);
    let prepared = parse_test_psbt(&encoded);
    let result = signer.sign_psbt(encoded, send_intent(&signer)).unwrap();
    let finalized = parse_test_psbt(&result.signed_psbt_base64);
    let signature = finalized.inputs[0]
        .final_script_witness
        .as_ref()
        .unwrap()
        .iter()
        .next()
        .unwrap();
    for index in 0..signature.len() {
        let mut changed = signature.to_vec();
        changed[index] ^= 1;
        let mut mutation = finalized.clone();
        mutation.inputs[0].final_script_witness = Some(Witness::from_slice(&[changed]));
        assert!(verify_finalized_transaction(&prepared, &mutation, &result.validation).is_err());
    }
}

#[test]
fn multi_input_nonzero_derivation_profile_fixture() {
    let signer = signer(Network::Mainnet, BIP86_MNEMONIC);
    let root = signer.root().unwrap();
    let mut psbt = parse_test_psbt(&test_psbt(&signer, 30_000, 69_500));
    psbt.unsigned_tx.output[1].value = Amount::from_sat(169_500);
    psbt.unsigned_tx
        .input
        .push(psbt.unsigned_tx.input[0].clone());
    psbt.unsigned_tx.input[1].previous_output.txid = Txid::from_byte_array([8; 32]);
    psbt.inputs.push(psbt.inputs[0].clone());
    for (index, input) in psbt.inputs.iter_mut().enumerate() {
        let path = address_path(
            Network::Mainnet,
            AccountKind::Vanilla,
            Keychain::External,
            u32::try_from(index + 2).unwrap(),
        )
        .unwrap();
        let (key, script) = derive_owned_script(&root, Network::Mainnet, &path).unwrap();
        input.witness_utxo = Some(TxOut {
            value: Amount::from_sat(100_000),
            script_pubkey: script,
        });
        input.tap_internal_key = Some(key);
        input.tap_key_origins.clear();
        input
            .tap_key_origins
            .insert(key, (Vec::new(), (master_fingerprint(&root), path)));
    }
    let encoded = encode_test_psbt(&psbt);
    let intent = send_intent(&signer);
    let signed = signer.sign_psbt(encoded.clone(), intent.clone()).unwrap();
    assert_eq!(signed.signed_input_count, 2);
    let mut one_input = intent.clone();
    one_input.policy.max_inputs = 1;
    assert!(signer.validate_psbt(encoded.clone(), one_input).is_err());
    let mut child_limit = intent.clone();
    child_limit.policy.max_child_index = 1;
    assert!(signer.validate_psbt(encoded.clone(), child_limit).is_err());
    println!(
        "MULTI_FIXTURE={}",
        serde_json::json!({
            "mnemonic": BIP86_MNEMONIC,
            "psbt": encoded,
            "recipient": intent.recipients[0].address,
            "txid": signed.validation.unsigned_txid,
            "vbytes": signed.validation.estimated_vbytes,
            "inputCount": 2,
            "maximumInputChild": 3,
            "feeSats": 500,
        })
    );
}
