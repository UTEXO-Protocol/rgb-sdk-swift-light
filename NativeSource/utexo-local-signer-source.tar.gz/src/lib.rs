mod error;
mod gateway;
mod invoice;
mod keys;
mod model;
mod policy;

use std::sync::Arc;

use base64::Engine;
use base64::engine::general_purpose::STANDARD;
use bip39::{Language, Mnemonic};
use bitcoin::bip32::{Xpriv, Xpub};
use zeroize::Zeroizing;

pub use error::SignerError;
pub use invoice::{decode_rgb_invoice, rgb_invoice_witness_recipient};
pub use model::{
    AccountKind, CreateUtxosAuthorization, DecodedRgbInvoice, DerivedAddress, GatewayOwnedOutput,
    GatewaySigningIntent, GeneratedKeys, KeyScope, Keychain, Network, OperationKind, RbfPolicy,
    Recipient, RgbBitcoinAuthorization, RgbInvoiceAssignment, RgbInvoiceAssignmentKind,
    RgbInvoiceEncodedState, RgbInvoiceEncodedStateKind, RgbInvoiceEncryption,
    RgbInvoiceRecipientType, SigningIntent, SigningPolicy, SigningResult, ValidationReport,
    WalletIdentity, default_signing_policy, gateway_signing_policy,
};

use crate::error::{Result, SignerError as Error, invalid_argument};
use crate::keys::{
    derive_address_from_root, generated_from_root, generated_from_seed, identity_from_root,
    mnemonic_seed, randomized_signing_context, root_xpriv, sign_legacy_message,
    verify_legacy_message,
};
use crate::policy::validate;

/// Extracts bounded, untrusted colored-output hints from an unsigned create
/// preparation. This does not prove wallet ownership, input safety, fees or
/// authorization. The caller must bind the returned plan to its original
/// request and run `validate_gateway_psbt` / `sign_gateway_psbt`, which derive
/// every owned key and script independently, before accepting or signing it.
/// Vanilla change is deliberately excluded from the returned plan.
///
/// # Errors
/// Returns a parsing or policy error for malformed, oversized or out-of-profile
/// preparations. No seed material or network request is involved.
#[uniffi::export]
#[allow(clippy::needless_pass_by_value)] // UniFFI owns the boundary value.
pub fn extract_gateway_create_utxos_outputs(
    psbt_base64: String,
    network: Network,
) -> Result<Vec<GatewayOwnedOutput>> {
    crate::policy::extract_gateway_create_outputs(&psbt_base64, network)
}

/// A short-lived, in-memory signing session. Native facades load encrypted seed
/// material only while the wallet is unlocked and drop this object on lock.
#[derive(uniffi::Object)]
pub struct LocalSigner {
    network: Network,
    seed: Zeroizing<Vec<u8>>,
}

#[uniffi::export]
#[allow(clippy::needless_pass_by_value)] // UniFFI owns values crossing the boundary.
impl LocalSigner {
    /// Opens a signing session from a validated English BIP39 mnemonic.
    ///
    /// # Errors
    ///
    /// Returns `InvalidMnemonic` for malformed/checksum-invalid words and
    /// `InvalidArgument` when the optional passphrase is not UTF-8.
    #[uniffi::constructor]
    pub fn from_mnemonic(
        network: Network,
        mnemonic_utf8: Vec<u8>,
        passphrase_utf8: Vec<u8>,
    ) -> Result<Arc<Self>> {
        let mnemonic_utf8 = Zeroizing::new(mnemonic_utf8);
        let passphrase_utf8 = Zeroizing::new(passphrase_utf8);
        let seed = mnemonic_seed(&mnemonic_utf8, &passphrase_utf8)?;
        Ok(Arc::new(Self { network, seed }))
    }

    #[uniffi::constructor]
    /// Opens a signing session from an exact 64-byte BIP39 seed.
    ///
    /// # Errors
    ///
    /// Returns `InvalidSeed` unless the input is exactly 64 bytes.
    pub fn from_seed(network: Network, seed: Vec<u8>) -> Result<Arc<Self>> {
        let seed = Zeroizing::new(seed);
        if seed.len() != 64 {
            return Err(Error::InvalidSeed);
        }
        Ok(Arc::new(Self { network, seed }))
    }

    /// Returns watch-only public identity values for backend registration.
    ///
    /// # Errors
    ///
    /// Returns `KeyDerivation` if deterministic BIP32 derivation fails.
    pub fn identity(&self) -> Result<WalletIdentity> {
        identity_from_root(&self.root()?, self.network)
    }

    /// Derives a BIP86 P2TR address in the frozen UTEXO v1 profile.
    ///
    /// # Errors
    ///
    /// Returns `KeyDerivation` when the requested path cannot be derived.
    pub fn derive_address(
        &self,
        account: AccountKind,
        keychain: Keychain,
        index: u32,
    ) -> Result<DerivedAddress> {
        derive_address_from_root(&self.root()?, self.network, account, keychain, index)
    }

    /// RN-compatible legacy account message signature: SHA256(message), then a
    /// BIP340 Schnorr signature at vanilla account child /0/0, base64 encoded.
    /// This is not BIP322 and must not be reused as a generic login protocol.
    ///
    /// # Errors
    ///
    /// Returns `InvalidArgument` for an empty message, `KeyDerivation` if the
    /// compatibility key cannot be derived, or `EntropyUnavailable` if signing
    /// cannot obtain context and BIP340 auxiliary randomness.
    pub fn sign_message(&self, message_utf8: Vec<u8>) -> Result<String> {
        if message_utf8.is_empty() {
            return Err(invalid_argument("message must not be empty"));
        }
        Ok(STANDARD.encode(sign_legacy_message(
            &self.root()?,
            self.network,
            &message_utf8,
        )?))
    }

    /// Parses and validates a PSBT against the immutable caller intent without
    /// producing any signatures.
    ///
    /// # Errors
    ///
    /// Returns `InvalidPsbt`, `InvalidNetwork`, or `PolicyRejected` on any
    /// malformed or unapproved transaction property.
    pub fn validate_psbt(
        &self,
        psbt_base64: String,
        intent: SigningIntent,
    ) -> Result<ValidationReport> {
        let root = self.root()?;
        let validated = validate(&root, self.network, &psbt_base64, &intent)?;
        Ok(validated.report)
    }

    /// Re-runs all policy checks, then signs and finalizes every approved BIP86
    /// key-path input. The returned PSBT contains a verified final witness;
    /// consumed input signing metadata is removed per BIP174/BIP371.
    ///
    /// # Errors
    ///
    /// Returns a validation error before signing or `SigningFailed` if every
    /// input cannot be signed by this wallet.
    pub fn sign_psbt(&self, psbt_base64: String, intent: SigningIntent) -> Result<SigningResult> {
        let root = self.root()?;
        let validated = validate(&root, self.network, &psbt_base64, &intent)?;
        sign_validated(&root, validated)
    }

    /// Validates a branch-0 RGB-lib builder preparation against independent
    /// height/fee bounds and operation-specific caller authorization. RGB
    /// transitions and consignment validity remain server-trusted.
    ///
    /// # Errors
    /// Returns a validation error for malformed or unauthorized preparations.
    pub fn validate_gateway_psbt(
        &self,
        psbt_base64: String,
        intent: GatewaySigningIntent,
    ) -> Result<ValidationReport> {
        Ok(
            crate::policy::validate_gateway(&self.root()?, self.network, &psbt_base64, &intent)?
                .report,
        )
    }

    /// Validates, signs and finalizes the additive gateway profile. It never
    /// changes the prepared transaction's locktime, scripts or amounts.
    ///
    /// # Errors
    /// Returns a policy error before signing or a signature verification error.
    pub fn sign_gateway_psbt(
        &self,
        psbt_base64: String,
        intent: GatewaySigningIntent,
    ) -> Result<SigningResult> {
        let root = self.root()?;
        let validated =
            crate::policy::validate_gateway(&root, self.network, &psbt_base64, &intent)?;
        sign_validated(&root, validated)
    }
}

fn sign_validated(
    root: &Xpriv,
    mut validated: crate::policy::ValidatedPsbt,
) -> Result<SigningResult> {
    let unsigned_psbt = validated.psbt.clone();
    let signed_input_count = sign_taproot_key_path_inputs(root, &mut validated.psbt)?;
    let mut psbt_without_signatures = validated.psbt.clone();
    for input in &mut psbt_without_signatures.inputs {
        input.tap_key_sig = None;
    }
    if psbt_without_signatures != unsigned_psbt {
        return Err(Error::SignatureVerification);
    }
    verify_taproot_signatures(&validated.psbt)?;
    finalize_taproot_key_path_inputs(&mut validated.psbt)?;
    verify_finalized_transaction(&unsigned_psbt, &validated.psbt, &validated.report)?;
    Ok(SigningResult {
        signed_psbt_base64: STANDARD.encode(validated.psbt.serialize()),
        signed_input_count,
        validation: validated.report,
    })
}

fn finalize_taproot_key_path_inputs(psbt: &mut bitcoin::psbt::Psbt) -> Result<()> {
    for input in &mut psbt.inputs {
        let signature = input
            .tap_key_sig
            .take()
            .ok_or(Error::SignatureVerification)?;
        input.final_script_witness = Some(bitcoin::Witness::from_slice(&[signature.to_vec()]));
        input.sighash_type = None;
        input.tap_internal_key = None;
        input.tap_key_origins.clear();
        // Validation rejects all other script/signature/preimage maps. Keep
        // UTXO evidence, as required by the PSBT finalizer/extractor contract.
    }
    Ok(())
}

fn verify_finalized_transaction(
    prepared: &bitcoin::psbt::Psbt,
    finalized: &bitcoin::psbt::Psbt,
    report: &ValidationReport,
) -> Result<()> {
    use bitcoin::hashes::Hash;
    use bitcoin::secp256k1::{Message, XOnlyPublicKey};
    use bitcoin::sighash::{Prevouts, SighashCache};

    if finalized.unsigned_tx != prepared.unsigned_tx || finalized.outputs != prepared.outputs {
        return Err(Error::SignatureVerification);
    }
    let transaction = finalized
        .clone()
        .extract_tx()
        .map_err(|_| Error::SignatureVerification)?;
    if transaction.compute_txid().to_string() != report.unsigned_txid
        || u64::try_from(transaction.vsize()).map_err(|_| Error::SignatureVerification)?
            != report.estimated_vbytes
    {
        return Err(Error::SignatureVerification);
    }
    let previous_outputs = prepared
        .inputs
        .iter()
        .map(|input| {
            input
                .witness_utxo
                .as_ref()
                .ok_or(Error::SignatureVerification)
        })
        .collect::<Result<Vec<_>>>()?;
    let secp = bitcoin::secp256k1::Secp256k1::verification_only();
    let mut cache = SighashCache::new(&transaction);
    for (index, input) in transaction.input.iter().enumerate() {
        if input.witness.len() != 1 || !input.script_sig.is_empty() {
            return Err(Error::SignatureVerification);
        }
        let signature = bitcoin::taproot::Signature::from_slice(
            input
                .witness
                .iter()
                .next()
                .ok_or(Error::SignatureVerification)?,
        )
        .map_err(|_| Error::SignatureVerification)?;
        let previous = previous_outputs
            .get(index)
            .ok_or(Error::SignatureVerification)?;
        if !previous.script_pubkey.is_p2tr() {
            return Err(Error::SignatureVerification);
        }
        let output_key = XOnlyPublicKey::from_slice(&previous.script_pubkey.as_bytes()[2..])
            .map_err(|_| Error::SignatureVerification)?;
        let sighash = cache
            .taproot_key_spend_signature_hash(
                index,
                &Prevouts::All(&previous_outputs),
                signature.sighash_type,
            )
            .map_err(|_| Error::SignatureVerification)?;
        secp.verify_schnorr(
            &signature.signature,
            &Message::from_digest(sighash.to_byte_array()),
            &output_key,
        )
        .map_err(|_| Error::SignatureVerification)?;
    }
    Ok(())
}

fn sign_taproot_key_path_inputs(root: &Xpriv, psbt: &mut bitcoin::psbt::Psbt) -> Result<u32> {
    use bitcoin::hashes::Hash;
    use bitcoin::key::TapTweak;
    use bitcoin::secp256k1::Message;
    use bitcoin::sighash::{Prevouts, SighashCache, TapSighashType};
    use bitcoin::taproot;

    let previous_outputs = psbt
        .inputs
        .iter()
        .map(|input| {
            input
                .witness_utxo
                .clone()
                .ok_or(Error::SignatureVerification)
        })
        .collect::<Result<Vec<_>>>()?;
    let signing_metadata = psbt
        .inputs
        .iter()
        .map(|input| {
            let (_, (_, (_, path))) = input
                .tap_key_origins
                .iter()
                .next()
                .ok_or(Error::SignatureVerification)?;
            let sighash_type = input
                .sighash_type
                .map(bitcoin::psbt::PsbtSighashType::taproot_hash_ty)
                .transpose()
                .map_err(|_| Error::SignatureVerification)?
                .unwrap_or(TapSighashType::Default);
            Ok((path.clone(), sighash_type))
        })
        .collect::<Result<Vec<_>>>()?;

    let secp = randomized_signing_context()?;
    let mut cache = SighashCache::new(&psbt.unsigned_tx);
    let mut signatures = Vec::with_capacity(signing_metadata.len());
    for (index, (path, sighash_type)) in signing_metadata.iter().enumerate() {
        let child = root
            .derive_priv(&secp, path)
            .map_err(|_| Error::KeyDerivation)?;
        let tweaked = child.to_keypair(&secp).tap_tweak(&secp, None);
        let sighash = cache
            .taproot_key_spend_signature_hash(
                index,
                &Prevouts::All(&previous_outputs),
                *sighash_type,
            )
            .map_err(|_| Error::SigningFailed)?;
        let message = Message::from_digest(sighash.to_byte_array());
        let mut aux_rand = Zeroizing::new([0_u8; 32]);
        getrandom::fill(aux_rand.as_mut()).map_err(|_| Error::EntropyUnavailable)?;
        let signature = secp.sign_schnorr_with_aux_rand(&message, tweaked.as_keypair(), &aux_rand);
        let (output_key, _) = tweaked.public_parts();
        secp.verify_schnorr(&signature, &message, output_key.as_x_only_public_key())
            .map_err(|_| Error::SignatureVerification)?;
        signatures.push(taproot::Signature {
            signature,
            sighash_type: *sighash_type,
        });
    }

    for (input, signature) in psbt.inputs.iter_mut().zip(signatures) {
        input.tap_key_sig = Some(signature);
    }
    u32::try_from(psbt.inputs.len()).map_err(|_| Error::SigningFailed)
}

impl LocalSigner {
    fn root(&self) -> Result<Xpriv> {
        root_xpriv(&self.seed, self.network)
    }
}

fn verify_taproot_signatures(psbt: &bitcoin::psbt::Psbt) -> Result<()> {
    use bitcoin::hashes::Hash;
    use bitcoin::key::TapTweak;
    use bitcoin::secp256k1::Message;
    use bitcoin::sighash::{Prevouts, SighashCache};

    let previous_outputs = psbt
        .inputs
        .iter()
        .map(|input| {
            input
                .witness_utxo
                .as_ref()
                .ok_or(Error::SignatureVerification)
        })
        .collect::<Result<Vec<_>>>()?;
    let secp = bitcoin::secp256k1::Secp256k1::verification_only();
    let mut cache = SighashCache::new(&psbt.unsigned_tx);
    for (index, input) in psbt.inputs.iter().enumerate() {
        let signature = input
            .tap_key_sig
            .as_ref()
            .ok_or(Error::SignatureVerification)?;
        let internal_key = input.tap_internal_key.ok_or(Error::SignatureVerification)?;
        let sighash = cache
            .taproot_key_spend_signature_hash(
                index,
                &Prevouts::All(&previous_outputs),
                signature.sighash_type,
            )
            .map_err(|_| Error::SignatureVerification)?;
        let (output_key, _) = internal_key.tap_tweak(&secp, None);
        secp.verify_schnorr(
            &signature.signature,
            &Message::from_digest(sighash.to_byte_array()),
            output_key.as_x_only_public_key(),
        )
        .map_err(|_| Error::SignatureVerification)?;
    }
    Ok(())
}

#[uniffi::export]
/// Generates a 12-word English BIP39 wallet and its RN-compatible key fields.
///
/// # Errors
///
/// Returns `EntropyUnavailable` if the operating system RNG fails, or
/// `KeyDerivation` if BIP32 derivation fails.
pub fn generate_keys(network: Network) -> Result<GeneratedKeys> {
    let mut entropy = Zeroizing::new([0_u8; 16]);
    getrandom::fill(entropy.as_mut()).map_err(|_| Error::EntropyUnavailable)?;
    let mnemonic = Mnemonic::from_entropy_in(Language::English, entropy.as_ref())
        .map_err(|_| Error::KeyDerivation)?;
    let phrase = mnemonic.to_string();
    let seed = Zeroizing::new(mnemonic.to_seed("").to_vec());
    generated_from_seed(&seed, network, phrase)
}

#[uniffi::export]
#[allow(clippy::needless_pass_by_value)] // UniFFI owns values crossing the boundary.
/// Recreates RN-compatible key fields from an English BIP39 mnemonic.
///
/// # Errors
///
/// Returns `InvalidMnemonic`, `InvalidArgument`, or `KeyDerivation` for invalid
/// inputs or deterministic derivation failure.
pub fn derive_keys_from_mnemonic(
    network: Network,
    mnemonic_utf8: Vec<u8>,
    passphrase_utf8: Vec<u8>,
) -> Result<GeneratedKeys> {
    let mnemonic_utf8 = Zeroizing::new(mnemonic_utf8);
    let passphrase_utf8 = Zeroizing::new(passphrase_utf8);
    let phrase = std::str::from_utf8(&mnemonic_utf8).map_err(|_| Error::InvalidMnemonic)?;
    let normalized = Zeroizing::new(phrase.split_whitespace().collect::<Vec<_>>().join(" "));
    let seed = mnemonic_seed(&mnemonic_utf8, &passphrase_utf8)?;
    generated_from_seed(&seed, network, normalized.to_string())
}

#[uniffi::export]
#[allow(clippy::needless_pass_by_value)] // UniFFI owns values crossing the boundary.
/// Derives the exact 64-byte BIP39 seed used by the local signer.
///
/// Native facades immediately wrap the returned bytes in their redacting seed
/// container and wipe temporary buffers. This exists so applications never need
/// a second BIP39 implementation when provisioning Keychain/Keystore storage.
///
/// # Errors
///
/// Returns `InvalidMnemonic` or `InvalidArgument` for invalid mnemonic or
/// passphrase UTF-8 input.
pub fn derive_seed_from_mnemonic(
    mnemonic_utf8: Vec<u8>,
    passphrase_utf8: Vec<u8>,
) -> Result<Vec<u8>> {
    let mnemonic_utf8 = Zeroizing::new(mnemonic_utf8);
    let passphrase_utf8 = Zeroizing::new(passphrase_utf8);
    let seed = mnemonic_seed(&mnemonic_utf8, &passphrase_utf8)?;
    Ok(seed.to_vec())
}

#[uniffi::export]
#[allow(clippy::needless_pass_by_value)] // UniFFI owns values crossing the boundary.
/// Recreates RN-compatible key fields from an exact 64-byte BIP39 seed.
///
/// The returned mnemonic is empty because a BIP39 seed cannot be reversed to
/// its mnemonic. The native facades expose this distinction explicitly.
///
/// # Errors
///
/// Returns `InvalidSeed` unless `seed` is exactly 64 bytes.
pub fn derive_keys_from_seed(network: Network, seed: Vec<u8>) -> Result<GeneratedKeys> {
    let seed = Zeroizing::new(seed);
    if seed.len() != 64 {
        return Err(Error::InvalidSeed);
    }
    generated_from_seed(&seed, network, String::new())
}

#[uniffi::export]
#[allow(clippy::needless_pass_by_value)] // UniFFI owns values crossing the boundary.
/// Returns the public BIP32 extended key corresponding to an extended private
/// key. This operation never performs child derivation.
///
/// # Errors
///
/// Returns `InvalidArgument` when `xpriv` is not a valid extended private key.
pub fn get_xpub_from_xpriv(xpriv: String) -> Result<String> {
    use std::str::FromStr;

    let xpriv = Zeroizing::new(xpriv);
    let root = Xpriv::from_str(xpriv.trim())
        .map_err(|_| invalid_argument("xpriv must be a valid extended private key"))?;
    Ok(Xpub::from_priv(&bitcoin::secp256k1::Secp256k1::new(), &root).to_string())
}

#[uniffi::export]
#[allow(clippy::needless_pass_by_value)] // UniFFI owns values crossing the boundary.
/// Recreates account public keys from a root extended private key.
///
/// This is a dangerous compatibility/export path. Applications should prefer
/// encrypted seed restoration through the native facade.
///
/// # Errors
///
/// Returns `InvalidArgument` unless `xpriv` is a root key for `network`.
pub fn derive_keys_from_xpriv(network: Network, xpriv: String) -> Result<GeneratedKeys> {
    use std::str::FromStr;

    let xpriv = Zeroizing::new(xpriv);
    let root = Xpriv::from_str(xpriv.trim())
        .map_err(|_| invalid_argument("xpriv must be a valid extended private key"))?;
    generated_from_root(&root, network, String::new())
}

#[uniffi::export]
#[allow(clippy::needless_pass_by_value)] // UniFFI owns values crossing the boundary.
/// Verifies the RN-compatible account-child BIP340 message signature.
///
/// # Errors
///
/// Returns `InvalidArgument` for malformed inputs or `KeyDerivation` if the
/// account child cannot be derived.
pub fn verify_message(
    message_utf8: Vec<u8>,
    signature_base64: String,
    account_xpub: String,
) -> Result<bool> {
    if message_utf8.is_empty() {
        return Err(invalid_argument("message must not be empty"));
    }
    let signature = STANDARD
        .decode(signature_base64.trim())
        .map_err(|_| invalid_argument("signature must be base64"))?;
    verify_legacy_message(&account_xpub, &message_utf8, &signature)
}

uniffi::setup_scaffolding!();

#[cfg(test)]
mod tests;
