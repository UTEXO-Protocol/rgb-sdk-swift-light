#![allow(
    clippy::expect_used,
    clippy::panic,
    clippy::similar_names,
    clippy::unwrap_used
)]

use std::sync::Arc;

use base64::Engine;
use base64::engine::general_purpose::STANDARD;
use bitcoin::absolute::LockTime;
use bitcoin::bip32::{KeySource, Xpriv};
use bitcoin::hashes::Hash;
use bitcoin::psbt::Psbt;
use bitcoin::transaction::Version;
use bitcoin::{Amount, OutPoint, ScriptBuf, Sequence, Transaction, TxIn, TxOut, Txid, Witness};

use super::*;
use crate::keys::{address_path, derive_owned_script, master_fingerprint};

#[path = "assurance_tests.rs"]
mod assurance;
#[path = "gateway_tests.rs"]
mod gateway;

const BIP86_MNEMONIC: &str =
    "abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about";
const RN_VECTOR_MNEMONIC: &str =
    "flight seminar tray bulb level embody switch enhance august deny scene dismiss";

fn signer(network: Network, mnemonic: &str) -> Arc<LocalSigner> {
    LocalSigner::from_mnemonic(network, mnemonic.as_bytes().to_vec(), Vec::new())
        .unwrap_or_else(|error| panic!("test signer creation failed: {error}"))
}

#[test]
fn matches_bip86_first_mainnet_address_vector() {
    let signer = signer(Network::Mainnet, BIP86_MNEMONIC);
    let derived = signer
        .derive_address(AccountKind::Vanilla, Keychain::External, 0)
        .unwrap_or_else(|error| panic!("address derivation failed: {error}"));
    assert_eq!(
        derived.internal_key_hex,
        "cc8a4bc64d897bddc5fbc2f670f7a8ba0b386779106cf1223c6fc5d7cd6fc115"
    );
    assert_eq!(
        derived.script_pubkey_hex,
        "5120a60869f0dbcf1dc659c9cecbaf8050135ea9e8cdc487053f1dc6880949dc684c"
    );
    assert_eq!(
        derived.address,
        "bc1p5cyxnuxmeuwuvkwfem96lqzszd02n6xdcjrs20cac6yqjjwudpxqkedrcr"
    );
}

#[test]
fn matches_existing_rn_key_vector() {
    let keys = derive_keys_from_mnemonic(
        Network::Testnet,
        RN_VECTOR_MNEMONIC.as_bytes().to_vec(),
        Vec::new(),
    )
    .unwrap_or_else(|error| panic!("key derivation failed: {error}"));
    assert_eq!(keys.master_fingerprint, "42424232");
    assert_eq!(
        keys.xpub,
        "tpubD6NzVbkrYhZ4WLw9njYmLvMEWp5nqVmjfkgAZfj7uivNXCFS7Ls9DyDZM82P4cDpobCDGAZpNsR9Gs9wuvv5yYCNFsqxcbsDn6VU4nU3ZcW"
    );
    assert_eq!(
        keys.account_xpub_vanilla,
        "tpubDDTg3fRGqAvEvshRUUwuS8brXkewNsE6y6Jbb9xZcuzBbmxAWa3UCmwyQG4peM9RwjgY8BDwuRVRU5KGtvRby5kiv1dk13YHU8z39o18QJK"
    );
    assert_eq!(
        keys.account_xpub_colored,
        "tpubDDqoEexZxewBLjXmZ7kxSHgZgmdAtej6DrXLBMiSSuPCdGQqjkTvyETLLVY7qNpxNRGUivvxDj8sswHHihT5effNNDmsbMUX2Lrpy4zjRcS"
    );
}

#[test]
fn seed_and_root_xpriv_compatibility_helpers_preserve_identity() {
    let mnemonic =
        bip39::Mnemonic::parse_in_normalized(bip39::Language::English, RN_VECTOR_MNEMONIC)
            .unwrap_or_else(|error| panic!("mnemonic: {error}"));
    let seed = mnemonic.to_seed_normalized("");
    let exported_seed =
        derive_seed_from_mnemonic(RN_VECTOR_MNEMONIC.as_bytes().to_vec(), Vec::new())
            .unwrap_or_else(|error| panic!("exported seed derivation: {error}"));
    assert_eq!(seed.as_slice(), exported_seed.as_slice());
    let from_seed = derive_keys_from_seed(Network::Testnet, seed.to_vec())
        .unwrap_or_else(|error| panic!("seed derivation: {error}"));
    let from_xpriv = derive_keys_from_xpriv(Network::Testnet, from_seed.xpriv.clone())
        .unwrap_or_else(|error| panic!("xpriv derivation: {error}"));
    let xpub = get_xpub_from_xpriv(from_seed.xpriv.clone())
        .unwrap_or_else(|error| panic!("xpub conversion: {error}"));
    assert_eq!(from_seed.mnemonic, "");
    assert_eq!(from_seed.xpub, xpub);
    assert_eq!(from_seed.xpub, from_xpriv.xpub);
    assert_eq!(
        from_seed.account_xpub_vanilla,
        from_xpriv.account_xpub_vanilla
    );
    assert_eq!(
        from_seed.account_xpub_colored,
        from_xpriv.account_xpub_colored
    );
}

#[test]
fn rejects_non_root_or_wrong_network_xprivs() {
    let mainnet = signer(Network::Mainnet, BIP86_MNEMONIC);
    let keys = derive_keys_from_mnemonic(
        Network::Mainnet,
        BIP86_MNEMONIC.as_bytes().to_vec(),
        Vec::new(),
    )
    .unwrap_or_else(|error| panic!("key derivation: {error}"));
    assert!(derive_keys_from_xpriv(Network::Testnet, keys.xpriv).is_err());

    let root = mainnet
        .root()
        .unwrap_or_else(|error| panic!("root: {error}"));
    let child = root
        .derive_priv(
            &bitcoin::secp256k1::Secp256k1::new(),
            &address_path(
                Network::Mainnet,
                AccountKind::Vanilla,
                Keychain::External,
                0,
            )
            .unwrap_or_else(|error| panic!("path: {error}")),
        )
        .unwrap_or_else(|error| panic!("child: {error}"));
    assert!(derive_keys_from_xpriv(Network::Mainnet, child.to_string()).is_err());
}

#[test]
fn bip39_passphrase_normalization_is_nfkd_equivalent() {
    let composed = mnemonic_seed(BIP86_MNEMONIC.as_bytes(), "caf\u{e9}".as_bytes())
        .unwrap_or_else(|error| panic!("composed seed: {error}"));
    let decomposed = mnemonic_seed(BIP86_MNEMONIC.as_bytes(), "cafe\u{301}".as_bytes())
        .unwrap_or_else(|error| panic!("decomposed seed: {error}"));
    assert_eq!(composed.as_slice(), decomposed.as_slice());
}

#[test]
fn message_signatures_round_trip_and_reject_tampering() {
    let signer = signer(Network::Testnet, RN_VECTOR_MNEMONIC);
    let message = b"RGB message signing test".to_vec();
    let signature = signer
        .sign_message(message.clone())
        .unwrap_or_else(|error| panic!("message signing failed: {error}"));
    let identity = signer
        .identity()
        .unwrap_or_else(|error| panic!("identity failed: {error}"));
    assert!(
        verify_message(
            message,
            signature.clone(),
            identity.account_xpub_vanilla.clone()
        )
        .unwrap_or(false)
    );
    assert!(
        !verify_message(
            b"tampered".to_vec(),
            signature,
            identity.account_xpub_vanilla
        )
        .unwrap_or(true)
    );
}

fn test_psbt(signer: &LocalSigner, recipient_amount: u64, change_amount: u64) -> String {
    let root = Xpriv::new_master(
        bitcoin::NetworkKind::Main,
        &bip39::Mnemonic::parse_in_normalized(bip39::Language::English, BIP86_MNEMONIC)
            .unwrap_or_else(|error| panic!("mnemonic: {error}"))
            .to_seed_normalized(""),
    )
    .unwrap_or_else(|error| panic!("root: {error}"));
    let input_path = address_path(
        Network::Mainnet,
        AccountKind::Vanilla,
        Keychain::External,
        0,
    )
    .unwrap_or_else(|error| panic!("input path: {error}"));
    let recipient = signer
        .derive_address(AccountKind::Vanilla, Keychain::External, 1)
        .unwrap_or_else(|error| panic!("recipient: {error}"));
    let recipient_script = ScriptBuf::from_hex(&recipient.script_pubkey_hex)
        .unwrap_or_else(|error| panic!("recipient script: {error}"));
    let change_path = address_path(Network::Mainnet, AccountKind::Vanilla, Keychain::Change, 0)
        .unwrap_or_else(|error| panic!("change path: {error}"));
    let (input_key, input_script) = derive_owned_script(&root, Network::Mainnet, &input_path)
        .unwrap_or_else(|error| panic!("input script: {error}"));
    let (change_key, change_script) = derive_owned_script(&root, Network::Mainnet, &change_path)
        .unwrap_or_else(|error| panic!("change script: {error}"));
    let tx = Transaction {
        version: Version::TWO,
        lock_time: LockTime::ZERO,
        input: vec![TxIn {
            previous_output: OutPoint {
                txid: Txid::from_byte_array([7_u8; 32]),
                vout: 0,
            },
            script_sig: ScriptBuf::new(),
            sequence: Sequence::ENABLE_RBF_NO_LOCKTIME,
            witness: Witness::new(),
        }],
        output: vec![
            TxOut {
                value: Amount::from_sat(recipient_amount),
                script_pubkey: recipient_script,
            },
            TxOut {
                value: Amount::from_sat(change_amount),
                script_pubkey: change_script,
            },
        ],
    };
    let mut psbt =
        Psbt::from_unsigned_tx(tx).unwrap_or_else(|error| panic!("psbt creation: {error}"));
    let origin = master_fingerprint(&root);
    psbt.inputs[0].witness_utxo = Some(TxOut {
        value: Amount::from_sat(100_000),
        script_pubkey: input_script,
    });
    psbt.inputs[0].tap_internal_key = Some(input_key);
    psbt.inputs[0]
        .tap_key_origins
        .insert(input_key, (Vec::new(), (origin, input_path) as KeySource));
    psbt.outputs[1].tap_internal_key = Some(change_key);
    psbt.outputs[1]
        .tap_key_origins
        .insert(change_key, (Vec::new(), (origin, change_path) as KeySource));
    STANDARD.encode(psbt.serialize())
}

fn parse_test_psbt(encoded: &str) -> Psbt {
    let bytes = STANDARD
        .decode(encoded)
        .unwrap_or_else(|error| panic!("test PSBT base64: {error}"));
    Psbt::deserialize(&bytes).unwrap_or_else(|error| panic!("test PSBT parse: {error}"))
}

fn encode_test_psbt(psbt: &Psbt) -> String {
    STANDARD.encode(psbt.serialize())
}

fn send_intent(signer: &LocalSigner) -> SigningIntent {
    let recipient = signer
        .derive_address(AccountKind::Vanilla, Keychain::External, 1)
        .unwrap_or_else(|error| panic!("recipient: {error}"));
    SigningIntent {
        operation_id: "op_test_001".to_owned(),
        idempotency_key: "idem_test_001".to_owned(),
        network: Network::Mainnet,
        operation: OperationKind::SendBtc,
        recipients: vec![Recipient {
            address: recipient.address,
            amount_sats: 30_000,
        }],
        policy: default_signing_policy(),
    }
}

/// Regenerates the public-mnemonic, synthetic native packaging smoke fixture.
#[test]
#[ignore = "fixture generation helper; no network or real funds"]
fn print_native_smoke_fixture() {
    let signer = signer(Network::Mainnet, BIP86_MNEMONIC);
    let psbt = test_psbt(&signer, 30_000, 69_500);
    let intent = send_intent(&signer);
    let report = signer.validate_psbt(psbt.clone(), intent.clone()).unwrap();
    println!("mnemonic={BIP86_MNEMONIC}");
    println!("psbt={psbt}");
    println!("recipient={}", intent.recipients[0].address);
    println!("txid={}", report.unsigned_txid);
    println!("vbytes={}", report.estimated_vbytes);
}

#[test]
fn validates_and_signs_an_intent_bound_bip86_psbt() {
    let signer = signer(Network::Mainnet, BIP86_MNEMONIC);
    let psbt = test_psbt(&signer, 30_000, 69_500);
    let result = signer
        .sign_psbt(psbt, send_intent(&signer))
        .unwrap_or_else(|error| panic!("signing failed: {error}"));
    assert_eq!(result.signed_input_count, 1);
    assert_eq!(result.validation.total_input_sats, 100_000);
    assert_eq!(result.validation.external_output_sats, 30_000);
    assert_eq!(result.validation.change_sats, 69_500);
    assert_eq!(result.validation.fee_sats, 500);
    let signed_bytes = STANDARD
        .decode(result.signed_psbt_base64)
        .unwrap_or_else(|error| panic!("signed base64: {error}"));
    let signed_psbt =
        Psbt::deserialize(&signed_bytes).unwrap_or_else(|error| panic!("signed psbt: {error}"));
    assert!(signed_psbt.inputs[0].tap_key_sig.is_none());
    assert!(signed_psbt.inputs[0].tap_internal_key.is_none());
    assert!(signed_psbt.inputs[0].tap_key_origins.is_empty());
    let witness = signed_psbt.inputs[0].final_script_witness.as_ref().unwrap();
    assert_eq!(witness.len(), 1);
    assert_eq!(witness.iter().next().unwrap().len(), 64);
    let transaction = signed_psbt.extract_tx().unwrap();
    assert_eq!(
        transaction.compute_txid().to_string(),
        result.validation.unsigned_txid
    );
    assert_eq!(
        transaction.vsize() as u64,
        result.validation.estimated_vbytes
    );
}

#[test]
fn finalizes_mixed_default_and_all_sighashes_without_changing_transaction_or_utxos() {
    let signer = signer(Network::Mainnet, BIP86_MNEMONIC);
    let mut prepared = parse_test_psbt(&test_psbt(&signer, 30_000, 169_500));
    let mut second = prepared.unsigned_tx.input[0].clone();
    second.previous_output.vout = 1;
    prepared.unsigned_tx.input.push(second);
    let mut second_metadata = prepared.inputs[0].clone();
    second_metadata.sighash_type = Some(bitcoin::sighash::TapSighashType::All.into());
    prepared.inputs.push(second_metadata);
    let result = signer
        .sign_psbt(encode_test_psbt(&prepared), send_intent(&signer))
        .unwrap();
    let finalized = parse_test_psbt(&result.signed_psbt_base64);
    assert_eq!(result.signed_input_count, 2);
    assert_eq!(finalized.unsigned_tx, prepared.unsigned_tx);
    assert_eq!(finalized.outputs, prepared.outputs);
    for (index, (input, original)) in finalized.inputs.iter().zip(&prepared.inputs).enumerate() {
        let witness = input.final_script_witness.as_ref().unwrap();
        assert_eq!(witness.len(), 1);
        assert_eq!(witness.iter().next().unwrap().len(), 64 + index);
        assert_eq!(input.witness_utxo, original.witness_utxo);
        assert_eq!(input.non_witness_utxo, original.non_witness_utxo);
        assert!(input.sighash_type.is_none());
        assert!(input.tap_key_origins.is_empty());
    }
    verify_finalized_transaction(&prepared, &finalized, &result.validation).unwrap();
    assert!(
        signer
            .sign_psbt(result.signed_psbt_base64, send_intent(&signer))
            .is_err()
    );
}

#[test]
fn finalized_verification_rejects_tampered_witness_output_and_missing_signature() {
    let signer = signer(Network::Mainnet, BIP86_MNEMONIC);
    let encoded = test_psbt(&signer, 30_000, 69_500);
    let prepared = parse_test_psbt(&encoded);
    let result = signer.sign_psbt(encoded, send_intent(&signer)).unwrap();
    let finalized = parse_test_psbt(&result.signed_psbt_base64);

    let mut altered = finalized.clone();
    let mut signature = altered.inputs[0]
        .final_script_witness
        .as_ref()
        .unwrap()
        .iter()
        .next()
        .unwrap()
        .to_vec();
    signature[0] ^= 1;
    altered.inputs[0].final_script_witness = Some(Witness::from_slice(&[signature]));
    assert!(verify_finalized_transaction(&prepared, &altered, &result.validation).is_err());

    let mut altered = finalized.clone();
    altered.unsigned_tx.output[0].value = Amount::from_sat(29_999);
    assert!(verify_finalized_transaction(&prepared, &altered, &result.validation).is_err());

    let mut altered = finalized;
    altered.inputs[0].final_script_witness = None;
    assert!(verify_finalized_transaction(&prepared, &altered, &result.validation).is_err());
}

#[test]
fn native_boundary_enforces_the_same_hard_limits_as_both_facades() {
    let signer = signer(Network::Mainnet, BIP86_MNEMONIC);
    let psbt = test_psbt(&signer, 30_000, 69_500);
    let wideners: [fn(&mut SigningPolicy); 6] = [
        |p| p.max_psbt_bytes = 1_000_001,
        |p| p.max_inputs = 129,
        |p| p.max_outputs = 257,
        |p| p.max_child_index = 1_000_001,
        |p| p.max_absolute_fee_sats = 1_000_001,
        |p| p.max_fee_rate_msat_per_vbyte = 100_001,
    ];
    for widen in wideners {
        let mut intent = send_intent(&signer);
        widen(&mut intent.policy);
        assert!(matches!(
            signer.validate_psbt(psbt.clone(), intent),
            Err(SignerError::InvalidArgument { .. })
        ));
    }
}

#[test]
fn rejects_impossible_supply_even_with_small_apparent_fee() {
    let signer = signer(Network::Mainnet, BIP86_MNEMONIC);
    let mut psbt = parse_test_psbt(&test_psbt(&signer, 30_000, 69_500));
    let maximum = Amount::MAX_MONEY.to_sat();
    psbt.inputs[0].witness_utxo.as_mut().unwrap().value = Amount::from_sat(maximum + 1);
    psbt.unsigned_tx.output[1].value = Amount::from_sat(maximum - 30_499);
    assert!(matches!(
        signer.validate_psbt(encode_test_psbt(&psbt), send_intent(&signer)),
        Err(SignerError::PolicyRejected { .. })
    ));

    psbt.inputs[0].witness_utxo.as_mut().unwrap().value = Amount::from_sat(maximum);
    psbt.unsigned_tx.output[1].value = Amount::from_sat(maximum);
    assert!(matches!(
        signer.validate_psbt(encode_test_psbt(&psbt), send_intent(&signer)),
        Err(SignerError::PolicyRejected { .. })
    ));
}

#[test]
fn rejects_noncanonical_whitespace_around_psbt() {
    let signer = signer(Network::Mainnet, BIP86_MNEMONIC);
    let psbt = test_psbt(&signer, 30_000, 69_500);
    for altered in [format!(" {psbt}"), format!("{psbt}\n")] {
        assert!(matches!(
            signer.validate_psbt(altered, send_intent(&signer)),
            Err(SignerError::InvalidPsbt { .. })
        ));
    }
}

#[test]
fn rejects_captured_gateway_profile_and_independently_rejects_external_branch_change() {
    let signer = signer(Network::Regtest, BIP86_MNEMONIC);
    let psbt = include_str!("../fixtures/gateway-btc-pr174.psbt").trim();
    let intent = SigningIntent {
        operation_id: "5bb28e16-416e-4c59-b07d-1af5ffbce4c0".to_owned(),
        idempotency_key: "gateway_regtest_fixture".to_owned(),
        network: Network::Regtest,
        operation: OperationKind::SendBtc,
        recipients: vec![Recipient {
            address: "bcrt1pjyd6wjs2nlefjehddqsvxe8r0ng5r70urvlx72u5fvpsnhs35feqsu7305".to_owned(),
            amount_sats: 40_000,
        }],
        policy: default_signing_policy(),
    };
    let error = signer
        .validate_psbt(psbt.to_owned(), intent.clone())
        .unwrap_err();
    assert!(error.to_string().contains("locktime"));
    let mut modified = parse_test_psbt(psbt);
    modified.unsigned_tx.lock_time = LockTime::ZERO;
    let error = signer
        .validate_psbt(encode_test_psbt(&modified), intent)
        .unwrap_err();
    assert!(error.to_string().contains("derivation scope"));
}

#[test]
fn rejects_a_server_changed_recipient_amount() {
    let signer = signer(Network::Mainnet, BIP86_MNEMONIC);
    let psbt = test_psbt(&signer, 29_999, 69_501);
    let error = signer
        .validate_psbt(psbt, send_intent(&signer))
        .expect_err("changed recipient must fail");
    assert!(matches!(error, SignerError::PolicyRejected { .. }));
}

#[test]
fn rejects_an_excessive_absolute_fee() {
    let signer = signer(Network::Mainnet, BIP86_MNEMONIC);
    let psbt = test_psbt(&signer, 30_000, 50_000);
    let mut intent = send_intent(&signer);
    intent.policy.max_absolute_fee_sats = 1_000;
    let error = signer
        .validate_psbt(psbt, intent)
        .expect_err("excessive fee must fail");
    assert!(matches!(error, SignerError::PolicyRejected { .. }));
}

#[test]
fn utexo_uses_signet_addresses_but_keeps_logical_identity() {
    let signer = signer(Network::Utexo, BIP86_MNEMONIC);
    let identity = signer
        .identity()
        .unwrap_or_else(|error| panic!("identity: {error}"));
    let address = signer
        .derive_address(AccountKind::Vanilla, Keychain::External, 0)
        .unwrap_or_else(|error| panic!("address: {error}"));
    assert_eq!(identity.network, Network::Utexo);
    assert_eq!(identity.chain_network, "signet");
    assert!(address.address.starts_with("tb1p"));
}

#[test]
fn rejects_colored_inputs_for_a_plain_bitcoin_send_even_if_policy_requests_them() {
    let signer = signer(Network::Mainnet, BIP86_MNEMONIC);
    let psbt = test_psbt(&signer, 30_000, 69_500);
    let mut intent = send_intent(&signer);
    intent.policy.allowed_input_scopes.push(KeyScope {
        account: AccountKind::Colored,
        keychain: Keychain::External,
    });
    let error = signer
        .validate_psbt(psbt, intent)
        .expect_err("colored scope widening must fail");
    assert!(matches!(error, SignerError::PolicyRejected { .. }));
}

#[test]
fn rejects_unbound_create_utxos_and_rgb_operations() {
    let signer = signer(Network::Mainnet, BIP86_MNEMONIC);
    let psbt = test_psbt(&signer, 30_000, 69_500);
    for operation in [
        OperationKind::CreateUtxos,
        OperationKind::OnchainSend,
        OperationKind::Inflate,
    ] {
        let mut intent = send_intent(&signer);
        intent.operation = operation;
        if operation == OperationKind::CreateUtxos {
            intent.recipients.clear();
        }
        let error = signer
            .validate_psbt(psbt.clone(), intent)
            .expect_err("unsupported operation must fail closed");
        assert!(matches!(error, SignerError::PolicyRejected { .. }));
    }
}

#[test]
fn rejects_attempts_to_widen_the_frozen_send_profile() {
    let signer = signer(Network::Mainnet, BIP86_MNEMONIC);
    let psbt = test_psbt(&signer, 30_000, 69_500);
    let mut intents = Vec::new();

    let mut locktime = send_intent(&signer);
    locktime.policy.expected_lock_time = None;
    intents.push(locktime);

    let mut sequence = send_intent(&signer);
    sequence.policy.expected_sequence = None;
    intents.push(sequence);

    let mut fields = send_intent(&signer);
    fields.policy.allow_unknown_fields = true;
    intents.push(fields);

    let mut proprietary = send_intent(&signer);
    proprietary
        .policy
        .allowed_proprietary_prefixes
        .push("server".to_owned());
    intents.push(proprietary);

    let mut op_return = send_intent(&signer);
    op_return.policy.max_op_return_outputs = 1;
    intents.push(op_return);

    for intent in intents {
        let error = signer
            .validate_psbt(psbt.clone(), intent)
            .expect_err("profile widening must fail");
        assert!(matches!(error, SignerError::PolicyRejected { .. }));
    }
}

#[test]
fn rejects_null_and_duplicate_outpoints() {
    let signer = signer(Network::Mainnet, BIP86_MNEMONIC);
    let original = test_psbt(&signer, 30_000, 69_500);

    let mut null = parse_test_psbt(&original);
    null.unsigned_tx.input[0].previous_output = OutPoint::null();
    assert!(matches!(
        signer.validate_psbt(encode_test_psbt(&null), send_intent(&signer)),
        Err(SignerError::PolicyRejected { .. })
    ));

    let mut duplicate = parse_test_psbt(&original);
    duplicate
        .unsigned_tx
        .input
        .push(duplicate.unsigned_tx.input[0].clone());
    duplicate.inputs.push(duplicate.inputs[0].clone());
    assert!(matches!(
        signer.validate_psbt(encode_test_psbt(&duplicate), send_intent(&signer)),
        Err(SignerError::PolicyRejected { .. })
    ));
}

#[test]
fn rejects_missing_or_foreign_input_evidence() {
    let signer = signer(Network::Mainnet, BIP86_MNEMONIC);
    let original = test_psbt(&signer, 30_000, 69_500);

    let mut missing = parse_test_psbt(&original);
    missing.inputs[0].witness_utxo = None;
    assert!(matches!(
        signer.validate_psbt(encode_test_psbt(&missing), send_intent(&signer)),
        Err(SignerError::PolicyRejected { .. })
    ));

    let mut foreign = parse_test_psbt(&original);
    for (_, key_source) in foreign.inputs[0].tap_key_origins.values_mut() {
        key_source.0 = bitcoin::bip32::Fingerprint::from([9_u8; 4]);
    }
    assert!(matches!(
        signer.validate_psbt(encode_test_psbt(&foreign), send_intent(&signer)),
        Err(SignerError::PolicyRejected { .. })
    ));
}

#[test]
fn rejects_unapproved_sighash_sequence_and_extra_output() {
    let signer = signer(Network::Mainnet, BIP86_MNEMONIC);
    let original = test_psbt(&signer, 30_000, 69_500);

    let mut sighash = parse_test_psbt(&original);
    sighash.inputs[0].sighash_type = Some(bitcoin::psbt::PsbtSighashType::from_u32(0x81));
    assert!(matches!(
        signer.validate_psbt(encode_test_psbt(&sighash), send_intent(&signer)),
        Err(SignerError::PolicyRejected { .. })
    ));

    let mut sequence = parse_test_psbt(&original);
    sequence.unsigned_tx.input[0].sequence = Sequence::MAX;
    assert!(matches!(
        signer.validate_psbt(encode_test_psbt(&sequence), send_intent(&signer)),
        Err(SignerError::PolicyRejected { .. })
    ));

    let mut extra = parse_test_psbt(&original);
    let external = signer
        .derive_address(AccountKind::Vanilla, Keychain::External, 2)
        .unwrap_or_else(|error| panic!("external address: {error}"));
    extra.unsigned_tx.output.push(TxOut {
        value: Amount::from_sat(1_000),
        script_pubkey: ScriptBuf::from_hex(&external.script_pubkey_hex)
            .unwrap_or_else(|error| panic!("external script: {error}")),
    });
    extra.outputs.push(bitcoin::psbt::Output::default());
    assert!(matches!(
        signer.validate_psbt(encode_test_psbt(&extra), send_intent(&signer)),
        Err(SignerError::PolicyRejected { .. })
    ));
}

#[test]
fn rejects_an_actual_colored_account_input_for_send_btc() {
    let signer = signer(Network::Mainnet, BIP86_MNEMONIC);
    let mut psbt = parse_test_psbt(&test_psbt(&signer, 30_000, 69_500));
    let root = signer
        .root()
        .unwrap_or_else(|error| panic!("root: {error}"));
    let colored_path = address_path(
        Network::Mainnet,
        AccountKind::Colored,
        Keychain::External,
        0,
    )
    .unwrap_or_else(|error| panic!("colored path: {error}"));
    let (colored_key, colored_script) = derive_owned_script(&root, Network::Mainnet, &colored_path)
        .unwrap_or_else(|error| panic!("colored script: {error}"));
    psbt.inputs[0].witness_utxo = Some(TxOut {
        value: Amount::from_sat(100_000),
        script_pubkey: colored_script,
    });
    psbt.inputs[0].tap_internal_key = Some(colored_key);
    psbt.inputs[0].tap_key_origins.clear();
    psbt.inputs[0].tap_key_origins.insert(
        colored_key,
        (Vec::new(), (master_fingerprint(&root), colored_path)),
    );
    assert!(matches!(
        signer.validate_psbt(encode_test_psbt(&psbt), send_intent(&signer)),
        Err(SignerError::PolicyRejected { .. })
    ));
}
