use std::str::FromStr;

use bip39::{Language, Mnemonic};
use bitcoin::bip32::{ChildNumber, DerivationPath, Fingerprint, Xpriv, Xpub};
use bitcoin::hashes::{Hash, sha256};
use bitcoin::secp256k1::{Message, Secp256k1, XOnlyPublicKey, schnorr};
use bitcoin::{Address, ScriptBuf};
use zeroize::Zeroizing;

use crate::error::{Result, SignerError, invalid_argument};
use crate::model::{
    ACCOUNT_ZERO, AccountKind, DERIVATION_PROFILE_V1, DerivedAddress, GeneratedKeys, Keychain,
    Network, PURPOSE_BIP86, WalletIdentity,
};

pub(crate) fn randomized_signing_context() -> Result<Secp256k1<bitcoin::secp256k1::All>> {
    let mut secp = Secp256k1::new();
    let mut context_seed = Zeroizing::new([0_u8; 32]);
    getrandom::fill(context_seed.as_mut()).map_err(|_| SignerError::EntropyUnavailable)?;
    secp.seeded_randomize(&context_seed);
    Ok(secp)
}

pub(crate) fn account_path(network: Network, account: AccountKind) -> Result<DerivationPath> {
    let purpose =
        ChildNumber::from_hardened_idx(PURPOSE_BIP86).map_err(|_| SignerError::KeyDerivation)?;
    let coin = ChildNumber::from_hardened_idx(network.coin_type(account))
        .map_err(|_| SignerError::KeyDerivation)?;
    let account =
        ChildNumber::from_hardened_idx(ACCOUNT_ZERO).map_err(|_| SignerError::KeyDerivation)?;
    Ok(DerivationPath::from(vec![purpose, coin, account]))
}

pub(crate) fn address_path(
    network: Network,
    account: AccountKind,
    keychain: Keychain,
    index: u32,
) -> Result<DerivationPath> {
    let mut path: Vec<ChildNumber> = account_path(network, account)?.into();
    path.push(
        ChildNumber::from_normal_idx(keychain.index()).map_err(|_| SignerError::KeyDerivation)?,
    );
    path.push(ChildNumber::from_normal_idx(index).map_err(|_| SignerError::KeyDerivation)?);
    Ok(DerivationPath::from(path))
}

pub(crate) fn root_xpriv(seed: &[u8], network: Network) -> Result<Xpriv> {
    Xpriv::new_master(network.network_kind(), seed).map_err(|_| SignerError::KeyDerivation)
}

pub(crate) fn identity_from_root(root: &Xpriv, network: Network) -> Result<WalletIdentity> {
    let secp = Secp256k1::new();
    let root_pub = Xpub::from_priv(&secp, root);
    let vanilla = root
        .derive_priv(&secp, &account_path(network, AccountKind::Vanilla)?)
        .map_err(|_| SignerError::KeyDerivation)?;
    let colored = root
        .derive_priv(&secp, &account_path(network, AccountKind::Colored)?)
        .map_err(|_| SignerError::KeyDerivation)?;

    Ok(WalletIdentity {
        network,
        chain_network: network.chain_name().to_owned(),
        derivation_profile: DERIVATION_PROFILE_V1.to_owned(),
        master_fingerprint: root_pub.fingerprint().to_string(),
        xpub: root_pub.to_string(),
        account_xpub_vanilla: Xpub::from_priv(&secp, &vanilla).to_string(),
        account_xpub_colored: Xpub::from_priv(&secp, &colored).to_string(),
    })
}

pub(crate) fn generated_from_seed(
    seed: &[u8],
    network: Network,
    mnemonic: String,
) -> Result<GeneratedKeys> {
    let root = root_xpriv(seed, network)?;
    let identity = identity_from_root(&root, network)?;
    Ok(GeneratedKeys {
        mnemonic,
        xpub: identity.xpub,
        account_xpub_vanilla: identity.account_xpub_vanilla,
        account_xpub_colored: identity.account_xpub_colored,
        master_fingerprint: identity.master_fingerprint,
        xpriv: root.to_string(),
    })
}

pub(crate) fn generated_from_root(
    root: &Xpriv,
    network: Network,
    mnemonic: String,
) -> Result<GeneratedKeys> {
    if root.network != network.network_kind()
        || root.depth != 0
        || root.parent_fingerprint != Fingerprint::default()
        || root.child_number
            != ChildNumber::from_normal_idx(0).map_err(|_| SignerError::KeyDerivation)?
    {
        return Err(invalid_argument(
            "xpriv must be a root key for the selected network",
        ));
    }
    let identity = identity_from_root(root, network)?;
    Ok(GeneratedKeys {
        mnemonic,
        xpub: identity.xpub,
        account_xpub_vanilla: identity.account_xpub_vanilla,
        account_xpub_colored: identity.account_xpub_colored,
        master_fingerprint: identity.master_fingerprint,
        xpriv: root.to_string(),
    })
}

pub(crate) fn mnemonic_seed(
    mnemonic_utf8: &[u8],
    passphrase_utf8: &[u8],
) -> Result<Zeroizing<Vec<u8>>> {
    let phrase = std::str::from_utf8(mnemonic_utf8).map_err(|_| SignerError::InvalidMnemonic)?;
    let passphrase = std::str::from_utf8(passphrase_utf8)
        .map_err(|_| invalid_argument("passphrase must be UTF-8"))?;
    let normalized = Zeroizing::new(phrase.split_whitespace().collect::<Vec<_>>().join(" "));
    let mnemonic = Mnemonic::parse_in_normalized(Language::English, &normalized)
        .map_err(|_| SignerError::InvalidMnemonic)?;
    let seed = Zeroizing::new(mnemonic.to_seed(passphrase).to_vec());
    Ok(seed)
}

pub(crate) fn derive_address_from_root(
    root: &Xpriv,
    network: Network,
    account: AccountKind,
    keychain: Keychain,
    index: u32,
) -> Result<DerivedAddress> {
    let secp = Secp256k1::new();
    let path = address_path(network, account, keychain, index)?;
    let child = root
        .derive_priv(&secp, &path)
        .map_err(|_| SignerError::KeyDerivation)?;
    let (internal_key, _) = child.to_keypair(&secp).x_only_public_key();
    let address = Address::p2tr(&secp, internal_key, None, network.bitcoin());
    let script = address.script_pubkey();
    Ok(DerivedAddress {
        address: address.to_string(),
        script_pubkey_hex: script.to_hex_string(),
        derivation_path: path.to_string(),
        internal_key_hex: internal_key.to_string(),
    })
}

pub(crate) fn derive_owned_script(
    root: &Xpriv,
    network: Network,
    path: &DerivationPath,
) -> Result<(XOnlyPublicKey, ScriptBuf)> {
    let secp = Secp256k1::new();
    let child = root
        .derive_priv(&secp, path)
        .map_err(|_| SignerError::KeyDerivation)?;
    let (internal_key, _) = child.to_keypair(&secp).x_only_public_key();
    let script = Address::p2tr(&secp, internal_key, None, network.bitcoin()).script_pubkey();
    Ok((internal_key, script))
}

pub(crate) fn master_fingerprint(root: &Xpriv) -> Fingerprint {
    Xpub::from_priv(&Secp256k1::new(), root).fingerprint()
}

pub(crate) fn sign_legacy_message(
    root: &Xpriv,
    network: Network,
    message: &[u8],
) -> Result<Vec<u8>> {
    let secp = randomized_signing_context()?;
    let path = address_path(network, AccountKind::Vanilla, Keychain::External, 0)?;
    let child = root
        .derive_priv(&secp, &path)
        .map_err(|_| SignerError::KeyDerivation)?;
    let digest = sha256::Hash::hash(message).to_byte_array();
    let mut aux_rand = Zeroizing::new([0_u8; 32]);
    getrandom::fill(aux_rand.as_mut()).map_err(|_| SignerError::EntropyUnavailable)?;
    let signature = secp.sign_schnorr_with_aux_rand(
        &Message::from_digest(digest),
        &child.to_keypair(&secp),
        &aux_rand,
    );
    Ok(signature.as_ref().to_vec())
}

pub(crate) fn verify_legacy_message(
    account_xpub: &str,
    message: &[u8],
    signature: &[u8],
) -> Result<bool> {
    let secp = Secp256k1::verification_only();
    let account =
        Xpub::from_str(account_xpub).map_err(|_| invalid_argument("invalid account xpub"))?;
    let path = DerivationPath::from(vec![
        ChildNumber::from_normal_idx(0).map_err(|_| SignerError::KeyDerivation)?,
        ChildNumber::from_normal_idx(0).map_err(|_| SignerError::KeyDerivation)?,
    ]);
    let child = account
        .derive_pub(&secp, &path)
        .map_err(|_| SignerError::KeyDerivation)?;
    let (xonly, _) = child.public_key.x_only_public_key();
    let signature = schnorr::Signature::from_slice(signature)
        .map_err(|_| invalid_argument("signature must be a 64-byte BIP340 signature"))?;
    let digest = sha256::Hash::hash(message).to_byte_array();
    Ok(secp
        .verify_schnorr(&signature, &Message::from_digest(digest), &xonly)
        .is_ok())
}
