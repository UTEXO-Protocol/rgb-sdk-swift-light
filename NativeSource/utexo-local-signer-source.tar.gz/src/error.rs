use thiserror::Error;

/// Stable failure categories crossing the native-language boundary.
///
/// Messages are deliberately safe to surface. They never include key material,
/// raw PSBTs, invoices, or backend payloads.
#[derive(Debug, Error, uniffi::Error)]
pub enum SignerError {
    #[error("invalid argument: {reason}")]
    InvalidArgument { reason: String },

    #[error("invalid mnemonic")]
    InvalidMnemonic,

    #[error("invalid seed")]
    InvalidSeed,

    #[error("secure operating-system entropy is unavailable")]
    EntropyUnavailable,

    #[error("invalid network: {reason}")]
    InvalidNetwork { reason: String },

    #[error("invalid PSBT: {reason}")]
    InvalidPsbt { reason: String },

    #[error("signing policy rejected the transaction: {reason}")]
    PolicyRejected { reason: String },

    #[error("key derivation failed")]
    KeyDerivation,

    #[error("PSBT signing failed")]
    SigningFailed,

    #[error("signature verification failed")]
    SignatureVerification,

    #[error("invalid RGB invoice: {reason}")]
    InvalidRgbInvoice { reason: String },
}

pub(crate) type Result<T> = std::result::Result<T, SignerError>;

pub(crate) fn invalid_argument(reason: impl Into<String>) -> SignerError {
    SignerError::InvalidArgument {
        reason: reason.into(),
    }
}

pub(crate) fn invalid_psbt(reason: impl Into<String>) -> SignerError {
    SignerError::InvalidPsbt {
        reason: reason.into(),
    }
}

pub(crate) fn invalid_rgb_invoice(reason: impl Into<String>) -> SignerError {
    SignerError::InvalidRgbInvoice {
        reason: reason.into(),
    }
}

pub(crate) fn rejected(reason: impl Into<String>) -> SignerError {
    SignerError::PolicyRejected {
        reason: reason.into(),
    }
}
