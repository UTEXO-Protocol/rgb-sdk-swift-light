# Supplemental upstream notices

The inventory preserves original upstream license bytes. Each supplement is bound
to a package version and either its archived VCS commit or its reviewed registry
checksum and license declaration. These are different evidence levels, explicitly
reported by the generator; a missing `.cargo_vcs_info.json` is not synthesized.

On 2026-09-19 the seven Bitcoin-family release tags in `manifest.json` were resolved
with `git ls-remote` against the publisher's `rust-bitcoin/rust-bitcoin` repository.
Their four target commits all contained byte-identical root `LICENSE` files:
SHA-256 `7179683e8000e6bdc9bbc60d85edf0a4ac8e76f951857f54fcb775d5886f1309`.
Every locked crate declares CC0-1.0; none bundles a license file or VCS record.
The supplement does not claim all crate source bytes were reproduced from a tag.

The `amplify_num` 0.5.4 and `amplify_syn` 2.0.1 crate archives reference
`./LICENSE` from their README files but do not bundle that file. Their
supplements are pinned to the exact `.cargo_vcs_info.json` commits embedded in
the crate archives and preserve the fetched upstream `LICENSE` bytes.

`hex_lit` 0.1.1 remains an explicit owner/upstream review item. Its pinned crate
declares MITNFA and names its author, but contains no original license notice.
The advertised VCS commit is not available from the current upstream repository,
which itself also contains no license text. Do not manufacture a copyright notice,
silently substitute plain MIT, or mark that missing notice as verified.

This inventory is not legal approval or selection of the SDK distribution license.
