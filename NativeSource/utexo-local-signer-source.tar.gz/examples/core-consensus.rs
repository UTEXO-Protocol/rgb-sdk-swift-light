//! Test-only regtest transaction builder. Uses a PUBLIC BIP39 test mnemonic.
//! No network access; the companion verifier owns an isolated disposable Core.
use std::{io::Read, str::FromStr};

use base64::{Engine, engine::general_purpose::STANDARD};
use bitcoin::{
    Amount, OutPoint, ScriptBuf, Sequence, Transaction, TxIn, TxOut, Txid, Witness, absolute,
    bip32::{DerivationPath, Fingerprint},
    consensus::encode::serialize_hex,
    psbt::Psbt,
    secp256k1::XOnlyPublicKey,
    sighash::TapSighashType,
    transaction,
};
use serde_json::{Value, json};
use utexo_local_signer::{
    AccountKind, Keychain, LocalSigner, Network, OperationKind, Recipient, SigningIntent,
    default_signing_policy,
};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let signer = LocalSigner::from_mnemonic(Network::Regtest,
        b"abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about".to_vec(), vec![])?;
    let funding = signer.derive_address(AccountKind::Vanilla, Keychain::External, 0)?;
    let change = signer.derive_address(AccountKind::Vanilla, Keychain::Change, 0)?;
    let recipient = signer.derive_address(AccountKind::Vanilla, Keychain::External, 10)?;
    if std::env::args().nth(1).as_deref() == Some("addresses") {
        println!(
            "{}",
            json!({"funding": funding.address, "recipient": recipient.address})
        );
        return Ok(());
    }
    let mut input = String::new();
    std::io::stdin().take(16_385).read_to_string(&mut input)?;
    if input.len() > 16_384 {
        return Err("oversized test input".into());
    }
    let request: Value = serde_json::from_str(&input)?;
    let txid = Txid::from_str(request["txid"].as_str().ok_or("missing txid")?)?;
    let vout = u32::try_from(request["vout"].as_u64().ok_or("missing vout")?)?;
    let amount = request["amountSats"].as_u64().ok_or("missing amount")?;
    let sighash_all = request["sighashAll"]
        .as_bool()
        .ok_or("missing sighash flag")?;
    let recipient_amount = 100_000;
    let fee = 1_000;
    let change_amount = amount
        .checked_sub(recipient_amount + fee)
        .ok_or("insufficient fixture")?;
    let mut psbt = Psbt::from_unsigned_tx(Transaction {
        version: transaction::Version::TWO,
        lock_time: absolute::LockTime::ZERO,
        input: vec![TxIn {
            previous_output: OutPoint { txid, vout },
            script_sig: ScriptBuf::new(),
            sequence: Sequence(0xffff_fffd),
            witness: Witness::new(),
        }],
        output: vec![
            TxOut {
                value: Amount::from_sat(recipient_amount),
                script_pubkey: ScriptBuf::from_hex(&recipient.script_pubkey_hex)?,
            },
            TxOut {
                value: Amount::from_sat(change_amount),
                script_pubkey: ScriptBuf::from_hex(&change.script_pubkey_hex)?,
            },
        ],
    })?;
    let fingerprint = Fingerprint::from_str(&signer.identity()?.master_fingerprint)?;
    let key = XOnlyPublicKey::from_str(&funding.internal_key_hex)?;
    psbt.inputs[0].witness_utxo = Some(TxOut {
        value: Amount::from_sat(amount),
        script_pubkey: ScriptBuf::from_hex(&funding.script_pubkey_hex)?,
    });
    psbt.inputs[0].tap_internal_key = Some(key);
    psbt.inputs[0].tap_key_origins.insert(
        key,
        (
            vec![],
            (
                fingerprint,
                DerivationPath::from_str(&funding.derivation_path)?,
            ),
        ),
    );
    if sighash_all {
        psbt.inputs[0].sighash_type = Some(TapSighashType::All.into());
    }
    let change_key = XOnlyPublicKey::from_str(&change.internal_key_hex)?;
    psbt.outputs[1].tap_internal_key = Some(change_key);
    psbt.outputs[1].tap_key_origins.insert(
        change_key,
        (
            vec![],
            (
                fingerprint,
                DerivationPath::from_str(&change.derivation_path)?,
            ),
        ),
    );
    let result = signer.sign_psbt(
        STANDARD.encode(psbt.serialize()),
        SigningIntent {
            operation_id: "isolated-regtest".into(),
            idempotency_key: "isolated-regtest-key".into(),
            network: Network::Regtest,
            operation: OperationKind::SendBtc,
            recipients: vec![Recipient {
                address: recipient.address,
                amount_sats: recipient_amount,
            }],
            policy: default_signing_policy(),
        },
    )?;
    let tx = Psbt::deserialize(&STANDARD.decode(&result.signed_psbt_base64)?)?.extract_tx()?;
    emit_cases(&tx, fee, recipient_amount)
}

fn emit_cases(
    tx: &Transaction,
    fee: u64,
    recipient_amount: u64,
) -> Result<(), Box<dyn std::error::Error>> {
    let mut invalid_signature = tx.clone();
    let mut signature = tx.input[0]
        .witness
        .iter()
        .next()
        .ok_or("missing witness")?
        .to_vec();
    signature[0] ^= 1;
    invalid_signature.input[0].witness = Witness::from_slice(&[signature]);
    let mut changed_output = tx.clone();
    changed_output.output[0].value = Amount::from_sat(recipient_amount - 1);
    println!(
        "{}",
        json!({
            "raw": serialize_hex(tx), "txid": tx.compute_txid().to_string(),
            "vsize": tx.vsize(), "feeSats": fee,
            "invalidSignature": serialize_hex(&invalid_signature),
            "changedOutput": serialize_hex(&changed_output),
        })
    );
    Ok(())
}
