#!/usr/bin/env node
// Uses a NEW disposable network-isolated regtest node, never the gateway's node.
// Only public test keys and locally mined valueless coins. No host mounts/ports.
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash, randomUUID } from 'node:crypto';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { artifactTree } from '../scripts/artifact-tree.mjs';

const core = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const image = 'registry.gitlab.com/hashbeam/docker/bitcoind@sha256:5473c951ca8a703f7c15d9a353f99135e0a1f0cc7ef976f29d073160950098bf';
const container = `utexo-signer-consensus-${randomUUID()}`;
const execute = (cmd, args, options = {}) => execFileSync(cmd, args, {
  encoding: 'utf8', timeout: 60_000, maxBuffer: 4 * 1024 * 1024, ...options,
}).trim();
const imageId = execute('docker', ['image', 'inspect', image, '--format', '{{.Id}}']);
assert.match(imageId, /^sha256:[a-f0-9]{64}$/);
const inputRoots = ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'src',
  'examples/core-consensus.rs', 'examples/verify-core-consensus.mjs'];
const sourceInputs = artifactTree(core, inputRoots);
execute('cargo', ['build', '--offline', '--locked', '--target-dir', resolve(core, 'target'),
  '--example', 'core-consensus'], { cwd: core, timeout: 600_000 });
const example = resolve(core, 'target/debug/examples/core-consensus');
const addresses = JSON.parse(execute(example, ['addresses']));
const evidence = { schema: 'utexo.isolated-core-consensus.v1', imageId,
  sourceInputsSha256: createHash('sha256').update(JSON.stringify(sourceInputs)).digest('hex'),
  startedAt: new Date().toISOString(), scope: 'Native core only, not mobile facade/gateway E2E', cases: [] };
const ownershipLabel = 'org.utexo.test.signer-consensus';
let startAttempted = false;
function rpc(method, ...args) {
  const result = execute('docker', ['exec', '-i', container, 'bitcoin-cli', '-regtest',
    '-datadir=/tmp', '-rpcuser=public-regtest', '-rpcpassword=public-regtest', '-stdin', method],
  { input: args.map(arg => (typeof arg === 'string' ? arg : JSON.stringify(arg)) + '\n').join('') });
  // bitcoin-cli prints a JSON string result as unquoted text.
  if (method === 'sendrawtransaction') { assert.match(result, /^[a-f0-9]{64}$/); return result; }
  return JSON.parse(result);
}
try {
  // The daemon can create the container even if the CLI later times out.
  // Cleanup inspects the exact random name and owner label on every start attempt.
  startAttempted = true;
  execute('docker', ['run', '--detach', '--rm', '--pull', 'never', '--name', container,
    '--label', `${ownershipLabel}=${container}`,
    '--platform', 'linux/amd64', '--network', 'none', '--read-only', '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges',
    '--pids-limit', '128', '--memory', '768m', '--cpus', '2',
    '--tmpfs', '/tmp:rw,nosuid,nodev,size=192m', '--entrypoint', 'bitcoind', imageId,
    '-datadir=/tmp', '-regtest', '-server', '-connect=0', '-listen=0', '-dnsseed=0',
    '-rpcuser=public-regtest', '-rpcpassword=public-regtest', '-fallbackfee=0.00002']);
  // bitcoin-cli's bounded RPC wait does not poll or touch any other node.
  evidence.core = JSON.parse(execute('docker', ['exec', container, 'bitcoin-cli', '-regtest',
    '-datadir=/tmp', '-rpcuser=public-regtest', '-rpcpassword=public-regtest',
    '-rpcwait', '-rpcwaittimeout=30', 'getnetworkinfo'])).subversion;
  assert.equal(rpc('getblockchaininfo').chain, 'regtest');
  assert.equal(rpc('getblockcount'), 0);
  const blocks = rpc('generatetoaddress', 102, addresses.funding);
  for (const [index, sighashAll] of [false, true].entries()) {
    const coinbase = rpc('getblock', blocks[index], 2).tx[0];
    const vout = coinbase.vout.find(item => item.scriptPubKey.address === addresses.funding);
    assert.ok(vout);
    // Regtest's first 102 subsidies are exactly 50 BTC, safely represented here.
    assert.equal(vout.value, 50);
    const item = JSON.parse(execute(example, [], { input: JSON.stringify({
      txid: coinbase.txid, vout: vout.n, amountSats: 5_000_000_000, sighashAll,
    }) }));
    const negatives = [];
    for (const field of ['invalidSignature', 'changedOutput']) {
      const result = rpc('testmempoolaccept', [item[field]])[0];
      assert.equal(result.allowed, false, field);
      assert.match(result['reject-reason'], /script-verify-flag/, `${field}: independent signature check required`);
      negatives.push({ mutation: field, reason: result['reject-reason'] });
    }
    const accepted = rpc('testmempoolaccept', [item.raw])[0];
    assert.equal(accepted.allowed, true);
    assert.equal(accepted.txid, item.txid);
    assert.equal(accepted.vsize, item.vsize);
    assert.equal(Math.round(accepted.fees.base * 100_000_000), item.feeSats);
    // Local-only submission confirms acceptance beyond decoding/extraction.
    const txid = rpc('sendrawtransaction', item.raw);
    assert.equal(txid, item.txid);
    const confirmedBlock = rpc('generatetoaddress', 1, addresses.recipient)[0];
    assert.ok(rpc('getblock', confirmedBlock).tx.includes(txid));
    const output = rpc('gettxout', txid, 0);
    assert.equal(output.confirmations, 1);
    assert.equal(output.scriptPubKey.address, addresses.recipient);
    assert.equal(Math.round(output.value * 100_000_000), 100_000);
    evidence.cases.push({ sighash: sighashAll ? 'ALL' : 'DEFAULT', txid,
      accepted: true, confirmed: true, negatives });
  }
  evidence.finishedAt = new Date().toISOString();
  assert.deepEqual(artifactTree(core, inputRoots), sourceInputs,
    'source changed while verifying; rerun against a stable snapshot');
} finally {
  if (startAttempted) {
    const listOwnedName = () => execute('docker', ['container', 'ls', '--all', '--quiet', '--no-trunc',
      '--filter', `name=^/${container}$`]);
    const existing = listOwnedName();
    if (existing) {
      assert.match(existing, /^[a-f0-9]{64}$/);
      const [metadata] = JSON.parse(execute('docker', ['container', 'inspect', existing]));
      assert.equal(metadata.Name, `/${container}`);
      assert.equal(metadata.Config.Labels[ownershipLabel], container, 'refusing cleanup of unowned container');
      // --rm also removes this test container's anonymous image-declared volume.
      execute('docker', ['stop', '--time', '10', existing]);
    }
    const deadline = Date.now() + 5_000;
    while (listOwnedName()) {
      assert.ok(Date.now() < deadline, `test container cleanup not confirmed: ${container}`);
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    evidence.noRemainingTestContainerObserved = true;
  }
}
console.log(JSON.stringify(evidence, null, 2));
