// Failure-path checks for the verifier itself. Docker is replaced by a local
// process stub; these tests never contact a Docker daemon or start containers.
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const core = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const verifier = join(core, 'examples/verify-core-consensus.mjs');
const dockerStub = `#!/usr/bin/env node
const fs = require('fs');
const path = process.env.UTEXO_CONSENSUS_STUB_STATE;
const state = JSON.parse(fs.readFileSync(path, 'utf8'));
const args = process.argv.slice(2);
state.calls.push(args);
function save() { fs.writeFileSync(path, JSON.stringify(state)); }
function out(value) { save(); process.stdout.write(value + '\\n'); }
if (args[0] === 'image') {
  out('sha256:5473c951ca8a703f7c15d9a353f99135e0a1f0cc7ef976f29d073160950098bf');
} else if (args[0] === 'run') {
  const name = args[args.indexOf('--name') + 1];
  state.container = state.scenario === 'before-create' ? null : {
    Id: 'a'.repeat(64), Name: '/' + name,
    Config: { Labels: { 'org.utexo.test.signer-consensus': state.scenario === 'foreign-owner' ? 'foreign' : name } }
  };
  save(); process.stderr.write('injected uncertain Docker start failure\\n'); process.exit(1);
} else if (args[0] === 'container' && args[1] === 'ls') {
  if (state.scenario === 'inspection-unavailable') { save(); process.exit(1); }
  out(state.container ? state.container.Id : '');
} else if (args[0] === 'container' && args[1] === 'inspect') {
  out(JSON.stringify([state.container]));
} else if (args[0] === 'stop') {
  if (state.scenario === 'stop-unavailable') { save(); process.exit(1); }
  state.container = null; out('stopped');
} else {
  save(); process.stderr.write('unexpected stub command\\n'); process.exit(99);
}
`;

for (const scenario of ['after-create', 'before-create', 'foreign-owner', 'inspection-unavailable', 'stop-unavailable']) {
  test(`consensus cleanup: ${scenario}`, { timeout: 660_000 }, () => {
    const directory = mkdtempSync(join(tmpdir(), 'utexo-consensus-cleanup-'));
    try {
      const stateFile = join(directory, 'state.json');
      writeFileSync(stateFile, JSON.stringify({ scenario, calls: [], container: null }));
      writeFileSync(join(directory, 'docker'), dockerStub, { mode: 0o700 });
      let failure;
      try {
        execFileSync(process.execPath, [verifier], {
          cwd: core, encoding: 'utf8', timeout: 650_000, stdio: ['pipe', 'pipe', 'pipe'],
          env: { ...process.env, PATH: directory + ':' + process.env.PATH,
            UTEXO_CONSENSUS_STUB_STATE: stateFile },
        });
      } catch (error) { failure = error; }
      assert.ok(failure, 'an uncertain start must not return a green verification');
      assert.equal(failure.status, 1, 'must fail by assertion/command, not harness timeout');
      assert.ok(!String(failure.stdout).includes('noRemainingTestContainerObserved'), 'no success report after failed start');
      const state = JSON.parse(readFileSync(stateFile, 'utf8'));
      assert.ok(state.calls.some(args => args[0] === 'run'), 'reach the injected start fault');
      assert.ok(state.calls.some(args => args[0] === 'container' && args[1] === 'ls'), 'always inspect after attempted start');
      const stopped = state.calls.some(args => args[0] === 'stop');
      assert.equal(stopped, ['after-create', 'stop-unavailable'].includes(scenario));
      assert.equal(state.container === null, ['after-create', 'before-create'].includes(scenario));
      assert.ok(!state.calls.some(args => args[0] === 'exec'), 'failure cases never reach node RPC');
    } finally {
      // This exact generated directory contains only the stub and its JSON state.
      rmSync(directory, { recursive: true, force: true });
    }
  });
}
