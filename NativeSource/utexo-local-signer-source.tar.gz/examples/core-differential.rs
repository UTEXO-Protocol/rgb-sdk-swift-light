//! Stateless, synthetic transaction corpus for an independent Bitcoin Core decoder.
//! Public test keys/nonexistent inputs only. Never broadcasts or asks Core to sign.
use base64::{Engine, engine::general_purpose::STANDARD};
use bitcoin::{Amount, consensus::encode::serialize_hex, psbt::Psbt};
use serde_json::{Value, json};
use utexo_local_signer::{
    LocalSigner, Network, OperationKind, Recipient, SigningIntent, default_signing_policy,
};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let fixture: Value =
        serde_json::from_str(include_str!("../fixtures/native-signing-multi-smoke.json"))?;
    let fixture_text = fixture["psbt"]
        .as_str()
        .ok_or("missing test fixture PSBT")?;
    let recipient = fixture["recipient"]
        .as_str()
        .ok_or("missing test recipient")?;
    let session = LocalSigner::from_mnemonic(Network::Mainnet,
        b"abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about".to_vec(), vec![])?;
    for number in 0..128_u64 {
        let mut psbt = Psbt::deserialize(&STANDARD.decode(fixture_text)?)?;
        if number % 2 == 0 {
            psbt.inputs.remove(1);
            psbt.unsigned_tx.input.remove(1);
        }
        let mut input_total = 0_u64;
        for (index, input) in psbt.inputs.iter_mut().enumerate() {
            let amount = 100_000 + number * 101 + u64::try_from(index)?;
            input
                .witness_utxo
                .as_mut()
                .ok_or("missing fixture UTXO")?
                .value = Amount::from_sat(amount);
            input_total += amount;
            // Exercise both permitted DEFAULT and ALL witnesses.
            if number % 3 == 0 {
                input.sighash_type = Some(bitcoin::sighash::TapSighashType::All.into());
            }
        }
        let amount = 30_000 + number;
        let fee = 400 + number * 3;
        psbt.unsigned_tx.output[0].value = Amount::from_sat(amount);
        psbt.unsigned_tx.output[1].value = Amount::from_sat(input_total - amount - fee);
        let intent = SigningIntent {
            operation_id: format!("core-differential-{number}"),
            idempotency_key: format!("core-differential-key-{number}"),
            network: Network::Mainnet,
            operation: OperationKind::SendBtc,
            recipients: vec![Recipient {
                address: recipient.into(),
                amount_sats: amount,
            }],
            policy: default_signing_policy(),
        };
        let signed = session.sign_psbt(STANDARD.encode(psbt.serialize()), intent)?;
        let tx = Psbt::deserialize(&STANDARD.decode(&signed.signed_psbt_base64)?)?.extract_tx()?;
        println!(
            "{}",
            json!({
                "case": number, "psbt": signed.signed_psbt_base64,
                "raw": serialize_hex(&tx), "txid": signed.validation.unsigned_txid,
                "vsize": signed.validation.estimated_vbytes, "weight": tx.weight().to_wu(),
                "inputs": signed.validation.input_count, "feeSats": signed.validation.fee_sats,
                "outputs": tx.output.iter().map(|output| json!({
                    "valueSats": output.value.to_sat(), "script": output.script_pubkey.to_hex_string(),
                })).collect::<Vec<_>>()
            })
        );
    }
    Ok(())
}
